
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00009117          	auipc	sp,0x9
    80000004:	90013103          	ld	sp,-1792(sp) # 80008900 <_GLOBAL_OFFSET_TABLE_+0x8>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	076000ef          	jal	ra,8000008c <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
// at timervec in kernelvec.S,
// which turns them into software interrupts for
// devintr() in trap.c.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
// which hart (core) is this?
static inline uint64
r_mhartid()
{
  uint64 x;
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80000022:	f14027f3          	csrr	a5,mhartid
  // each CPU has a separate source of timer interrupts.
  int id = r_mhartid();
    80000026:	0007859b          	sext.w	a1,a5

  // ask the CLINT for a timer interrupt.
  int interval = 1000000; // cycles; about 1/10th second in qemu.
  *(uint64*)CLINT_MTIMECMP(id) = *(uint64*)CLINT_MTIME + interval;
    8000002a:	0037979b          	slliw	a5,a5,0x3
    8000002e:	02004737          	lui	a4,0x2004
    80000032:	97ba                	add	a5,a5,a4
    80000034:	0200c737          	lui	a4,0x200c
    80000038:	ff873703          	ld	a4,-8(a4) # 200bff8 <_entry-0x7dff4008>
    8000003c:	000f4637          	lui	a2,0xf4
    80000040:	24060613          	addi	a2,a2,576 # f4240 <_entry-0x7ff0bdc0>
    80000044:	9732                	add	a4,a4,a2
    80000046:	e398                	sd	a4,0(a5)

  // prepare information in scratch[] for timervec.
  // scratch[0..2] : space for timervec to save registers.
  // scratch[3] : address of CLINT MTIMECMP register.
  // scratch[4] : desired interval (in cycles) between timer interrupts.
  uint64 *scratch = &timer_scratch[id][0];
    80000048:	00259693          	slli	a3,a1,0x2
    8000004c:	96ae                	add	a3,a3,a1
    8000004e:	068e                	slli	a3,a3,0x3
    80000050:	00009717          	auipc	a4,0x9
    80000054:	92070713          	addi	a4,a4,-1760 # 80008970 <timer_scratch>
    80000058:	9736                	add	a4,a4,a3
  scratch[3] = CLINT_MTIMECMP(id);
    8000005a:	ef1c                	sd	a5,24(a4)
  scratch[4] = interval;
    8000005c:	f310                	sd	a2,32(a4)
}

static inline void 
w_mscratch(uint64 x)
{
  asm volatile("csrw mscratch, %0" : : "r" (x));
    8000005e:	34071073          	csrw	mscratch,a4
  asm volatile("csrw mtvec, %0" : : "r" (x));
    80000062:	00006797          	auipc	a5,0x6
    80000066:	d6e78793          	addi	a5,a5,-658 # 80005dd0 <timervec>
    8000006a:	30579073          	csrw	mtvec,a5
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    8000006e:	300027f3          	csrr	a5,mstatus

  // set the machine-mode trap handler.
  w_mtvec((uint64)timervec);

  // enable machine-mode interrupts.
  w_mstatus(r_mstatus() | MSTATUS_MIE);
    80000072:	0087e793          	ori	a5,a5,8
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80000076:	30079073          	csrw	mstatus,a5
  asm volatile("csrr %0, mie" : "=r" (x) );
    8000007a:	304027f3          	csrr	a5,mie

  // enable machine-mode timer interrupts.
  w_mie(r_mie() | MIE_MTIE);
    8000007e:	0807e793          	ori	a5,a5,128
  asm volatile("csrw mie, %0" : : "r" (x));
    80000082:	30479073          	csrw	mie,a5
}
    80000086:	6422                	ld	s0,8(sp)
    80000088:	0141                	addi	sp,sp,16
    8000008a:	8082                	ret

000000008000008c <start>:
{
    8000008c:	1141                	addi	sp,sp,-16
    8000008e:	e406                	sd	ra,8(sp)
    80000090:	e022                	sd	s0,0(sp)
    80000092:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000094:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000098:	7779                	lui	a4,0xffffe
    8000009a:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdc59f>
    8000009e:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    800000a0:	6705                	lui	a4,0x1
    800000a2:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    800000a6:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    800000a8:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    800000ac:	00001797          	auipc	a5,0x1
    800000b0:	dcc78793          	addi	a5,a5,-564 # 80000e78 <main>
    800000b4:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    800000b8:	4781                	li	a5,0
    800000ba:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    800000be:	67c1                	lui	a5,0x10
    800000c0:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    800000c2:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    800000c6:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    800000ca:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    800000ce:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    800000d2:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000d6:	57fd                	li	a5,-1
    800000d8:	83a9                	srli	a5,a5,0xa
    800000da:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000de:	47bd                	li	a5,15
    800000e0:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000e4:	00000097          	auipc	ra,0x0
    800000e8:	f38080e7          	jalr	-200(ra) # 8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000ec:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000f0:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000f2:	823e                	mv	tp,a5
  asm volatile("mret");
    800000f4:	30200073          	mret
}
    800000f8:	60a2                	ld	ra,8(sp)
    800000fa:	6402                	ld	s0,0(sp)
    800000fc:	0141                	addi	sp,sp,16
    800000fe:	8082                	ret

0000000080000100 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80000100:	715d                	addi	sp,sp,-80
    80000102:	e486                	sd	ra,72(sp)
    80000104:	e0a2                	sd	s0,64(sp)
    80000106:	fc26                	sd	s1,56(sp)
    80000108:	f84a                	sd	s2,48(sp)
    8000010a:	f44e                	sd	s3,40(sp)
    8000010c:	f052                	sd	s4,32(sp)
    8000010e:	ec56                	sd	s5,24(sp)
    80000110:	0880                	addi	s0,sp,80
  int i;

  for(i = 0; i < n; i++){
    80000112:	04c05763          	blez	a2,80000160 <consolewrite+0x60>
    80000116:	8a2a                	mv	s4,a0
    80000118:	84ae                	mv	s1,a1
    8000011a:	89b2                	mv	s3,a2
    8000011c:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    8000011e:	5afd                	li	s5,-1
    80000120:	4685                	li	a3,1
    80000122:	8626                	mv	a2,s1
    80000124:	85d2                	mv	a1,s4
    80000126:	fbf40513          	addi	a0,s0,-65
    8000012a:	00002097          	auipc	ra,0x2
    8000012e:	560080e7          	jalr	1376(ra) # 8000268a <either_copyin>
    80000132:	01550d63          	beq	a0,s5,8000014c <consolewrite+0x4c>
      break;
    uartputc(c);
    80000136:	fbf44503          	lbu	a0,-65(s0)
    8000013a:	00000097          	auipc	ra,0x0
    8000013e:	784080e7          	jalr	1924(ra) # 800008be <uartputc>
  for(i = 0; i < n; i++){
    80000142:	2905                	addiw	s2,s2,1
    80000144:	0485                	addi	s1,s1,1
    80000146:	fd299de3          	bne	s3,s2,80000120 <consolewrite+0x20>
    8000014a:	894e                	mv	s2,s3
  }

  return i;
}
    8000014c:	854a                	mv	a0,s2
    8000014e:	60a6                	ld	ra,72(sp)
    80000150:	6406                	ld	s0,64(sp)
    80000152:	74e2                	ld	s1,56(sp)
    80000154:	7942                	ld	s2,48(sp)
    80000156:	79a2                	ld	s3,40(sp)
    80000158:	7a02                	ld	s4,32(sp)
    8000015a:	6ae2                	ld	s5,24(sp)
    8000015c:	6161                	addi	sp,sp,80
    8000015e:	8082                	ret
  for(i = 0; i < n; i++){
    80000160:	4901                	li	s2,0
    80000162:	b7ed                	j	8000014c <consolewrite+0x4c>

0000000080000164 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000164:	7159                	addi	sp,sp,-112
    80000166:	f486                	sd	ra,104(sp)
    80000168:	f0a2                	sd	s0,96(sp)
    8000016a:	eca6                	sd	s1,88(sp)
    8000016c:	e8ca                	sd	s2,80(sp)
    8000016e:	e4ce                	sd	s3,72(sp)
    80000170:	e0d2                	sd	s4,64(sp)
    80000172:	fc56                	sd	s5,56(sp)
    80000174:	f85a                	sd	s6,48(sp)
    80000176:	f45e                	sd	s7,40(sp)
    80000178:	f062                	sd	s8,32(sp)
    8000017a:	ec66                	sd	s9,24(sp)
    8000017c:	e86a                	sd	s10,16(sp)
    8000017e:	1880                	addi	s0,sp,112
    80000180:	8aaa                	mv	s5,a0
    80000182:	8a2e                	mv	s4,a1
    80000184:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000186:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    8000018a:	00011517          	auipc	a0,0x11
    8000018e:	92650513          	addi	a0,a0,-1754 # 80010ab0 <cons>
    80000192:	00001097          	auipc	ra,0x1
    80000196:	a44080e7          	jalr	-1468(ra) # 80000bd6 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000019a:	00011497          	auipc	s1,0x11
    8000019e:	91648493          	addi	s1,s1,-1770 # 80010ab0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a2:	00011917          	auipc	s2,0x11
    800001a6:	9a690913          	addi	s2,s2,-1626 # 80010b48 <cons+0x98>
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];

    if(c == C('D')){  // end-of-file
    800001aa:	4b91                	li	s7,4
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800001ac:	5c7d                	li	s8,-1
      break;

    dst++;
    --n;

    if(c == '\n'){
    800001ae:	4ca9                	li	s9,10
  while(n > 0){
    800001b0:	07305b63          	blez	s3,80000226 <consoleread+0xc2>
    while(cons.r == cons.w){
    800001b4:	0984a783          	lw	a5,152(s1)
    800001b8:	09c4a703          	lw	a4,156(s1)
    800001bc:	02f71763          	bne	a4,a5,800001ea <consoleread+0x86>
      if(killed(myproc())){
    800001c0:	00002097          	auipc	ra,0x2
    800001c4:	8d6080e7          	jalr	-1834(ra) # 80001a96 <myproc>
    800001c8:	00002097          	auipc	ra,0x2
    800001cc:	30c080e7          	jalr	780(ra) # 800024d4 <killed>
    800001d0:	e535                	bnez	a0,8000023c <consoleread+0xd8>
      sleep(&cons.r, &cons.lock);
    800001d2:	85a6                	mv	a1,s1
    800001d4:	854a                	mv	a0,s2
    800001d6:	00002097          	auipc	ra,0x2
    800001da:	056080e7          	jalr	86(ra) # 8000222c <sleep>
    while(cons.r == cons.w){
    800001de:	0984a783          	lw	a5,152(s1)
    800001e2:	09c4a703          	lw	a4,156(s1)
    800001e6:	fcf70de3          	beq	a4,a5,800001c0 <consoleread+0x5c>
    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001ea:	0017871b          	addiw	a4,a5,1
    800001ee:	08e4ac23          	sw	a4,152(s1)
    800001f2:	07f7f713          	andi	a4,a5,127
    800001f6:	9726                	add	a4,a4,s1
    800001f8:	01874703          	lbu	a4,24(a4)
    800001fc:	00070d1b          	sext.w	s10,a4
    if(c == C('D')){  // end-of-file
    80000200:	077d0563          	beq	s10,s7,8000026a <consoleread+0x106>
    cbuf = c;
    80000204:	f8e40fa3          	sb	a4,-97(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000208:	4685                	li	a3,1
    8000020a:	f9f40613          	addi	a2,s0,-97
    8000020e:	85d2                	mv	a1,s4
    80000210:	8556                	mv	a0,s5
    80000212:	00002097          	auipc	ra,0x2
    80000216:	422080e7          	jalr	1058(ra) # 80002634 <either_copyout>
    8000021a:	01850663          	beq	a0,s8,80000226 <consoleread+0xc2>
    dst++;
    8000021e:	0a05                	addi	s4,s4,1
    --n;
    80000220:	39fd                	addiw	s3,s3,-1
    if(c == '\n'){
    80000222:	f99d17e3          	bne	s10,s9,800001b0 <consoleread+0x4c>
      // a whole line has arrived, return to
      // the user-level read().
      break;
    }
  }
  release(&cons.lock);
    80000226:	00011517          	auipc	a0,0x11
    8000022a:	88a50513          	addi	a0,a0,-1910 # 80010ab0 <cons>
    8000022e:	00001097          	auipc	ra,0x1
    80000232:	a5c080e7          	jalr	-1444(ra) # 80000c8a <release>

  return target - n;
    80000236:	413b053b          	subw	a0,s6,s3
    8000023a:	a811                	j	8000024e <consoleread+0xea>
        release(&cons.lock);
    8000023c:	00011517          	auipc	a0,0x11
    80000240:	87450513          	addi	a0,a0,-1932 # 80010ab0 <cons>
    80000244:	00001097          	auipc	ra,0x1
    80000248:	a46080e7          	jalr	-1466(ra) # 80000c8a <release>
        return -1;
    8000024c:	557d                	li	a0,-1
}
    8000024e:	70a6                	ld	ra,104(sp)
    80000250:	7406                	ld	s0,96(sp)
    80000252:	64e6                	ld	s1,88(sp)
    80000254:	6946                	ld	s2,80(sp)
    80000256:	69a6                	ld	s3,72(sp)
    80000258:	6a06                	ld	s4,64(sp)
    8000025a:	7ae2                	ld	s5,56(sp)
    8000025c:	7b42                	ld	s6,48(sp)
    8000025e:	7ba2                	ld	s7,40(sp)
    80000260:	7c02                	ld	s8,32(sp)
    80000262:	6ce2                	ld	s9,24(sp)
    80000264:	6d42                	ld	s10,16(sp)
    80000266:	6165                	addi	sp,sp,112
    80000268:	8082                	ret
      if(n < target){
    8000026a:	0009871b          	sext.w	a4,s3
    8000026e:	fb677ce3          	bgeu	a4,s6,80000226 <consoleread+0xc2>
        cons.r--;
    80000272:	00011717          	auipc	a4,0x11
    80000276:	8cf72b23          	sw	a5,-1834(a4) # 80010b48 <cons+0x98>
    8000027a:	b775                	j	80000226 <consoleread+0xc2>

000000008000027c <consputc>:
{
    8000027c:	1141                	addi	sp,sp,-16
    8000027e:	e406                	sd	ra,8(sp)
    80000280:	e022                	sd	s0,0(sp)
    80000282:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000284:	10000793          	li	a5,256
    80000288:	00f50a63          	beq	a0,a5,8000029c <consputc+0x20>
    uartputc_sync(c);
    8000028c:	00000097          	auipc	ra,0x0
    80000290:	560080e7          	jalr	1376(ra) # 800007ec <uartputc_sync>
}
    80000294:	60a2                	ld	ra,8(sp)
    80000296:	6402                	ld	s0,0(sp)
    80000298:	0141                	addi	sp,sp,16
    8000029a:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    8000029c:	4521                	li	a0,8
    8000029e:	00000097          	auipc	ra,0x0
    800002a2:	54e080e7          	jalr	1358(ra) # 800007ec <uartputc_sync>
    800002a6:	02000513          	li	a0,32
    800002aa:	00000097          	auipc	ra,0x0
    800002ae:	542080e7          	jalr	1346(ra) # 800007ec <uartputc_sync>
    800002b2:	4521                	li	a0,8
    800002b4:	00000097          	auipc	ra,0x0
    800002b8:	538080e7          	jalr	1336(ra) # 800007ec <uartputc_sync>
    800002bc:	bfe1                	j	80000294 <consputc+0x18>

00000000800002be <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002be:	1101                	addi	sp,sp,-32
    800002c0:	ec06                	sd	ra,24(sp)
    800002c2:	e822                	sd	s0,16(sp)
    800002c4:	e426                	sd	s1,8(sp)
    800002c6:	e04a                	sd	s2,0(sp)
    800002c8:	1000                	addi	s0,sp,32
    800002ca:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002cc:	00010517          	auipc	a0,0x10
    800002d0:	7e450513          	addi	a0,a0,2020 # 80010ab0 <cons>
    800002d4:	00001097          	auipc	ra,0x1
    800002d8:	902080e7          	jalr	-1790(ra) # 80000bd6 <acquire>

  switch(c){
    800002dc:	47d5                	li	a5,21
    800002de:	0af48663          	beq	s1,a5,8000038a <consoleintr+0xcc>
    800002e2:	0297ca63          	blt	a5,s1,80000316 <consoleintr+0x58>
    800002e6:	47a1                	li	a5,8
    800002e8:	0ef48763          	beq	s1,a5,800003d6 <consoleintr+0x118>
    800002ec:	47c1                	li	a5,16
    800002ee:	10f49a63          	bne	s1,a5,80000402 <consoleintr+0x144>
  case C('P'):  // Print process list.
    procdump();
    800002f2:	00002097          	auipc	ra,0x2
    800002f6:	3ee080e7          	jalr	1006(ra) # 800026e0 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002fa:	00010517          	auipc	a0,0x10
    800002fe:	7b650513          	addi	a0,a0,1974 # 80010ab0 <cons>
    80000302:	00001097          	auipc	ra,0x1
    80000306:	988080e7          	jalr	-1656(ra) # 80000c8a <release>
}
    8000030a:	60e2                	ld	ra,24(sp)
    8000030c:	6442                	ld	s0,16(sp)
    8000030e:	64a2                	ld	s1,8(sp)
    80000310:	6902                	ld	s2,0(sp)
    80000312:	6105                	addi	sp,sp,32
    80000314:	8082                	ret
  switch(c){
    80000316:	07f00793          	li	a5,127
    8000031a:	0af48e63          	beq	s1,a5,800003d6 <consoleintr+0x118>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    8000031e:	00010717          	auipc	a4,0x10
    80000322:	79270713          	addi	a4,a4,1938 # 80010ab0 <cons>
    80000326:	0a072783          	lw	a5,160(a4)
    8000032a:	09872703          	lw	a4,152(a4)
    8000032e:	9f99                	subw	a5,a5,a4
    80000330:	07f00713          	li	a4,127
    80000334:	fcf763e3          	bltu	a4,a5,800002fa <consoleintr+0x3c>
      c = (c == '\r') ? '\n' : c;
    80000338:	47b5                	li	a5,13
    8000033a:	0cf48763          	beq	s1,a5,80000408 <consoleintr+0x14a>
      consputc(c);
    8000033e:	8526                	mv	a0,s1
    80000340:	00000097          	auipc	ra,0x0
    80000344:	f3c080e7          	jalr	-196(ra) # 8000027c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000348:	00010797          	auipc	a5,0x10
    8000034c:	76878793          	addi	a5,a5,1896 # 80010ab0 <cons>
    80000350:	0a07a683          	lw	a3,160(a5)
    80000354:	0016871b          	addiw	a4,a3,1
    80000358:	0007061b          	sext.w	a2,a4
    8000035c:	0ae7a023          	sw	a4,160(a5)
    80000360:	07f6f693          	andi	a3,a3,127
    80000364:	97b6                	add	a5,a5,a3
    80000366:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    8000036a:	47a9                	li	a5,10
    8000036c:	0cf48563          	beq	s1,a5,80000436 <consoleintr+0x178>
    80000370:	4791                	li	a5,4
    80000372:	0cf48263          	beq	s1,a5,80000436 <consoleintr+0x178>
    80000376:	00010797          	auipc	a5,0x10
    8000037a:	7d27a783          	lw	a5,2002(a5) # 80010b48 <cons+0x98>
    8000037e:	9f1d                	subw	a4,a4,a5
    80000380:	08000793          	li	a5,128
    80000384:	f6f71be3          	bne	a4,a5,800002fa <consoleintr+0x3c>
    80000388:	a07d                	j	80000436 <consoleintr+0x178>
    while(cons.e != cons.w &&
    8000038a:	00010717          	auipc	a4,0x10
    8000038e:	72670713          	addi	a4,a4,1830 # 80010ab0 <cons>
    80000392:	0a072783          	lw	a5,160(a4)
    80000396:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    8000039a:	00010497          	auipc	s1,0x10
    8000039e:	71648493          	addi	s1,s1,1814 # 80010ab0 <cons>
    while(cons.e != cons.w &&
    800003a2:	4929                	li	s2,10
    800003a4:	f4f70be3          	beq	a4,a5,800002fa <consoleintr+0x3c>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    800003a8:	37fd                	addiw	a5,a5,-1
    800003aa:	07f7f713          	andi	a4,a5,127
    800003ae:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    800003b0:	01874703          	lbu	a4,24(a4)
    800003b4:	f52703e3          	beq	a4,s2,800002fa <consoleintr+0x3c>
      cons.e--;
    800003b8:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003bc:	10000513          	li	a0,256
    800003c0:	00000097          	auipc	ra,0x0
    800003c4:	ebc080e7          	jalr	-324(ra) # 8000027c <consputc>
    while(cons.e != cons.w &&
    800003c8:	0a04a783          	lw	a5,160(s1)
    800003cc:	09c4a703          	lw	a4,156(s1)
    800003d0:	fcf71ce3          	bne	a4,a5,800003a8 <consoleintr+0xea>
    800003d4:	b71d                	j	800002fa <consoleintr+0x3c>
    if(cons.e != cons.w){
    800003d6:	00010717          	auipc	a4,0x10
    800003da:	6da70713          	addi	a4,a4,1754 # 80010ab0 <cons>
    800003de:	0a072783          	lw	a5,160(a4)
    800003e2:	09c72703          	lw	a4,156(a4)
    800003e6:	f0f70ae3          	beq	a4,a5,800002fa <consoleintr+0x3c>
      cons.e--;
    800003ea:	37fd                	addiw	a5,a5,-1
    800003ec:	00010717          	auipc	a4,0x10
    800003f0:	76f72223          	sw	a5,1892(a4) # 80010b50 <cons+0xa0>
      consputc(BACKSPACE);
    800003f4:	10000513          	li	a0,256
    800003f8:	00000097          	auipc	ra,0x0
    800003fc:	e84080e7          	jalr	-380(ra) # 8000027c <consputc>
    80000400:	bded                	j	800002fa <consoleintr+0x3c>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80000402:	ee048ce3          	beqz	s1,800002fa <consoleintr+0x3c>
    80000406:	bf21                	j	8000031e <consoleintr+0x60>
      consputc(c);
    80000408:	4529                	li	a0,10
    8000040a:	00000097          	auipc	ra,0x0
    8000040e:	e72080e7          	jalr	-398(ra) # 8000027c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000412:	00010797          	auipc	a5,0x10
    80000416:	69e78793          	addi	a5,a5,1694 # 80010ab0 <cons>
    8000041a:	0a07a703          	lw	a4,160(a5)
    8000041e:	0017069b          	addiw	a3,a4,1
    80000422:	0006861b          	sext.w	a2,a3
    80000426:	0ad7a023          	sw	a3,160(a5)
    8000042a:	07f77713          	andi	a4,a4,127
    8000042e:	97ba                	add	a5,a5,a4
    80000430:	4729                	li	a4,10
    80000432:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    80000436:	00010797          	auipc	a5,0x10
    8000043a:	70c7ab23          	sw	a2,1814(a5) # 80010b4c <cons+0x9c>
        wakeup(&cons.r);
    8000043e:	00010517          	auipc	a0,0x10
    80000442:	70a50513          	addi	a0,a0,1802 # 80010b48 <cons+0x98>
    80000446:	00002097          	auipc	ra,0x2
    8000044a:	e4a080e7          	jalr	-438(ra) # 80002290 <wakeup>
    8000044e:	b575                	j	800002fa <consoleintr+0x3c>

0000000080000450 <consoleinit>:

void
consoleinit(void)
{
    80000450:	1141                	addi	sp,sp,-16
    80000452:	e406                	sd	ra,8(sp)
    80000454:	e022                	sd	s0,0(sp)
    80000456:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000458:	00008597          	auipc	a1,0x8
    8000045c:	bb858593          	addi	a1,a1,-1096 # 80008010 <etext+0x10>
    80000460:	00010517          	auipc	a0,0x10
    80000464:	65050513          	addi	a0,a0,1616 # 80010ab0 <cons>
    80000468:	00000097          	auipc	ra,0x0
    8000046c:	6de080e7          	jalr	1758(ra) # 80000b46 <initlock>

  uartinit();
    80000470:	00000097          	auipc	ra,0x0
    80000474:	32c080e7          	jalr	812(ra) # 8000079c <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000478:	00021797          	auipc	a5,0x21
    8000047c:	c5078793          	addi	a5,a5,-944 # 800210c8 <devsw>
    80000480:	00000717          	auipc	a4,0x0
    80000484:	ce470713          	addi	a4,a4,-796 # 80000164 <consoleread>
    80000488:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    8000048a:	00000717          	auipc	a4,0x0
    8000048e:	c7670713          	addi	a4,a4,-906 # 80000100 <consolewrite>
    80000492:	ef98                	sd	a4,24(a5)
}
    80000494:	60a2                	ld	ra,8(sp)
    80000496:	6402                	ld	s0,0(sp)
    80000498:	0141                	addi	sp,sp,16
    8000049a:	8082                	ret

000000008000049c <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(int xx, int base, int sign)
{
    8000049c:	7179                	addi	sp,sp,-48
    8000049e:	f406                	sd	ra,40(sp)
    800004a0:	f022                	sd	s0,32(sp)
    800004a2:	ec26                	sd	s1,24(sp)
    800004a4:	e84a                	sd	s2,16(sp)
    800004a6:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  uint x;

  if(sign && (sign = xx < 0))
    800004a8:	c219                	beqz	a2,800004ae <printint+0x12>
    800004aa:	08054763          	bltz	a0,80000538 <printint+0x9c>
    x = -xx;
  else
    x = xx;
    800004ae:	2501                	sext.w	a0,a0
    800004b0:	4881                	li	a7,0
    800004b2:	fd040693          	addi	a3,s0,-48

  i = 0;
    800004b6:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    800004b8:	2581                	sext.w	a1,a1
    800004ba:	00008617          	auipc	a2,0x8
    800004be:	b8660613          	addi	a2,a2,-1146 # 80008040 <digits>
    800004c2:	883a                	mv	a6,a4
    800004c4:	2705                	addiw	a4,a4,1
    800004c6:	02b577bb          	remuw	a5,a0,a1
    800004ca:	1782                	slli	a5,a5,0x20
    800004cc:	9381                	srli	a5,a5,0x20
    800004ce:	97b2                	add	a5,a5,a2
    800004d0:	0007c783          	lbu	a5,0(a5)
    800004d4:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    800004d8:	0005079b          	sext.w	a5,a0
    800004dc:	02b5553b          	divuw	a0,a0,a1
    800004e0:	0685                	addi	a3,a3,1
    800004e2:	feb7f0e3          	bgeu	a5,a1,800004c2 <printint+0x26>

  if(sign)
    800004e6:	00088c63          	beqz	a7,800004fe <printint+0x62>
    buf[i++] = '-';
    800004ea:	fe070793          	addi	a5,a4,-32
    800004ee:	00878733          	add	a4,a5,s0
    800004f2:	02d00793          	li	a5,45
    800004f6:	fef70823          	sb	a5,-16(a4)
    800004fa:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
    800004fe:	02e05763          	blez	a4,8000052c <printint+0x90>
    80000502:	fd040793          	addi	a5,s0,-48
    80000506:	00e784b3          	add	s1,a5,a4
    8000050a:	fff78913          	addi	s2,a5,-1
    8000050e:	993a                	add	s2,s2,a4
    80000510:	377d                	addiw	a4,a4,-1
    80000512:	1702                	slli	a4,a4,0x20
    80000514:	9301                	srli	a4,a4,0x20
    80000516:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    8000051a:	fff4c503          	lbu	a0,-1(s1)
    8000051e:	00000097          	auipc	ra,0x0
    80000522:	d5e080e7          	jalr	-674(ra) # 8000027c <consputc>
  while(--i >= 0)
    80000526:	14fd                	addi	s1,s1,-1
    80000528:	ff2499e3          	bne	s1,s2,8000051a <printint+0x7e>
}
    8000052c:	70a2                	ld	ra,40(sp)
    8000052e:	7402                	ld	s0,32(sp)
    80000530:	64e2                	ld	s1,24(sp)
    80000532:	6942                	ld	s2,16(sp)
    80000534:	6145                	addi	sp,sp,48
    80000536:	8082                	ret
    x = -xx;
    80000538:	40a0053b          	negw	a0,a0
  if(sign && (sign = xx < 0))
    8000053c:	4885                	li	a7,1
    x = -xx;
    8000053e:	bf95                	j	800004b2 <printint+0x16>

0000000080000540 <panic>:
    release(&pr.lock);
}

void
panic(char *s)
{
    80000540:	1101                	addi	sp,sp,-32
    80000542:	ec06                	sd	ra,24(sp)
    80000544:	e822                	sd	s0,16(sp)
    80000546:	e426                	sd	s1,8(sp)
    80000548:	1000                	addi	s0,sp,32
    8000054a:	84aa                	mv	s1,a0
  pr.locking = 0;
    8000054c:	00010797          	auipc	a5,0x10
    80000550:	6207a223          	sw	zero,1572(a5) # 80010b70 <pr+0x18>
  printf("panic: ");
    80000554:	00008517          	auipc	a0,0x8
    80000558:	ac450513          	addi	a0,a0,-1340 # 80008018 <etext+0x18>
    8000055c:	00000097          	auipc	ra,0x0
    80000560:	02e080e7          	jalr	46(ra) # 8000058a <printf>
  printf(s);
    80000564:	8526                	mv	a0,s1
    80000566:	00000097          	auipc	ra,0x0
    8000056a:	024080e7          	jalr	36(ra) # 8000058a <printf>
  printf("\n");
    8000056e:	00008517          	auipc	a0,0x8
    80000572:	b5a50513          	addi	a0,a0,-1190 # 800080c8 <digits+0x88>
    80000576:	00000097          	auipc	ra,0x0
    8000057a:	014080e7          	jalr	20(ra) # 8000058a <printf>
  panicked = 1; // freeze uart output from other CPUs
    8000057e:	4785                	li	a5,1
    80000580:	00008717          	auipc	a4,0x8
    80000584:	3af72023          	sw	a5,928(a4) # 80008920 <panicked>
  for(;;)
    80000588:	a001                	j	80000588 <panic+0x48>

000000008000058a <printf>:
{
    8000058a:	7131                	addi	sp,sp,-192
    8000058c:	fc86                	sd	ra,120(sp)
    8000058e:	f8a2                	sd	s0,112(sp)
    80000590:	f4a6                	sd	s1,104(sp)
    80000592:	f0ca                	sd	s2,96(sp)
    80000594:	ecce                	sd	s3,88(sp)
    80000596:	e8d2                	sd	s4,80(sp)
    80000598:	e4d6                	sd	s5,72(sp)
    8000059a:	e0da                	sd	s6,64(sp)
    8000059c:	fc5e                	sd	s7,56(sp)
    8000059e:	f862                	sd	s8,48(sp)
    800005a0:	f466                	sd	s9,40(sp)
    800005a2:	f06a                	sd	s10,32(sp)
    800005a4:	ec6e                	sd	s11,24(sp)
    800005a6:	0100                	addi	s0,sp,128
    800005a8:	8a2a                	mv	s4,a0
    800005aa:	e40c                	sd	a1,8(s0)
    800005ac:	e810                	sd	a2,16(s0)
    800005ae:	ec14                	sd	a3,24(s0)
    800005b0:	f018                	sd	a4,32(s0)
    800005b2:	f41c                	sd	a5,40(s0)
    800005b4:	03043823          	sd	a6,48(s0)
    800005b8:	03143c23          	sd	a7,56(s0)
  locking = pr.locking;
    800005bc:	00010d97          	auipc	s11,0x10
    800005c0:	5b4dad83          	lw	s11,1460(s11) # 80010b70 <pr+0x18>
  if(locking)
    800005c4:	020d9b63          	bnez	s11,800005fa <printf+0x70>
  if (fmt == 0)
    800005c8:	040a0263          	beqz	s4,8000060c <printf+0x82>
  va_start(ap, fmt);
    800005cc:	00840793          	addi	a5,s0,8
    800005d0:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    800005d4:	000a4503          	lbu	a0,0(s4)
    800005d8:	14050f63          	beqz	a0,80000736 <printf+0x1ac>
    800005dc:	4981                	li	s3,0
    if(c != '%'){
    800005de:	02500a93          	li	s5,37
    switch(c){
    800005e2:	07000b93          	li	s7,112
  consputc('x');
    800005e6:	4d41                	li	s10,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800005e8:	00008b17          	auipc	s6,0x8
    800005ec:	a58b0b13          	addi	s6,s6,-1448 # 80008040 <digits>
    switch(c){
    800005f0:	07300c93          	li	s9,115
    800005f4:	06400c13          	li	s8,100
    800005f8:	a82d                	j	80000632 <printf+0xa8>
    acquire(&pr.lock);
    800005fa:	00010517          	auipc	a0,0x10
    800005fe:	55e50513          	addi	a0,a0,1374 # 80010b58 <pr>
    80000602:	00000097          	auipc	ra,0x0
    80000606:	5d4080e7          	jalr	1492(ra) # 80000bd6 <acquire>
    8000060a:	bf7d                	j	800005c8 <printf+0x3e>
    panic("null fmt");
    8000060c:	00008517          	auipc	a0,0x8
    80000610:	a1c50513          	addi	a0,a0,-1508 # 80008028 <etext+0x28>
    80000614:	00000097          	auipc	ra,0x0
    80000618:	f2c080e7          	jalr	-212(ra) # 80000540 <panic>
      consputc(c);
    8000061c:	00000097          	auipc	ra,0x0
    80000620:	c60080e7          	jalr	-928(ra) # 8000027c <consputc>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    80000624:	2985                	addiw	s3,s3,1
    80000626:	013a07b3          	add	a5,s4,s3
    8000062a:	0007c503          	lbu	a0,0(a5)
    8000062e:	10050463          	beqz	a0,80000736 <printf+0x1ac>
    if(c != '%'){
    80000632:	ff5515e3          	bne	a0,s5,8000061c <printf+0x92>
    c = fmt[++i] & 0xff;
    80000636:	2985                	addiw	s3,s3,1
    80000638:	013a07b3          	add	a5,s4,s3
    8000063c:	0007c783          	lbu	a5,0(a5)
    80000640:	0007849b          	sext.w	s1,a5
    if(c == 0)
    80000644:	cbed                	beqz	a5,80000736 <printf+0x1ac>
    switch(c){
    80000646:	05778a63          	beq	a5,s7,8000069a <printf+0x110>
    8000064a:	02fbf663          	bgeu	s7,a5,80000676 <printf+0xec>
    8000064e:	09978863          	beq	a5,s9,800006de <printf+0x154>
    80000652:	07800713          	li	a4,120
    80000656:	0ce79563          	bne	a5,a4,80000720 <printf+0x196>
      printint(va_arg(ap, int), 16, 1);
    8000065a:	f8843783          	ld	a5,-120(s0)
    8000065e:	00878713          	addi	a4,a5,8
    80000662:	f8e43423          	sd	a4,-120(s0)
    80000666:	4605                	li	a2,1
    80000668:	85ea                	mv	a1,s10
    8000066a:	4388                	lw	a0,0(a5)
    8000066c:	00000097          	auipc	ra,0x0
    80000670:	e30080e7          	jalr	-464(ra) # 8000049c <printint>
      break;
    80000674:	bf45                	j	80000624 <printf+0x9a>
    switch(c){
    80000676:	09578f63          	beq	a5,s5,80000714 <printf+0x18a>
    8000067a:	0b879363          	bne	a5,s8,80000720 <printf+0x196>
      printint(va_arg(ap, int), 10, 1);
    8000067e:	f8843783          	ld	a5,-120(s0)
    80000682:	00878713          	addi	a4,a5,8
    80000686:	f8e43423          	sd	a4,-120(s0)
    8000068a:	4605                	li	a2,1
    8000068c:	45a9                	li	a1,10
    8000068e:	4388                	lw	a0,0(a5)
    80000690:	00000097          	auipc	ra,0x0
    80000694:	e0c080e7          	jalr	-500(ra) # 8000049c <printint>
      break;
    80000698:	b771                	j	80000624 <printf+0x9a>
      printptr(va_arg(ap, uint64));
    8000069a:	f8843783          	ld	a5,-120(s0)
    8000069e:	00878713          	addi	a4,a5,8
    800006a2:	f8e43423          	sd	a4,-120(s0)
    800006a6:	0007b903          	ld	s2,0(a5)
  consputc('0');
    800006aa:	03000513          	li	a0,48
    800006ae:	00000097          	auipc	ra,0x0
    800006b2:	bce080e7          	jalr	-1074(ra) # 8000027c <consputc>
  consputc('x');
    800006b6:	07800513          	li	a0,120
    800006ba:	00000097          	auipc	ra,0x0
    800006be:	bc2080e7          	jalr	-1086(ra) # 8000027c <consputc>
    800006c2:	84ea                	mv	s1,s10
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006c4:	03c95793          	srli	a5,s2,0x3c
    800006c8:	97da                	add	a5,a5,s6
    800006ca:	0007c503          	lbu	a0,0(a5)
    800006ce:	00000097          	auipc	ra,0x0
    800006d2:	bae080e7          	jalr	-1106(ra) # 8000027c <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006d6:	0912                	slli	s2,s2,0x4
    800006d8:	34fd                	addiw	s1,s1,-1
    800006da:	f4ed                	bnez	s1,800006c4 <printf+0x13a>
    800006dc:	b7a1                	j	80000624 <printf+0x9a>
      if((s = va_arg(ap, char*)) == 0)
    800006de:	f8843783          	ld	a5,-120(s0)
    800006e2:	00878713          	addi	a4,a5,8
    800006e6:	f8e43423          	sd	a4,-120(s0)
    800006ea:	6384                	ld	s1,0(a5)
    800006ec:	cc89                	beqz	s1,80000706 <printf+0x17c>
      for(; *s; s++)
    800006ee:	0004c503          	lbu	a0,0(s1)
    800006f2:	d90d                	beqz	a0,80000624 <printf+0x9a>
        consputc(*s);
    800006f4:	00000097          	auipc	ra,0x0
    800006f8:	b88080e7          	jalr	-1144(ra) # 8000027c <consputc>
      for(; *s; s++)
    800006fc:	0485                	addi	s1,s1,1
    800006fe:	0004c503          	lbu	a0,0(s1)
    80000702:	f96d                	bnez	a0,800006f4 <printf+0x16a>
    80000704:	b705                	j	80000624 <printf+0x9a>
        s = "(null)";
    80000706:	00008497          	auipc	s1,0x8
    8000070a:	91a48493          	addi	s1,s1,-1766 # 80008020 <etext+0x20>
      for(; *s; s++)
    8000070e:	02800513          	li	a0,40
    80000712:	b7cd                	j	800006f4 <printf+0x16a>
      consputc('%');
    80000714:	8556                	mv	a0,s5
    80000716:	00000097          	auipc	ra,0x0
    8000071a:	b66080e7          	jalr	-1178(ra) # 8000027c <consputc>
      break;
    8000071e:	b719                	j	80000624 <printf+0x9a>
      consputc('%');
    80000720:	8556                	mv	a0,s5
    80000722:	00000097          	auipc	ra,0x0
    80000726:	b5a080e7          	jalr	-1190(ra) # 8000027c <consputc>
      consputc(c);
    8000072a:	8526                	mv	a0,s1
    8000072c:	00000097          	auipc	ra,0x0
    80000730:	b50080e7          	jalr	-1200(ra) # 8000027c <consputc>
      break;
    80000734:	bdc5                	j	80000624 <printf+0x9a>
  if(locking)
    80000736:	020d9163          	bnez	s11,80000758 <printf+0x1ce>
}
    8000073a:	70e6                	ld	ra,120(sp)
    8000073c:	7446                	ld	s0,112(sp)
    8000073e:	74a6                	ld	s1,104(sp)
    80000740:	7906                	ld	s2,96(sp)
    80000742:	69e6                	ld	s3,88(sp)
    80000744:	6a46                	ld	s4,80(sp)
    80000746:	6aa6                	ld	s5,72(sp)
    80000748:	6b06                	ld	s6,64(sp)
    8000074a:	7be2                	ld	s7,56(sp)
    8000074c:	7c42                	ld	s8,48(sp)
    8000074e:	7ca2                	ld	s9,40(sp)
    80000750:	7d02                	ld	s10,32(sp)
    80000752:	6de2                	ld	s11,24(sp)
    80000754:	6129                	addi	sp,sp,192
    80000756:	8082                	ret
    release(&pr.lock);
    80000758:	00010517          	auipc	a0,0x10
    8000075c:	40050513          	addi	a0,a0,1024 # 80010b58 <pr>
    80000760:	00000097          	auipc	ra,0x0
    80000764:	52a080e7          	jalr	1322(ra) # 80000c8a <release>
}
    80000768:	bfc9                	j	8000073a <printf+0x1b0>

000000008000076a <printfinit>:
    ;
}

void
printfinit(void)
{
    8000076a:	1101                	addi	sp,sp,-32
    8000076c:	ec06                	sd	ra,24(sp)
    8000076e:	e822                	sd	s0,16(sp)
    80000770:	e426                	sd	s1,8(sp)
    80000772:	1000                	addi	s0,sp,32
  initlock(&pr.lock, "pr");
    80000774:	00010497          	auipc	s1,0x10
    80000778:	3e448493          	addi	s1,s1,996 # 80010b58 <pr>
    8000077c:	00008597          	auipc	a1,0x8
    80000780:	8bc58593          	addi	a1,a1,-1860 # 80008038 <etext+0x38>
    80000784:	8526                	mv	a0,s1
    80000786:	00000097          	auipc	ra,0x0
    8000078a:	3c0080e7          	jalr	960(ra) # 80000b46 <initlock>
  pr.locking = 1;
    8000078e:	4785                	li	a5,1
    80000790:	cc9c                	sw	a5,24(s1)
}
    80000792:	60e2                	ld	ra,24(sp)
    80000794:	6442                	ld	s0,16(sp)
    80000796:	64a2                	ld	s1,8(sp)
    80000798:	6105                	addi	sp,sp,32
    8000079a:	8082                	ret

000000008000079c <uartinit>:

void uartstart();

void
uartinit(void)
{
    8000079c:	1141                	addi	sp,sp,-16
    8000079e:	e406                	sd	ra,8(sp)
    800007a0:	e022                	sd	s0,0(sp)
    800007a2:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    800007a4:	100007b7          	lui	a5,0x10000
    800007a8:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800007ac:	f8000713          	li	a4,-128
    800007b0:	00e781a3          	sb	a4,3(a5)

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800007b4:	470d                	li	a4,3
    800007b6:	00e78023          	sb	a4,0(a5)

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800007ba:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800007be:	00e781a3          	sb	a4,3(a5)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800007c2:	469d                	li	a3,7
    800007c4:	00d78123          	sb	a3,2(a5)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800007c8:	00e780a3          	sb	a4,1(a5)

  initlock(&uart_tx_lock, "uart");
    800007cc:	00008597          	auipc	a1,0x8
    800007d0:	88c58593          	addi	a1,a1,-1908 # 80008058 <digits+0x18>
    800007d4:	00010517          	auipc	a0,0x10
    800007d8:	3a450513          	addi	a0,a0,932 # 80010b78 <uart_tx_lock>
    800007dc:	00000097          	auipc	ra,0x0
    800007e0:	36a080e7          	jalr	874(ra) # 80000b46 <initlock>
}
    800007e4:	60a2                	ld	ra,8(sp)
    800007e6:	6402                	ld	s0,0(sp)
    800007e8:	0141                	addi	sp,sp,16
    800007ea:	8082                	ret

00000000800007ec <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800007ec:	1101                	addi	sp,sp,-32
    800007ee:	ec06                	sd	ra,24(sp)
    800007f0:	e822                	sd	s0,16(sp)
    800007f2:	e426                	sd	s1,8(sp)
    800007f4:	1000                	addi	s0,sp,32
    800007f6:	84aa                	mv	s1,a0
  push_off();
    800007f8:	00000097          	auipc	ra,0x0
    800007fc:	392080e7          	jalr	914(ra) # 80000b8a <push_off>

  if(panicked){
    80000800:	00008797          	auipc	a5,0x8
    80000804:	1207a783          	lw	a5,288(a5) # 80008920 <panicked>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80000808:	10000737          	lui	a4,0x10000
  if(panicked){
    8000080c:	c391                	beqz	a5,80000810 <uartputc_sync+0x24>
    for(;;)
    8000080e:	a001                	j	8000080e <uartputc_sync+0x22>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80000810:	00574783          	lbu	a5,5(a4) # 10000005 <_entry-0x6ffffffb>
    80000814:	0207f793          	andi	a5,a5,32
    80000818:	dfe5                	beqz	a5,80000810 <uartputc_sync+0x24>
    ;
  WriteReg(THR, c);
    8000081a:	0ff4f513          	zext.b	a0,s1
    8000081e:	100007b7          	lui	a5,0x10000
    80000822:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    80000826:	00000097          	auipc	ra,0x0
    8000082a:	404080e7          	jalr	1028(ra) # 80000c2a <pop_off>
}
    8000082e:	60e2                	ld	ra,24(sp)
    80000830:	6442                	ld	s0,16(sp)
    80000832:	64a2                	ld	s1,8(sp)
    80000834:	6105                	addi	sp,sp,32
    80000836:	8082                	ret

0000000080000838 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    80000838:	00008797          	auipc	a5,0x8
    8000083c:	0f07b783          	ld	a5,240(a5) # 80008928 <uart_tx_r>
    80000840:	00008717          	auipc	a4,0x8
    80000844:	0f073703          	ld	a4,240(a4) # 80008930 <uart_tx_w>
    80000848:	06f70a63          	beq	a4,a5,800008bc <uartstart+0x84>
{
    8000084c:	7139                	addi	sp,sp,-64
    8000084e:	fc06                	sd	ra,56(sp)
    80000850:	f822                	sd	s0,48(sp)
    80000852:	f426                	sd	s1,40(sp)
    80000854:	f04a                	sd	s2,32(sp)
    80000856:	ec4e                	sd	s3,24(sp)
    80000858:	e852                	sd	s4,16(sp)
    8000085a:	e456                	sd	s5,8(sp)
    8000085c:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000085e:	10000937          	lui	s2,0x10000
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80000862:	00010a17          	auipc	s4,0x10
    80000866:	316a0a13          	addi	s4,s4,790 # 80010b78 <uart_tx_lock>
    uart_tx_r += 1;
    8000086a:	00008497          	auipc	s1,0x8
    8000086e:	0be48493          	addi	s1,s1,190 # 80008928 <uart_tx_r>
    if(uart_tx_w == uart_tx_r){
    80000872:	00008997          	auipc	s3,0x8
    80000876:	0be98993          	addi	s3,s3,190 # 80008930 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000087a:	00594703          	lbu	a4,5(s2) # 10000005 <_entry-0x6ffffffb>
    8000087e:	02077713          	andi	a4,a4,32
    80000882:	c705                	beqz	a4,800008aa <uartstart+0x72>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80000884:	01f7f713          	andi	a4,a5,31
    80000888:	9752                	add	a4,a4,s4
    8000088a:	01874a83          	lbu	s5,24(a4)
    uart_tx_r += 1;
    8000088e:	0785                	addi	a5,a5,1
    80000890:	e09c                	sd	a5,0(s1)
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    80000892:	8526                	mv	a0,s1
    80000894:	00002097          	auipc	ra,0x2
    80000898:	9fc080e7          	jalr	-1540(ra) # 80002290 <wakeup>
    
    WriteReg(THR, c);
    8000089c:	01590023          	sb	s5,0(s2)
    if(uart_tx_w == uart_tx_r){
    800008a0:	609c                	ld	a5,0(s1)
    800008a2:	0009b703          	ld	a4,0(s3)
    800008a6:	fcf71ae3          	bne	a4,a5,8000087a <uartstart+0x42>
  }
}
    800008aa:	70e2                	ld	ra,56(sp)
    800008ac:	7442                	ld	s0,48(sp)
    800008ae:	74a2                	ld	s1,40(sp)
    800008b0:	7902                	ld	s2,32(sp)
    800008b2:	69e2                	ld	s3,24(sp)
    800008b4:	6a42                	ld	s4,16(sp)
    800008b6:	6aa2                	ld	s5,8(sp)
    800008b8:	6121                	addi	sp,sp,64
    800008ba:	8082                	ret
    800008bc:	8082                	ret

00000000800008be <uartputc>:
{
    800008be:	7179                	addi	sp,sp,-48
    800008c0:	f406                	sd	ra,40(sp)
    800008c2:	f022                	sd	s0,32(sp)
    800008c4:	ec26                	sd	s1,24(sp)
    800008c6:	e84a                	sd	s2,16(sp)
    800008c8:	e44e                	sd	s3,8(sp)
    800008ca:	e052                	sd	s4,0(sp)
    800008cc:	1800                	addi	s0,sp,48
    800008ce:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    800008d0:	00010517          	auipc	a0,0x10
    800008d4:	2a850513          	addi	a0,a0,680 # 80010b78 <uart_tx_lock>
    800008d8:	00000097          	auipc	ra,0x0
    800008dc:	2fe080e7          	jalr	766(ra) # 80000bd6 <acquire>
  if(panicked){
    800008e0:	00008797          	auipc	a5,0x8
    800008e4:	0407a783          	lw	a5,64(a5) # 80008920 <panicked>
    800008e8:	e7c9                	bnez	a5,80000972 <uartputc+0xb4>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800008ea:	00008717          	auipc	a4,0x8
    800008ee:	04673703          	ld	a4,70(a4) # 80008930 <uart_tx_w>
    800008f2:	00008797          	auipc	a5,0x8
    800008f6:	0367b783          	ld	a5,54(a5) # 80008928 <uart_tx_r>
    800008fa:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800008fe:	00010997          	auipc	s3,0x10
    80000902:	27a98993          	addi	s3,s3,634 # 80010b78 <uart_tx_lock>
    80000906:	00008497          	auipc	s1,0x8
    8000090a:	02248493          	addi	s1,s1,34 # 80008928 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000090e:	00008917          	auipc	s2,0x8
    80000912:	02290913          	addi	s2,s2,34 # 80008930 <uart_tx_w>
    80000916:	00e79f63          	bne	a5,a4,80000934 <uartputc+0x76>
    sleep(&uart_tx_r, &uart_tx_lock);
    8000091a:	85ce                	mv	a1,s3
    8000091c:	8526                	mv	a0,s1
    8000091e:	00002097          	auipc	ra,0x2
    80000922:	90e080e7          	jalr	-1778(ra) # 8000222c <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80000926:	00093703          	ld	a4,0(s2)
    8000092a:	609c                	ld	a5,0(s1)
    8000092c:	02078793          	addi	a5,a5,32
    80000930:	fee785e3          	beq	a5,a4,8000091a <uartputc+0x5c>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    80000934:	00010497          	auipc	s1,0x10
    80000938:	24448493          	addi	s1,s1,580 # 80010b78 <uart_tx_lock>
    8000093c:	01f77793          	andi	a5,a4,31
    80000940:	97a6                	add	a5,a5,s1
    80000942:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    80000946:	0705                	addi	a4,a4,1
    80000948:	00008797          	auipc	a5,0x8
    8000094c:	fee7b423          	sd	a4,-24(a5) # 80008930 <uart_tx_w>
  uartstart();
    80000950:	00000097          	auipc	ra,0x0
    80000954:	ee8080e7          	jalr	-280(ra) # 80000838 <uartstart>
  release(&uart_tx_lock);
    80000958:	8526                	mv	a0,s1
    8000095a:	00000097          	auipc	ra,0x0
    8000095e:	330080e7          	jalr	816(ra) # 80000c8a <release>
}
    80000962:	70a2                	ld	ra,40(sp)
    80000964:	7402                	ld	s0,32(sp)
    80000966:	64e2                	ld	s1,24(sp)
    80000968:	6942                	ld	s2,16(sp)
    8000096a:	69a2                	ld	s3,8(sp)
    8000096c:	6a02                	ld	s4,0(sp)
    8000096e:	6145                	addi	sp,sp,48
    80000970:	8082                	ret
    for(;;)
    80000972:	a001                	j	80000972 <uartputc+0xb4>

0000000080000974 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80000974:	1141                	addi	sp,sp,-16
    80000976:	e422                	sd	s0,8(sp)
    80000978:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    8000097a:	100007b7          	lui	a5,0x10000
    8000097e:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000982:	8b85                	andi	a5,a5,1
    80000984:	cb81                	beqz	a5,80000994 <uartgetc+0x20>
    // input data is ready.
    return ReadReg(RHR);
    80000986:	100007b7          	lui	a5,0x10000
    8000098a:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    8000098e:	6422                	ld	s0,8(sp)
    80000990:	0141                	addi	sp,sp,16
    80000992:	8082                	ret
    return -1;
    80000994:	557d                	li	a0,-1
    80000996:	bfe5                	j	8000098e <uartgetc+0x1a>

0000000080000998 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80000998:	1101                	addi	sp,sp,-32
    8000099a:	ec06                	sd	ra,24(sp)
    8000099c:	e822                	sd	s0,16(sp)
    8000099e:	e426                	sd	s1,8(sp)
    800009a0:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    800009a2:	54fd                	li	s1,-1
    800009a4:	a029                	j	800009ae <uartintr+0x16>
      break;
    consoleintr(c);
    800009a6:	00000097          	auipc	ra,0x0
    800009aa:	918080e7          	jalr	-1768(ra) # 800002be <consoleintr>
    int c = uartgetc();
    800009ae:	00000097          	auipc	ra,0x0
    800009b2:	fc6080e7          	jalr	-58(ra) # 80000974 <uartgetc>
    if(c == -1)
    800009b6:	fe9518e3          	bne	a0,s1,800009a6 <uartintr+0xe>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    800009ba:	00010497          	auipc	s1,0x10
    800009be:	1be48493          	addi	s1,s1,446 # 80010b78 <uart_tx_lock>
    800009c2:	8526                	mv	a0,s1
    800009c4:	00000097          	auipc	ra,0x0
    800009c8:	212080e7          	jalr	530(ra) # 80000bd6 <acquire>
  uartstart();
    800009cc:	00000097          	auipc	ra,0x0
    800009d0:	e6c080e7          	jalr	-404(ra) # 80000838 <uartstart>
  release(&uart_tx_lock);
    800009d4:	8526                	mv	a0,s1
    800009d6:	00000097          	auipc	ra,0x0
    800009da:	2b4080e7          	jalr	692(ra) # 80000c8a <release>
}
    800009de:	60e2                	ld	ra,24(sp)
    800009e0:	6442                	ld	s0,16(sp)
    800009e2:	64a2                	ld	s1,8(sp)
    800009e4:	6105                	addi	sp,sp,32
    800009e6:	8082                	ret

00000000800009e8 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    800009e8:	1101                	addi	sp,sp,-32
    800009ea:	ec06                	sd	ra,24(sp)
    800009ec:	e822                	sd	s0,16(sp)
    800009ee:	e426                	sd	s1,8(sp)
    800009f0:	e04a                	sd	s2,0(sp)
    800009f2:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    800009f4:	03451793          	slli	a5,a0,0x34
    800009f8:	ebb9                	bnez	a5,80000a4e <kfree+0x66>
    800009fa:	84aa                	mv	s1,a0
    800009fc:	00022797          	auipc	a5,0x22
    80000a00:	86478793          	addi	a5,a5,-1948 # 80022260 <end>
    80000a04:	04f56563          	bltu	a0,a5,80000a4e <kfree+0x66>
    80000a08:	47c5                	li	a5,17
    80000a0a:	07ee                	slli	a5,a5,0x1b
    80000a0c:	04f57163          	bgeu	a0,a5,80000a4e <kfree+0x66>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a10:	6605                	lui	a2,0x1
    80000a12:	4585                	li	a1,1
    80000a14:	00000097          	auipc	ra,0x0
    80000a18:	2be080e7          	jalr	702(ra) # 80000cd2 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a1c:	00010917          	auipc	s2,0x10
    80000a20:	19490913          	addi	s2,s2,404 # 80010bb0 <kmem>
    80000a24:	854a                	mv	a0,s2
    80000a26:	00000097          	auipc	ra,0x0
    80000a2a:	1b0080e7          	jalr	432(ra) # 80000bd6 <acquire>
  r->next = kmem.freelist;
    80000a2e:	01893783          	ld	a5,24(s2)
    80000a32:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a34:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a38:	854a                	mv	a0,s2
    80000a3a:	00000097          	auipc	ra,0x0
    80000a3e:	250080e7          	jalr	592(ra) # 80000c8a <release>
}
    80000a42:	60e2                	ld	ra,24(sp)
    80000a44:	6442                	ld	s0,16(sp)
    80000a46:	64a2                	ld	s1,8(sp)
    80000a48:	6902                	ld	s2,0(sp)
    80000a4a:	6105                	addi	sp,sp,32
    80000a4c:	8082                	ret
    panic("kfree");
    80000a4e:	00007517          	auipc	a0,0x7
    80000a52:	61250513          	addi	a0,a0,1554 # 80008060 <digits+0x20>
    80000a56:	00000097          	auipc	ra,0x0
    80000a5a:	aea080e7          	jalr	-1302(ra) # 80000540 <panic>

0000000080000a5e <freerange>:
{
    80000a5e:	7179                	addi	sp,sp,-48
    80000a60:	f406                	sd	ra,40(sp)
    80000a62:	f022                	sd	s0,32(sp)
    80000a64:	ec26                	sd	s1,24(sp)
    80000a66:	e84a                	sd	s2,16(sp)
    80000a68:	e44e                	sd	s3,8(sp)
    80000a6a:	e052                	sd	s4,0(sp)
    80000a6c:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000a6e:	6785                	lui	a5,0x1
    80000a70:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000a74:	00e504b3          	add	s1,a0,a4
    80000a78:	777d                	lui	a4,0xfffff
    80000a7a:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a7c:	94be                	add	s1,s1,a5
    80000a7e:	0095ee63          	bltu	a1,s1,80000a9a <freerange+0x3c>
    80000a82:	892e                	mv	s2,a1
    kfree(p);
    80000a84:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a86:	6985                	lui	s3,0x1
    kfree(p);
    80000a88:	01448533          	add	a0,s1,s4
    80000a8c:	00000097          	auipc	ra,0x0
    80000a90:	f5c080e7          	jalr	-164(ra) # 800009e8 <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a94:	94ce                	add	s1,s1,s3
    80000a96:	fe9979e3          	bgeu	s2,s1,80000a88 <freerange+0x2a>
}
    80000a9a:	70a2                	ld	ra,40(sp)
    80000a9c:	7402                	ld	s0,32(sp)
    80000a9e:	64e2                	ld	s1,24(sp)
    80000aa0:	6942                	ld	s2,16(sp)
    80000aa2:	69a2                	ld	s3,8(sp)
    80000aa4:	6a02                	ld	s4,0(sp)
    80000aa6:	6145                	addi	sp,sp,48
    80000aa8:	8082                	ret

0000000080000aaa <kinit>:
{
    80000aaa:	1141                	addi	sp,sp,-16
    80000aac:	e406                	sd	ra,8(sp)
    80000aae:	e022                	sd	s0,0(sp)
    80000ab0:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000ab2:	00007597          	auipc	a1,0x7
    80000ab6:	5b658593          	addi	a1,a1,1462 # 80008068 <digits+0x28>
    80000aba:	00010517          	auipc	a0,0x10
    80000abe:	0f650513          	addi	a0,a0,246 # 80010bb0 <kmem>
    80000ac2:	00000097          	auipc	ra,0x0
    80000ac6:	084080e7          	jalr	132(ra) # 80000b46 <initlock>
  freerange(end, (void*)PHYSTOP);
    80000aca:	45c5                	li	a1,17
    80000acc:	05ee                	slli	a1,a1,0x1b
    80000ace:	00021517          	auipc	a0,0x21
    80000ad2:	79250513          	addi	a0,a0,1938 # 80022260 <end>
    80000ad6:	00000097          	auipc	ra,0x0
    80000ada:	f88080e7          	jalr	-120(ra) # 80000a5e <freerange>
}
    80000ade:	60a2                	ld	ra,8(sp)
    80000ae0:	6402                	ld	s0,0(sp)
    80000ae2:	0141                	addi	sp,sp,16
    80000ae4:	8082                	ret

0000000080000ae6 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000ae6:	1101                	addi	sp,sp,-32
    80000ae8:	ec06                	sd	ra,24(sp)
    80000aea:	e822                	sd	s0,16(sp)
    80000aec:	e426                	sd	s1,8(sp)
    80000aee:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000af0:	00010497          	auipc	s1,0x10
    80000af4:	0c048493          	addi	s1,s1,192 # 80010bb0 <kmem>
    80000af8:	8526                	mv	a0,s1
    80000afa:	00000097          	auipc	ra,0x0
    80000afe:	0dc080e7          	jalr	220(ra) # 80000bd6 <acquire>
  r = kmem.freelist;
    80000b02:	6c84                	ld	s1,24(s1)
  if(r)
    80000b04:	c885                	beqz	s1,80000b34 <kalloc+0x4e>
    kmem.freelist = r->next;
    80000b06:	609c                	ld	a5,0(s1)
    80000b08:	00010517          	auipc	a0,0x10
    80000b0c:	0a850513          	addi	a0,a0,168 # 80010bb0 <kmem>
    80000b10:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000b12:	00000097          	auipc	ra,0x0
    80000b16:	178080e7          	jalr	376(ra) # 80000c8a <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b1a:	6605                	lui	a2,0x1
    80000b1c:	4595                	li	a1,5
    80000b1e:	8526                	mv	a0,s1
    80000b20:	00000097          	auipc	ra,0x0
    80000b24:	1b2080e7          	jalr	434(ra) # 80000cd2 <memset>
  return (void*)r;
}
    80000b28:	8526                	mv	a0,s1
    80000b2a:	60e2                	ld	ra,24(sp)
    80000b2c:	6442                	ld	s0,16(sp)
    80000b2e:	64a2                	ld	s1,8(sp)
    80000b30:	6105                	addi	sp,sp,32
    80000b32:	8082                	ret
  release(&kmem.lock);
    80000b34:	00010517          	auipc	a0,0x10
    80000b38:	07c50513          	addi	a0,a0,124 # 80010bb0 <kmem>
    80000b3c:	00000097          	auipc	ra,0x0
    80000b40:	14e080e7          	jalr	334(ra) # 80000c8a <release>
  if(r)
    80000b44:	b7d5                	j	80000b28 <kalloc+0x42>

0000000080000b46 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b46:	1141                	addi	sp,sp,-16
    80000b48:	e422                	sd	s0,8(sp)
    80000b4a:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b4c:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b4e:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b52:	00053823          	sd	zero,16(a0)
}
    80000b56:	6422                	ld	s0,8(sp)
    80000b58:	0141                	addi	sp,sp,16
    80000b5a:	8082                	ret

0000000080000b5c <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b5c:	411c                	lw	a5,0(a0)
    80000b5e:	e399                	bnez	a5,80000b64 <holding+0x8>
    80000b60:	4501                	li	a0,0
  return r;
}
    80000b62:	8082                	ret
{
    80000b64:	1101                	addi	sp,sp,-32
    80000b66:	ec06                	sd	ra,24(sp)
    80000b68:	e822                	sd	s0,16(sp)
    80000b6a:	e426                	sd	s1,8(sp)
    80000b6c:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b6e:	6904                	ld	s1,16(a0)
    80000b70:	00001097          	auipc	ra,0x1
    80000b74:	f0a080e7          	jalr	-246(ra) # 80001a7a <mycpu>
    80000b78:	40a48533          	sub	a0,s1,a0
    80000b7c:	00153513          	seqz	a0,a0
}
    80000b80:	60e2                	ld	ra,24(sp)
    80000b82:	6442                	ld	s0,16(sp)
    80000b84:	64a2                	ld	s1,8(sp)
    80000b86:	6105                	addi	sp,sp,32
    80000b88:	8082                	ret

0000000080000b8a <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000b8a:	1101                	addi	sp,sp,-32
    80000b8c:	ec06                	sd	ra,24(sp)
    80000b8e:	e822                	sd	s0,16(sp)
    80000b90:	e426                	sd	s1,8(sp)
    80000b92:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000b94:	100024f3          	csrr	s1,sstatus
    80000b98:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000b9c:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000b9e:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    80000ba2:	00001097          	auipc	ra,0x1
    80000ba6:	ed8080e7          	jalr	-296(ra) # 80001a7a <mycpu>
    80000baa:	5d3c                	lw	a5,120(a0)
    80000bac:	cf89                	beqz	a5,80000bc6 <push_off+0x3c>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000bae:	00001097          	auipc	ra,0x1
    80000bb2:	ecc080e7          	jalr	-308(ra) # 80001a7a <mycpu>
    80000bb6:	5d3c                	lw	a5,120(a0)
    80000bb8:	2785                	addiw	a5,a5,1
    80000bba:	dd3c                	sw	a5,120(a0)
}
    80000bbc:	60e2                	ld	ra,24(sp)
    80000bbe:	6442                	ld	s0,16(sp)
    80000bc0:	64a2                	ld	s1,8(sp)
    80000bc2:	6105                	addi	sp,sp,32
    80000bc4:	8082                	ret
    mycpu()->intena = old;
    80000bc6:	00001097          	auipc	ra,0x1
    80000bca:	eb4080e7          	jalr	-332(ra) # 80001a7a <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000bce:	8085                	srli	s1,s1,0x1
    80000bd0:	8885                	andi	s1,s1,1
    80000bd2:	dd64                	sw	s1,124(a0)
    80000bd4:	bfe9                	j	80000bae <push_off+0x24>

0000000080000bd6 <acquire>:
{
    80000bd6:	1101                	addi	sp,sp,-32
    80000bd8:	ec06                	sd	ra,24(sp)
    80000bda:	e822                	sd	s0,16(sp)
    80000bdc:	e426                	sd	s1,8(sp)
    80000bde:	1000                	addi	s0,sp,32
    80000be0:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000be2:	00000097          	auipc	ra,0x0
    80000be6:	fa8080e7          	jalr	-88(ra) # 80000b8a <push_off>
  if(holding(lk))
    80000bea:	8526                	mv	a0,s1
    80000bec:	00000097          	auipc	ra,0x0
    80000bf0:	f70080e7          	jalr	-144(ra) # 80000b5c <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000bf4:	4705                	li	a4,1
  if(holding(lk))
    80000bf6:	e115                	bnez	a0,80000c1a <acquire+0x44>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000bf8:	87ba                	mv	a5,a4
    80000bfa:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000bfe:	2781                	sext.w	a5,a5
    80000c00:	ffe5                	bnez	a5,80000bf8 <acquire+0x22>
  __sync_synchronize();
    80000c02:	0ff0000f          	fence
  lk->cpu = mycpu();
    80000c06:	00001097          	auipc	ra,0x1
    80000c0a:	e74080e7          	jalr	-396(ra) # 80001a7a <mycpu>
    80000c0e:	e888                	sd	a0,16(s1)
}
    80000c10:	60e2                	ld	ra,24(sp)
    80000c12:	6442                	ld	s0,16(sp)
    80000c14:	64a2                	ld	s1,8(sp)
    80000c16:	6105                	addi	sp,sp,32
    80000c18:	8082                	ret
    panic("acquire");
    80000c1a:	00007517          	auipc	a0,0x7
    80000c1e:	45650513          	addi	a0,a0,1110 # 80008070 <digits+0x30>
    80000c22:	00000097          	auipc	ra,0x0
    80000c26:	91e080e7          	jalr	-1762(ra) # 80000540 <panic>

0000000080000c2a <pop_off>:

void
pop_off(void)
{
    80000c2a:	1141                	addi	sp,sp,-16
    80000c2c:	e406                	sd	ra,8(sp)
    80000c2e:	e022                	sd	s0,0(sp)
    80000c30:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c32:	00001097          	auipc	ra,0x1
    80000c36:	e48080e7          	jalr	-440(ra) # 80001a7a <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c3a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c3e:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c40:	e78d                	bnez	a5,80000c6a <pop_off+0x40>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c42:	5d3c                	lw	a5,120(a0)
    80000c44:	02f05b63          	blez	a5,80000c7a <pop_off+0x50>
    panic("pop_off");
  c->noff -= 1;
    80000c48:	37fd                	addiw	a5,a5,-1
    80000c4a:	0007871b          	sext.w	a4,a5
    80000c4e:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000c50:	eb09                	bnez	a4,80000c62 <pop_off+0x38>
    80000c52:	5d7c                	lw	a5,124(a0)
    80000c54:	c799                	beqz	a5,80000c62 <pop_off+0x38>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c56:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000c5a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c5e:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000c62:	60a2                	ld	ra,8(sp)
    80000c64:	6402                	ld	s0,0(sp)
    80000c66:	0141                	addi	sp,sp,16
    80000c68:	8082                	ret
    panic("pop_off - interruptible");
    80000c6a:	00007517          	auipc	a0,0x7
    80000c6e:	40e50513          	addi	a0,a0,1038 # 80008078 <digits+0x38>
    80000c72:	00000097          	auipc	ra,0x0
    80000c76:	8ce080e7          	jalr	-1842(ra) # 80000540 <panic>
    panic("pop_off");
    80000c7a:	00007517          	auipc	a0,0x7
    80000c7e:	41650513          	addi	a0,a0,1046 # 80008090 <digits+0x50>
    80000c82:	00000097          	auipc	ra,0x0
    80000c86:	8be080e7          	jalr	-1858(ra) # 80000540 <panic>

0000000080000c8a <release>:
{
    80000c8a:	1101                	addi	sp,sp,-32
    80000c8c:	ec06                	sd	ra,24(sp)
    80000c8e:	e822                	sd	s0,16(sp)
    80000c90:	e426                	sd	s1,8(sp)
    80000c92:	1000                	addi	s0,sp,32
    80000c94:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000c96:	00000097          	auipc	ra,0x0
    80000c9a:	ec6080e7          	jalr	-314(ra) # 80000b5c <holding>
    80000c9e:	c115                	beqz	a0,80000cc2 <release+0x38>
  lk->cpu = 0;
    80000ca0:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000ca4:	0ff0000f          	fence
  __sync_lock_release(&lk->locked);
    80000ca8:	0f50000f          	fence	iorw,ow
    80000cac:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    80000cb0:	00000097          	auipc	ra,0x0
    80000cb4:	f7a080e7          	jalr	-134(ra) # 80000c2a <pop_off>
}
    80000cb8:	60e2                	ld	ra,24(sp)
    80000cba:	6442                	ld	s0,16(sp)
    80000cbc:	64a2                	ld	s1,8(sp)
    80000cbe:	6105                	addi	sp,sp,32
    80000cc0:	8082                	ret
    panic("release");
    80000cc2:	00007517          	auipc	a0,0x7
    80000cc6:	3d650513          	addi	a0,a0,982 # 80008098 <digits+0x58>
    80000cca:	00000097          	auipc	ra,0x0
    80000cce:	876080e7          	jalr	-1930(ra) # 80000540 <panic>

0000000080000cd2 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000cd2:	1141                	addi	sp,sp,-16
    80000cd4:	e422                	sd	s0,8(sp)
    80000cd6:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000cd8:	ca19                	beqz	a2,80000cee <memset+0x1c>
    80000cda:	87aa                	mv	a5,a0
    80000cdc:	1602                	slli	a2,a2,0x20
    80000cde:	9201                	srli	a2,a2,0x20
    80000ce0:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000ce4:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000ce8:	0785                	addi	a5,a5,1
    80000cea:	fee79de3          	bne	a5,a4,80000ce4 <memset+0x12>
  }
  return dst;
}
    80000cee:	6422                	ld	s0,8(sp)
    80000cf0:	0141                	addi	sp,sp,16
    80000cf2:	8082                	ret

0000000080000cf4 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000cf4:	1141                	addi	sp,sp,-16
    80000cf6:	e422                	sd	s0,8(sp)
    80000cf8:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000cfa:	ca05                	beqz	a2,80000d2a <memcmp+0x36>
    80000cfc:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000d00:	1682                	slli	a3,a3,0x20
    80000d02:	9281                	srli	a3,a3,0x20
    80000d04:	0685                	addi	a3,a3,1
    80000d06:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000d08:	00054783          	lbu	a5,0(a0)
    80000d0c:	0005c703          	lbu	a4,0(a1)
    80000d10:	00e79863          	bne	a5,a4,80000d20 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000d14:	0505                	addi	a0,a0,1
    80000d16:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d18:	fed518e3          	bne	a0,a3,80000d08 <memcmp+0x14>
  }

  return 0;
    80000d1c:	4501                	li	a0,0
    80000d1e:	a019                	j	80000d24 <memcmp+0x30>
      return *s1 - *s2;
    80000d20:	40e7853b          	subw	a0,a5,a4
}
    80000d24:	6422                	ld	s0,8(sp)
    80000d26:	0141                	addi	sp,sp,16
    80000d28:	8082                	ret
  return 0;
    80000d2a:	4501                	li	a0,0
    80000d2c:	bfe5                	j	80000d24 <memcmp+0x30>

0000000080000d2e <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d2e:	1141                	addi	sp,sp,-16
    80000d30:	e422                	sd	s0,8(sp)
    80000d32:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d34:	c205                	beqz	a2,80000d54 <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d36:	02a5e263          	bltu	a1,a0,80000d5a <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d3a:	1602                	slli	a2,a2,0x20
    80000d3c:	9201                	srli	a2,a2,0x20
    80000d3e:	00c587b3          	add	a5,a1,a2
{
    80000d42:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d44:	0585                	addi	a1,a1,1
    80000d46:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffdcda1>
    80000d48:	fff5c683          	lbu	a3,-1(a1)
    80000d4c:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d50:	fef59ae3          	bne	a1,a5,80000d44 <memmove+0x16>

  return dst;
}
    80000d54:	6422                	ld	s0,8(sp)
    80000d56:	0141                	addi	sp,sp,16
    80000d58:	8082                	ret
  if(s < d && s + n > d){
    80000d5a:	02061693          	slli	a3,a2,0x20
    80000d5e:	9281                	srli	a3,a3,0x20
    80000d60:	00d58733          	add	a4,a1,a3
    80000d64:	fce57be3          	bgeu	a0,a4,80000d3a <memmove+0xc>
    d += n;
    80000d68:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000d6a:	fff6079b          	addiw	a5,a2,-1
    80000d6e:	1782                	slli	a5,a5,0x20
    80000d70:	9381                	srli	a5,a5,0x20
    80000d72:	fff7c793          	not	a5,a5
    80000d76:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d78:	177d                	addi	a4,a4,-1
    80000d7a:	16fd                	addi	a3,a3,-1
    80000d7c:	00074603          	lbu	a2,0(a4)
    80000d80:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000d84:	fee79ae3          	bne	a5,a4,80000d78 <memmove+0x4a>
    80000d88:	b7f1                	j	80000d54 <memmove+0x26>

0000000080000d8a <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000d8a:	1141                	addi	sp,sp,-16
    80000d8c:	e406                	sd	ra,8(sp)
    80000d8e:	e022                	sd	s0,0(sp)
    80000d90:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d92:	00000097          	auipc	ra,0x0
    80000d96:	f9c080e7          	jalr	-100(ra) # 80000d2e <memmove>
}
    80000d9a:	60a2                	ld	ra,8(sp)
    80000d9c:	6402                	ld	s0,0(sp)
    80000d9e:	0141                	addi	sp,sp,16
    80000da0:	8082                	ret

0000000080000da2 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000da2:	1141                	addi	sp,sp,-16
    80000da4:	e422                	sd	s0,8(sp)
    80000da6:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000da8:	ce11                	beqz	a2,80000dc4 <strncmp+0x22>
    80000daa:	00054783          	lbu	a5,0(a0)
    80000dae:	cf89                	beqz	a5,80000dc8 <strncmp+0x26>
    80000db0:	0005c703          	lbu	a4,0(a1)
    80000db4:	00f71a63          	bne	a4,a5,80000dc8 <strncmp+0x26>
    n--, p++, q++;
    80000db8:	367d                	addiw	a2,a2,-1
    80000dba:	0505                	addi	a0,a0,1
    80000dbc:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000dbe:	f675                	bnez	a2,80000daa <strncmp+0x8>
  if(n == 0)
    return 0;
    80000dc0:	4501                	li	a0,0
    80000dc2:	a809                	j	80000dd4 <strncmp+0x32>
    80000dc4:	4501                	li	a0,0
    80000dc6:	a039                	j	80000dd4 <strncmp+0x32>
  if(n == 0)
    80000dc8:	ca09                	beqz	a2,80000dda <strncmp+0x38>
  return (uchar)*p - (uchar)*q;
    80000dca:	00054503          	lbu	a0,0(a0)
    80000dce:	0005c783          	lbu	a5,0(a1)
    80000dd2:	9d1d                	subw	a0,a0,a5
}
    80000dd4:	6422                	ld	s0,8(sp)
    80000dd6:	0141                	addi	sp,sp,16
    80000dd8:	8082                	ret
    return 0;
    80000dda:	4501                	li	a0,0
    80000ddc:	bfe5                	j	80000dd4 <strncmp+0x32>

0000000080000dde <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000dde:	1141                	addi	sp,sp,-16
    80000de0:	e422                	sd	s0,8(sp)
    80000de2:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000de4:	872a                	mv	a4,a0
    80000de6:	8832                	mv	a6,a2
    80000de8:	367d                	addiw	a2,a2,-1
    80000dea:	01005963          	blez	a6,80000dfc <strncpy+0x1e>
    80000dee:	0705                	addi	a4,a4,1
    80000df0:	0005c783          	lbu	a5,0(a1)
    80000df4:	fef70fa3          	sb	a5,-1(a4)
    80000df8:	0585                	addi	a1,a1,1
    80000dfa:	f7f5                	bnez	a5,80000de6 <strncpy+0x8>
    ;
  while(n-- > 0)
    80000dfc:	86ba                	mv	a3,a4
    80000dfe:	00c05c63          	blez	a2,80000e16 <strncpy+0x38>
    *s++ = 0;
    80000e02:	0685                	addi	a3,a3,1
    80000e04:	fe068fa3          	sb	zero,-1(a3)
  while(n-- > 0)
    80000e08:	40d707bb          	subw	a5,a4,a3
    80000e0c:	37fd                	addiw	a5,a5,-1
    80000e0e:	010787bb          	addw	a5,a5,a6
    80000e12:	fef048e3          	bgtz	a5,80000e02 <strncpy+0x24>
  return os;
}
    80000e16:	6422                	ld	s0,8(sp)
    80000e18:	0141                	addi	sp,sp,16
    80000e1a:	8082                	ret

0000000080000e1c <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e1c:	1141                	addi	sp,sp,-16
    80000e1e:	e422                	sd	s0,8(sp)
    80000e20:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e22:	02c05363          	blez	a2,80000e48 <safestrcpy+0x2c>
    80000e26:	fff6069b          	addiw	a3,a2,-1
    80000e2a:	1682                	slli	a3,a3,0x20
    80000e2c:	9281                	srli	a3,a3,0x20
    80000e2e:	96ae                	add	a3,a3,a1
    80000e30:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e32:	00d58963          	beq	a1,a3,80000e44 <safestrcpy+0x28>
    80000e36:	0585                	addi	a1,a1,1
    80000e38:	0785                	addi	a5,a5,1
    80000e3a:	fff5c703          	lbu	a4,-1(a1)
    80000e3e:	fee78fa3          	sb	a4,-1(a5)
    80000e42:	fb65                	bnez	a4,80000e32 <safestrcpy+0x16>
    ;
  *s = 0;
    80000e44:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e48:	6422                	ld	s0,8(sp)
    80000e4a:	0141                	addi	sp,sp,16
    80000e4c:	8082                	ret

0000000080000e4e <strlen>:

int
strlen(const char *s)
{
    80000e4e:	1141                	addi	sp,sp,-16
    80000e50:	e422                	sd	s0,8(sp)
    80000e52:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e54:	00054783          	lbu	a5,0(a0)
    80000e58:	cf91                	beqz	a5,80000e74 <strlen+0x26>
    80000e5a:	0505                	addi	a0,a0,1
    80000e5c:	87aa                	mv	a5,a0
    80000e5e:	4685                	li	a3,1
    80000e60:	9e89                	subw	a3,a3,a0
    80000e62:	00f6853b          	addw	a0,a3,a5
    80000e66:	0785                	addi	a5,a5,1
    80000e68:	fff7c703          	lbu	a4,-1(a5)
    80000e6c:	fb7d                	bnez	a4,80000e62 <strlen+0x14>
    ;
  return n;
}
    80000e6e:	6422                	ld	s0,8(sp)
    80000e70:	0141                	addi	sp,sp,16
    80000e72:	8082                	ret
  for(n = 0; s[n]; n++)
    80000e74:	4501                	li	a0,0
    80000e76:	bfe5                	j	80000e6e <strlen+0x20>

0000000080000e78 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e78:	1141                	addi	sp,sp,-16
    80000e7a:	e406                	sd	ra,8(sp)
    80000e7c:	e022                	sd	s0,0(sp)
    80000e7e:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000e80:	00001097          	auipc	ra,0x1
    80000e84:	bea080e7          	jalr	-1046(ra) # 80001a6a <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000e88:	00008717          	auipc	a4,0x8
    80000e8c:	ab070713          	addi	a4,a4,-1360 # 80008938 <started>
  if(cpuid() == 0){
    80000e90:	c139                	beqz	a0,80000ed6 <main+0x5e>
    while(started == 0)
    80000e92:	431c                	lw	a5,0(a4)
    80000e94:	2781                	sext.w	a5,a5
    80000e96:	dff5                	beqz	a5,80000e92 <main+0x1a>
      ;
    __sync_synchronize();
    80000e98:	0ff0000f          	fence
    printf("hart %d starting\n", cpuid());
    80000e9c:	00001097          	auipc	ra,0x1
    80000ea0:	bce080e7          	jalr	-1074(ra) # 80001a6a <cpuid>
    80000ea4:	85aa                	mv	a1,a0
    80000ea6:	00007517          	auipc	a0,0x7
    80000eaa:	21250513          	addi	a0,a0,530 # 800080b8 <digits+0x78>
    80000eae:	fffff097          	auipc	ra,0xfffff
    80000eb2:	6dc080e7          	jalr	1756(ra) # 8000058a <printf>
    kvminithart();    // turn on paging
    80000eb6:	00000097          	auipc	ra,0x0
    80000eba:	1c2080e7          	jalr	450(ra) # 80001078 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000ebe:	00002097          	auipc	ra,0x2
    80000ec2:	964080e7          	jalr	-1692(ra) # 80002822 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000ec6:	00005097          	auipc	ra,0x5
    80000eca:	f4a080e7          	jalr	-182(ra) # 80005e10 <plicinithart>
  }

  scheduler();        
    80000ece:	00001097          	auipc	ra,0x1
    80000ed2:	13c080e7          	jalr	316(ra) # 8000200a <scheduler>
    consoleinit();
    80000ed6:	fffff097          	auipc	ra,0xfffff
    80000eda:	57a080e7          	jalr	1402(ra) # 80000450 <consoleinit>
    printfinit();
    80000ede:	00000097          	auipc	ra,0x0
    80000ee2:	88c080e7          	jalr	-1908(ra) # 8000076a <printfinit>
    printf("\n");
    80000ee6:	00007517          	auipc	a0,0x7
    80000eea:	1e250513          	addi	a0,a0,482 # 800080c8 <digits+0x88>
    80000eee:	fffff097          	auipc	ra,0xfffff
    80000ef2:	69c080e7          	jalr	1692(ra) # 8000058a <printf>
    printf("xv6 kernel is booting\n");
    80000ef6:	00007517          	auipc	a0,0x7
    80000efa:	1aa50513          	addi	a0,a0,426 # 800080a0 <digits+0x60>
    80000efe:	fffff097          	auipc	ra,0xfffff
    80000f02:	68c080e7          	jalr	1676(ra) # 8000058a <printf>
    printf("\n");
    80000f06:	00007517          	auipc	a0,0x7
    80000f0a:	1c250513          	addi	a0,a0,450 # 800080c8 <digits+0x88>
    80000f0e:	fffff097          	auipc	ra,0xfffff
    80000f12:	67c080e7          	jalr	1660(ra) # 8000058a <printf>
    kinit();         // physical page allocator
    80000f16:	00000097          	auipc	ra,0x0
    80000f1a:	b94080e7          	jalr	-1132(ra) # 80000aaa <kinit>
    kvminit();       // create kernel page table
    80000f1e:	00000097          	auipc	ra,0x0
    80000f22:	410080e7          	jalr	1040(ra) # 8000132e <kvminit>
    kvminithart();   // turn on paging
    80000f26:	00000097          	auipc	ra,0x0
    80000f2a:	152080e7          	jalr	338(ra) # 80001078 <kvminithart>
    procinit();      // process table
    80000f2e:	00001097          	auipc	ra,0x1
    80000f32:	a88080e7          	jalr	-1400(ra) # 800019b6 <procinit>
    trapinit();      // trap vectors
    80000f36:	00002097          	auipc	ra,0x2
    80000f3a:	8c4080e7          	jalr	-1852(ra) # 800027fa <trapinit>
    trapinithart();  // install kernel trap vector
    80000f3e:	00002097          	auipc	ra,0x2
    80000f42:	8e4080e7          	jalr	-1820(ra) # 80002822 <trapinithart>
    plicinit();      // set up interrupt controller
    80000f46:	00005097          	auipc	ra,0x5
    80000f4a:	eb4080e7          	jalr	-332(ra) # 80005dfa <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000f4e:	00005097          	auipc	ra,0x5
    80000f52:	ec2080e7          	jalr	-318(ra) # 80005e10 <plicinithart>
    binit();         // buffer cache
    80000f56:	00002097          	auipc	ra,0x2
    80000f5a:	056080e7          	jalr	86(ra) # 80002fac <binit>
    iinit();         // inode table
    80000f5e:	00002097          	auipc	ra,0x2
    80000f62:	6f6080e7          	jalr	1782(ra) # 80003654 <iinit>
    fileinit();      // file table
    80000f66:	00003097          	auipc	ra,0x3
    80000f6a:	69c080e7          	jalr	1692(ra) # 80004602 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f6e:	00005097          	auipc	ra,0x5
    80000f72:	faa080e7          	jalr	-86(ra) # 80005f18 <virtio_disk_init>
    userinit();      // first user process
    80000f76:	00001097          	auipc	ra,0x1
    80000f7a:	df8080e7          	jalr	-520(ra) # 80001d6e <userinit>
    __sync_synchronize();
    80000f7e:	0ff0000f          	fence
    started = 1;
    80000f82:	4785                	li	a5,1
    80000f84:	00008717          	auipc	a4,0x8
    80000f88:	9af72a23          	sw	a5,-1612(a4) # 80008938 <started>
    80000f8c:	b789                	j	80000ece <main+0x56>

0000000080000f8e <printTable>:
extern char etext[];  // kernel.ld sets this to end of kernel code.

extern char trampoline[]; // trampoline.S

void printTable(pagetable_t pagetable, int level)
{
    80000f8e:	7159                	addi	sp,sp,-112
    80000f90:	f486                	sd	ra,104(sp)
    80000f92:	f0a2                	sd	s0,96(sp)
    80000f94:	eca6                	sd	s1,88(sp)
    80000f96:	e8ca                	sd	s2,80(sp)
    80000f98:	e4ce                	sd	s3,72(sp)
    80000f9a:	e0d2                	sd	s4,64(sp)
    80000f9c:	fc56                	sd	s5,56(sp)
    80000f9e:	f85a                	sd	s6,48(sp)
    80000fa0:	f45e                	sd	s7,40(sp)
    80000fa2:	f062                	sd	s8,32(sp)
    80000fa4:	ec66                	sd	s9,24(sp)
    80000fa6:	e86a                	sd	s10,16(sp)
    80000fa8:	e46e                	sd	s11,8(sp)
    80000faa:	1880                	addi	s0,sp,112
    80000fac:	8aae                	mv	s5,a1
  for(int i = 0; i < 512; i++)
    80000fae:	8a2a                	mv	s4,a0
    80000fb0:	4981                	li	s3,0
  {
    pte_t pte = pagetable[i];
    if(pte & PTE_V){
      for (int j = 0; j <= level; j++) printf("    ");
      printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    80000fb2:	00007c97          	auipc	s9,0x7
    80000fb6:	126c8c93          	addi	s9,s9,294 # 800080d8 <digits+0x98>
      for (int j = 0; j <= level; j++) printf("    ");
    80000fba:	4d01                	li	s10,0
    80000fbc:	00007b17          	auipc	s6,0x7
    80000fc0:	114b0b13          	addi	s6,s6,276 # 800080d0 <digits+0x90>
    }
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80000fc4:	4c05                	li	s8,1
      uint64 child = PTE2PA(pte);
      printTable((pagetable_t)child, level+1);
    80000fc6:	00158d9b          	addiw	s11,a1,1
  for(int i = 0; i < 512; i++)
    80000fca:	20000b93          	li	s7,512
    80000fce:	a01d                	j	80000ff4 <printTable+0x66>
      printf("%d: pte %p pa %p\n", i, pte, PTE2PA(pte));
    80000fd0:	00a95693          	srli	a3,s2,0xa
    80000fd4:	06b2                	slli	a3,a3,0xc
    80000fd6:	864a                	mv	a2,s2
    80000fd8:	85ce                	mv	a1,s3
    80000fda:	8566                	mv	a0,s9
    80000fdc:	fffff097          	auipc	ra,0xfffff
    80000fe0:	5ae080e7          	jalr	1454(ra) # 8000058a <printf>
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80000fe4:	00f97793          	andi	a5,s2,15
    80000fe8:	03878763          	beq	a5,s8,80001016 <printTable+0x88>
  for(int i = 0; i < 512; i++)
    80000fec:	2985                	addiw	s3,s3,1 # 1001 <_entry-0x7fffefff>
    80000fee:	0a21                	addi	s4,s4,8 # fffffffffffff008 <end+0xffffffff7ffdcda8>
    80000ff0:	03798c63          	beq	s3,s7,80001028 <printTable+0x9a>
    pte_t pte = pagetable[i];
    80000ff4:	000a3903          	ld	s2,0(s4)
    if(pte & PTE_V){
    80000ff8:	00197793          	andi	a5,s2,1
    80000ffc:	d7e5                	beqz	a5,80000fe4 <printTable+0x56>
      for (int j = 0; j <= level; j++) printf("    ");
    80000ffe:	fc0ac9e3          	bltz	s5,80000fd0 <printTable+0x42>
    80001002:	84ea                	mv	s1,s10
    80001004:	855a                	mv	a0,s6
    80001006:	fffff097          	auipc	ra,0xfffff
    8000100a:	584080e7          	jalr	1412(ra) # 8000058a <printf>
    8000100e:	2485                	addiw	s1,s1,1
    80001010:	fe9adae3          	bge	s5,s1,80001004 <printTable+0x76>
    80001014:	bf75                	j	80000fd0 <printTable+0x42>
      uint64 child = PTE2PA(pte);
    80001016:	00a95513          	srli	a0,s2,0xa
      printTable((pagetable_t)child, level+1);
    8000101a:	85ee                	mv	a1,s11
    8000101c:	0532                	slli	a0,a0,0xc
    8000101e:	00000097          	auipc	ra,0x0
    80001022:	f70080e7          	jalr	-144(ra) # 80000f8e <printTable>
    80001026:	b7d9                	j	80000fec <printTable+0x5e>
    }
  }
}
    80001028:	70a6                	ld	ra,104(sp)
    8000102a:	7406                	ld	s0,96(sp)
    8000102c:	64e6                	ld	s1,88(sp)
    8000102e:	6946                	ld	s2,80(sp)
    80001030:	69a6                	ld	s3,72(sp)
    80001032:	6a06                	ld	s4,64(sp)
    80001034:	7ae2                	ld	s5,56(sp)
    80001036:	7b42                	ld	s6,48(sp)
    80001038:	7ba2                	ld	s7,40(sp)
    8000103a:	7c02                	ld	s8,32(sp)
    8000103c:	6ce2                	ld	s9,24(sp)
    8000103e:	6d42                	ld	s10,16(sp)
    80001040:	6da2                	ld	s11,8(sp)
    80001042:	6165                	addi	sp,sp,112
    80001044:	8082                	ret

0000000080001046 <prtpgtble>:

void prtpgtble(pagetable_t pagetable)
{
    80001046:	1101                	addi	sp,sp,-32
    80001048:	ec06                	sd	ra,24(sp)
    8000104a:	e822                	sd	s0,16(sp)
    8000104c:	e426                	sd	s1,8(sp)
    8000104e:	1000                	addi	s0,sp,32
    80001050:	84aa                	mv	s1,a0
  printf("Hello world (from Abreham Tadesse)\n");
    80001052:	00007517          	auipc	a0,0x7
    80001056:	09e50513          	addi	a0,a0,158 # 800080f0 <digits+0xb0>
    8000105a:	fffff097          	auipc	ra,0xfffff
    8000105e:	530080e7          	jalr	1328(ra) # 8000058a <printf>
  printTable(pagetable, 0);
    80001062:	4581                	li	a1,0
    80001064:	8526                	mv	a0,s1
    80001066:	00000097          	auipc	ra,0x0
    8000106a:	f28080e7          	jalr	-216(ra) # 80000f8e <printTable>
}
    8000106e:	60e2                	ld	ra,24(sp)
    80001070:	6442                	ld	s0,16(sp)
    80001072:	64a2                	ld	s1,8(sp)
    80001074:	6105                	addi	sp,sp,32
    80001076:	8082                	ret

0000000080001078 <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    80001078:	1141                	addi	sp,sp,-16
    8000107a:	e422                	sd	s0,8(sp)
    8000107c:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    8000107e:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80001082:	00008797          	auipc	a5,0x8
    80001086:	8be7b783          	ld	a5,-1858(a5) # 80008940 <kernel_pagetable>
    8000108a:	83b1                	srli	a5,a5,0xc
    8000108c:	577d                	li	a4,-1
    8000108e:	177e                	slli	a4,a4,0x3f
    80001090:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80001092:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80001096:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    8000109a:	6422                	ld	s0,8(sp)
    8000109c:	0141                	addi	sp,sp,16
    8000109e:	8082                	ret

00000000800010a0 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    800010a0:	7139                	addi	sp,sp,-64
    800010a2:	fc06                	sd	ra,56(sp)
    800010a4:	f822                	sd	s0,48(sp)
    800010a6:	f426                	sd	s1,40(sp)
    800010a8:	f04a                	sd	s2,32(sp)
    800010aa:	ec4e                	sd	s3,24(sp)
    800010ac:	e852                	sd	s4,16(sp)
    800010ae:	e456                	sd	s5,8(sp)
    800010b0:	e05a                	sd	s6,0(sp)
    800010b2:	0080                	addi	s0,sp,64
    800010b4:	84aa                	mv	s1,a0
    800010b6:	89ae                	mv	s3,a1
    800010b8:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    800010ba:	57fd                	li	a5,-1
    800010bc:	83e9                	srli	a5,a5,0x1a
    800010be:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    800010c0:	4b31                	li	s6,12
  if(va >= MAXVA)
    800010c2:	04b7f263          	bgeu	a5,a1,80001106 <walk+0x66>
    panic("walk");
    800010c6:	00007517          	auipc	a0,0x7
    800010ca:	05250513          	addi	a0,a0,82 # 80008118 <digits+0xd8>
    800010ce:	fffff097          	auipc	ra,0xfffff
    800010d2:	472080e7          	jalr	1138(ra) # 80000540 <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    800010d6:	060a8663          	beqz	s5,80001142 <walk+0xa2>
    800010da:	00000097          	auipc	ra,0x0
    800010de:	a0c080e7          	jalr	-1524(ra) # 80000ae6 <kalloc>
    800010e2:	84aa                	mv	s1,a0
    800010e4:	c529                	beqz	a0,8000112e <walk+0x8e>
        return 0;
      memset(pagetable, 0, PGSIZE);
    800010e6:	6605                	lui	a2,0x1
    800010e8:	4581                	li	a1,0
    800010ea:	00000097          	auipc	ra,0x0
    800010ee:	be8080e7          	jalr	-1048(ra) # 80000cd2 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    800010f2:	00c4d793          	srli	a5,s1,0xc
    800010f6:	07aa                	slli	a5,a5,0xa
    800010f8:	0017e793          	ori	a5,a5,1
    800010fc:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    80001100:	3a5d                	addiw	s4,s4,-9
    80001102:	036a0063          	beq	s4,s6,80001122 <walk+0x82>
    pte_t *pte = &pagetable[PX(level, va)];
    80001106:	0149d933          	srl	s2,s3,s4
    8000110a:	1ff97913          	andi	s2,s2,511
    8000110e:	090e                	slli	s2,s2,0x3
    80001110:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80001112:	00093483          	ld	s1,0(s2)
    80001116:	0014f793          	andi	a5,s1,1
    8000111a:	dfd5                	beqz	a5,800010d6 <walk+0x36>
      pagetable = (pagetable_t)PTE2PA(*pte);
    8000111c:	80a9                	srli	s1,s1,0xa
    8000111e:	04b2                	slli	s1,s1,0xc
    80001120:	b7c5                	j	80001100 <walk+0x60>
    }
  }
  return &pagetable[PX(0, va)];
    80001122:	00c9d513          	srli	a0,s3,0xc
    80001126:	1ff57513          	andi	a0,a0,511
    8000112a:	050e                	slli	a0,a0,0x3
    8000112c:	9526                	add	a0,a0,s1
}
    8000112e:	70e2                	ld	ra,56(sp)
    80001130:	7442                	ld	s0,48(sp)
    80001132:	74a2                	ld	s1,40(sp)
    80001134:	7902                	ld	s2,32(sp)
    80001136:	69e2                	ld	s3,24(sp)
    80001138:	6a42                	ld	s4,16(sp)
    8000113a:	6aa2                	ld	s5,8(sp)
    8000113c:	6b02                	ld	s6,0(sp)
    8000113e:	6121                	addi	sp,sp,64
    80001140:	8082                	ret
        return 0;
    80001142:	4501                	li	a0,0
    80001144:	b7ed                	j	8000112e <walk+0x8e>

0000000080001146 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80001146:	57fd                	li	a5,-1
    80001148:	83e9                	srli	a5,a5,0x1a
    8000114a:	00b7f463          	bgeu	a5,a1,80001152 <walkaddr+0xc>
    return 0;
    8000114e:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80001150:	8082                	ret
{
    80001152:	1141                	addi	sp,sp,-16
    80001154:	e406                	sd	ra,8(sp)
    80001156:	e022                	sd	s0,0(sp)
    80001158:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    8000115a:	4601                	li	a2,0
    8000115c:	00000097          	auipc	ra,0x0
    80001160:	f44080e7          	jalr	-188(ra) # 800010a0 <walk>
  if(pte == 0)
    80001164:	c105                	beqz	a0,80001184 <walkaddr+0x3e>
  if((*pte & PTE_V) == 0)
    80001166:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80001168:	0117f693          	andi	a3,a5,17
    8000116c:	4745                	li	a4,17
    return 0;
    8000116e:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80001170:	00e68663          	beq	a3,a4,8000117c <walkaddr+0x36>
}
    80001174:	60a2                	ld	ra,8(sp)
    80001176:	6402                	ld	s0,0(sp)
    80001178:	0141                	addi	sp,sp,16
    8000117a:	8082                	ret
  pa = PTE2PA(*pte);
    8000117c:	83a9                	srli	a5,a5,0xa
    8000117e:	00c79513          	slli	a0,a5,0xc
  return pa;
    80001182:	bfcd                	j	80001174 <walkaddr+0x2e>
    return 0;
    80001184:	4501                	li	a0,0
    80001186:	b7fd                	j	80001174 <walkaddr+0x2e>

0000000080001188 <mappages>:
// physical addresses starting at pa. va and size might not
// be page-aligned. Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001188:	715d                	addi	sp,sp,-80
    8000118a:	e486                	sd	ra,72(sp)
    8000118c:	e0a2                	sd	s0,64(sp)
    8000118e:	fc26                	sd	s1,56(sp)
    80001190:	f84a                	sd	s2,48(sp)
    80001192:	f44e                	sd	s3,40(sp)
    80001194:	f052                	sd	s4,32(sp)
    80001196:	ec56                	sd	s5,24(sp)
    80001198:	e85a                	sd	s6,16(sp)
    8000119a:	e45e                	sd	s7,8(sp)
    8000119c:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if(size == 0)
    8000119e:	c639                	beqz	a2,800011ec <mappages+0x64>
    800011a0:	8aaa                	mv	s5,a0
    800011a2:	8b3a                	mv	s6,a4
    panic("mappages: size");
  
  a = PGROUNDDOWN(va);
    800011a4:	777d                	lui	a4,0xfffff
    800011a6:	00e5f7b3          	and	a5,a1,a4
  last = PGROUNDDOWN(va + size - 1);
    800011aa:	fff58993          	addi	s3,a1,-1
    800011ae:	99b2                	add	s3,s3,a2
    800011b0:	00e9f9b3          	and	s3,s3,a4
  a = PGROUNDDOWN(va);
    800011b4:	893e                	mv	s2,a5
    800011b6:	40f68a33          	sub	s4,a3,a5
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    800011ba:	6b85                	lui	s7,0x1
    800011bc:	012a04b3          	add	s1,s4,s2
    if((pte = walk(pagetable, a, 1)) == 0)
    800011c0:	4605                	li	a2,1
    800011c2:	85ca                	mv	a1,s2
    800011c4:	8556                	mv	a0,s5
    800011c6:	00000097          	auipc	ra,0x0
    800011ca:	eda080e7          	jalr	-294(ra) # 800010a0 <walk>
    800011ce:	cd1d                	beqz	a0,8000120c <mappages+0x84>
    if(*pte & PTE_V)
    800011d0:	611c                	ld	a5,0(a0)
    800011d2:	8b85                	andi	a5,a5,1
    800011d4:	e785                	bnez	a5,800011fc <mappages+0x74>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800011d6:	80b1                	srli	s1,s1,0xc
    800011d8:	04aa                	slli	s1,s1,0xa
    800011da:	0164e4b3          	or	s1,s1,s6
    800011de:	0014e493          	ori	s1,s1,1
    800011e2:	e104                	sd	s1,0(a0)
    if(a == last)
    800011e4:	05390063          	beq	s2,s3,80001224 <mappages+0x9c>
    a += PGSIZE;
    800011e8:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800011ea:	bfc9                	j	800011bc <mappages+0x34>
    panic("mappages: size");
    800011ec:	00007517          	auipc	a0,0x7
    800011f0:	f3450513          	addi	a0,a0,-204 # 80008120 <digits+0xe0>
    800011f4:	fffff097          	auipc	ra,0xfffff
    800011f8:	34c080e7          	jalr	844(ra) # 80000540 <panic>
      panic("mappages: remap");
    800011fc:	00007517          	auipc	a0,0x7
    80001200:	f3450513          	addi	a0,a0,-204 # 80008130 <digits+0xf0>
    80001204:	fffff097          	auipc	ra,0xfffff
    80001208:	33c080e7          	jalr	828(ra) # 80000540 <panic>
      return -1;
    8000120c:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    8000120e:	60a6                	ld	ra,72(sp)
    80001210:	6406                	ld	s0,64(sp)
    80001212:	74e2                	ld	s1,56(sp)
    80001214:	7942                	ld	s2,48(sp)
    80001216:	79a2                	ld	s3,40(sp)
    80001218:	7a02                	ld	s4,32(sp)
    8000121a:	6ae2                	ld	s5,24(sp)
    8000121c:	6b42                	ld	s6,16(sp)
    8000121e:	6ba2                	ld	s7,8(sp)
    80001220:	6161                	addi	sp,sp,80
    80001222:	8082                	ret
  return 0;
    80001224:	4501                	li	a0,0
    80001226:	b7e5                	j	8000120e <mappages+0x86>

0000000080001228 <kvmmap>:
{
    80001228:	1141                	addi	sp,sp,-16
    8000122a:	e406                	sd	ra,8(sp)
    8000122c:	e022                	sd	s0,0(sp)
    8000122e:	0800                	addi	s0,sp,16
    80001230:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001232:	86b2                	mv	a3,a2
    80001234:	863e                	mv	a2,a5
    80001236:	00000097          	auipc	ra,0x0
    8000123a:	f52080e7          	jalr	-174(ra) # 80001188 <mappages>
    8000123e:	e509                	bnez	a0,80001248 <kvmmap+0x20>
}
    80001240:	60a2                	ld	ra,8(sp)
    80001242:	6402                	ld	s0,0(sp)
    80001244:	0141                	addi	sp,sp,16
    80001246:	8082                	ret
    panic("kvmmap");
    80001248:	00007517          	auipc	a0,0x7
    8000124c:	ef850513          	addi	a0,a0,-264 # 80008140 <digits+0x100>
    80001250:	fffff097          	auipc	ra,0xfffff
    80001254:	2f0080e7          	jalr	752(ra) # 80000540 <panic>

0000000080001258 <kvmmake>:
{
    80001258:	1101                	addi	sp,sp,-32
    8000125a:	ec06                	sd	ra,24(sp)
    8000125c:	e822                	sd	s0,16(sp)
    8000125e:	e426                	sd	s1,8(sp)
    80001260:	e04a                	sd	s2,0(sp)
    80001262:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    80001264:	00000097          	auipc	ra,0x0
    80001268:	882080e7          	jalr	-1918(ra) # 80000ae6 <kalloc>
    8000126c:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    8000126e:	6605                	lui	a2,0x1
    80001270:	4581                	li	a1,0
    80001272:	00000097          	auipc	ra,0x0
    80001276:	a60080e7          	jalr	-1440(ra) # 80000cd2 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000127a:	4719                	li	a4,6
    8000127c:	6685                	lui	a3,0x1
    8000127e:	10000637          	lui	a2,0x10000
    80001282:	100005b7          	lui	a1,0x10000
    80001286:	8526                	mv	a0,s1
    80001288:	00000097          	auipc	ra,0x0
    8000128c:	fa0080e7          	jalr	-96(ra) # 80001228 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001290:	4719                	li	a4,6
    80001292:	6685                	lui	a3,0x1
    80001294:	10001637          	lui	a2,0x10001
    80001298:	100015b7          	lui	a1,0x10001
    8000129c:	8526                	mv	a0,s1
    8000129e:	00000097          	auipc	ra,0x0
    800012a2:	f8a080e7          	jalr	-118(ra) # 80001228 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x400000, PTE_R | PTE_W);
    800012a6:	4719                	li	a4,6
    800012a8:	004006b7          	lui	a3,0x400
    800012ac:	0c000637          	lui	a2,0xc000
    800012b0:	0c0005b7          	lui	a1,0xc000
    800012b4:	8526                	mv	a0,s1
    800012b6:	00000097          	auipc	ra,0x0
    800012ba:	f72080e7          	jalr	-142(ra) # 80001228 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800012be:	00007917          	auipc	s2,0x7
    800012c2:	d4290913          	addi	s2,s2,-702 # 80008000 <etext>
    800012c6:	4729                	li	a4,10
    800012c8:	80007697          	auipc	a3,0x80007
    800012cc:	d3868693          	addi	a3,a3,-712 # 8000 <_entry-0x7fff8000>
    800012d0:	4605                	li	a2,1
    800012d2:	067e                	slli	a2,a2,0x1f
    800012d4:	85b2                	mv	a1,a2
    800012d6:	8526                	mv	a0,s1
    800012d8:	00000097          	auipc	ra,0x0
    800012dc:	f50080e7          	jalr	-176(ra) # 80001228 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800012e0:	4719                	li	a4,6
    800012e2:	46c5                	li	a3,17
    800012e4:	06ee                	slli	a3,a3,0x1b
    800012e6:	412686b3          	sub	a3,a3,s2
    800012ea:	864a                	mv	a2,s2
    800012ec:	85ca                	mv	a1,s2
    800012ee:	8526                	mv	a0,s1
    800012f0:	00000097          	auipc	ra,0x0
    800012f4:	f38080e7          	jalr	-200(ra) # 80001228 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800012f8:	4729                	li	a4,10
    800012fa:	6685                	lui	a3,0x1
    800012fc:	00006617          	auipc	a2,0x6
    80001300:	d0460613          	addi	a2,a2,-764 # 80007000 <_trampoline>
    80001304:	040005b7          	lui	a1,0x4000
    80001308:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000130a:	05b2                	slli	a1,a1,0xc
    8000130c:	8526                	mv	a0,s1
    8000130e:	00000097          	auipc	ra,0x0
    80001312:	f1a080e7          	jalr	-230(ra) # 80001228 <kvmmap>
  proc_mapstacks(kpgtbl);
    80001316:	8526                	mv	a0,s1
    80001318:	00000097          	auipc	ra,0x0
    8000131c:	608080e7          	jalr	1544(ra) # 80001920 <proc_mapstacks>
}
    80001320:	8526                	mv	a0,s1
    80001322:	60e2                	ld	ra,24(sp)
    80001324:	6442                	ld	s0,16(sp)
    80001326:	64a2                	ld	s1,8(sp)
    80001328:	6902                	ld	s2,0(sp)
    8000132a:	6105                	addi	sp,sp,32
    8000132c:	8082                	ret

000000008000132e <kvminit>:
{
    8000132e:	1141                	addi	sp,sp,-16
    80001330:	e406                	sd	ra,8(sp)
    80001332:	e022                	sd	s0,0(sp)
    80001334:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80001336:	00000097          	auipc	ra,0x0
    8000133a:	f22080e7          	jalr	-222(ra) # 80001258 <kvmmake>
    8000133e:	00007797          	auipc	a5,0x7
    80001342:	60a7b123          	sd	a0,1538(a5) # 80008940 <kernel_pagetable>
}
    80001346:	60a2                	ld	ra,8(sp)
    80001348:	6402                	ld	s0,0(sp)
    8000134a:	0141                	addi	sp,sp,16
    8000134c:	8082                	ret

000000008000134e <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000134e:	715d                	addi	sp,sp,-80
    80001350:	e486                	sd	ra,72(sp)
    80001352:	e0a2                	sd	s0,64(sp)
    80001354:	fc26                	sd	s1,56(sp)
    80001356:	f84a                	sd	s2,48(sp)
    80001358:	f44e                	sd	s3,40(sp)
    8000135a:	f052                	sd	s4,32(sp)
    8000135c:	ec56                	sd	s5,24(sp)
    8000135e:	e85a                	sd	s6,16(sp)
    80001360:	e45e                	sd	s7,8(sp)
    80001362:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001364:	03459793          	slli	a5,a1,0x34
    80001368:	e795                	bnez	a5,80001394 <uvmunmap+0x46>
    8000136a:	8a2a                	mv	s4,a0
    8000136c:	892e                	mv	s2,a1
    8000136e:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001370:	0632                	slli	a2,a2,0xc
    80001372:	00b609b3          	add	s3,a2,a1
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if(PTE_FLAGS(*pte) == PTE_V)
    80001376:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001378:	6b05                	lui	s6,0x1
    8000137a:	0735e263          	bltu	a1,s3,800013de <uvmunmap+0x90>
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
  }
}
    8000137e:	60a6                	ld	ra,72(sp)
    80001380:	6406                	ld	s0,64(sp)
    80001382:	74e2                	ld	s1,56(sp)
    80001384:	7942                	ld	s2,48(sp)
    80001386:	79a2                	ld	s3,40(sp)
    80001388:	7a02                	ld	s4,32(sp)
    8000138a:	6ae2                	ld	s5,24(sp)
    8000138c:	6b42                	ld	s6,16(sp)
    8000138e:	6ba2                	ld	s7,8(sp)
    80001390:	6161                	addi	sp,sp,80
    80001392:	8082                	ret
    panic("uvmunmap: not aligned");
    80001394:	00007517          	auipc	a0,0x7
    80001398:	db450513          	addi	a0,a0,-588 # 80008148 <digits+0x108>
    8000139c:	fffff097          	auipc	ra,0xfffff
    800013a0:	1a4080e7          	jalr	420(ra) # 80000540 <panic>
      panic("uvmunmap: walk");
    800013a4:	00007517          	auipc	a0,0x7
    800013a8:	dbc50513          	addi	a0,a0,-580 # 80008160 <digits+0x120>
    800013ac:	fffff097          	auipc	ra,0xfffff
    800013b0:	194080e7          	jalr	404(ra) # 80000540 <panic>
      panic("uvmunmap: not mapped");
    800013b4:	00007517          	auipc	a0,0x7
    800013b8:	dbc50513          	addi	a0,a0,-580 # 80008170 <digits+0x130>
    800013bc:	fffff097          	auipc	ra,0xfffff
    800013c0:	184080e7          	jalr	388(ra) # 80000540 <panic>
      panic("uvmunmap: not a leaf");
    800013c4:	00007517          	auipc	a0,0x7
    800013c8:	dc450513          	addi	a0,a0,-572 # 80008188 <digits+0x148>
    800013cc:	fffff097          	auipc	ra,0xfffff
    800013d0:	174080e7          	jalr	372(ra) # 80000540 <panic>
    *pte = 0;
    800013d4:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800013d8:	995a                	add	s2,s2,s6
    800013da:	fb3972e3          	bgeu	s2,s3,8000137e <uvmunmap+0x30>
    if((pte = walk(pagetable, a, 0)) == 0)
    800013de:	4601                	li	a2,0
    800013e0:	85ca                	mv	a1,s2
    800013e2:	8552                	mv	a0,s4
    800013e4:	00000097          	auipc	ra,0x0
    800013e8:	cbc080e7          	jalr	-836(ra) # 800010a0 <walk>
    800013ec:	84aa                	mv	s1,a0
    800013ee:	d95d                	beqz	a0,800013a4 <uvmunmap+0x56>
    if((*pte & PTE_V) == 0)
    800013f0:	6108                	ld	a0,0(a0)
    800013f2:	00157793          	andi	a5,a0,1
    800013f6:	dfdd                	beqz	a5,800013b4 <uvmunmap+0x66>
    if(PTE_FLAGS(*pte) == PTE_V)
    800013f8:	3ff57793          	andi	a5,a0,1023
    800013fc:	fd7784e3          	beq	a5,s7,800013c4 <uvmunmap+0x76>
    if(do_free){
    80001400:	fc0a8ae3          	beqz	s5,800013d4 <uvmunmap+0x86>
      uint64 pa = PTE2PA(*pte);
    80001404:	8129                	srli	a0,a0,0xa
      kfree((void*)pa);
    80001406:	0532                	slli	a0,a0,0xc
    80001408:	fffff097          	auipc	ra,0xfffff
    8000140c:	5e0080e7          	jalr	1504(ra) # 800009e8 <kfree>
    80001410:	b7d1                	j	800013d4 <uvmunmap+0x86>

0000000080001412 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001412:	1101                	addi	sp,sp,-32
    80001414:	ec06                	sd	ra,24(sp)
    80001416:	e822                	sd	s0,16(sp)
    80001418:	e426                	sd	s1,8(sp)
    8000141a:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    8000141c:	fffff097          	auipc	ra,0xfffff
    80001420:	6ca080e7          	jalr	1738(ra) # 80000ae6 <kalloc>
    80001424:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001426:	c519                	beqz	a0,80001434 <uvmcreate+0x22>
    return 0;
  memset(pagetable, 0, PGSIZE);
    80001428:	6605                	lui	a2,0x1
    8000142a:	4581                	li	a1,0
    8000142c:	00000097          	auipc	ra,0x0
    80001430:	8a6080e7          	jalr	-1882(ra) # 80000cd2 <memset>
  return pagetable;
}
    80001434:	8526                	mv	a0,s1
    80001436:	60e2                	ld	ra,24(sp)
    80001438:	6442                	ld	s0,16(sp)
    8000143a:	64a2                	ld	s1,8(sp)
    8000143c:	6105                	addi	sp,sp,32
    8000143e:	8082                	ret

0000000080001440 <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    80001440:	7179                	addi	sp,sp,-48
    80001442:	f406                	sd	ra,40(sp)
    80001444:	f022                	sd	s0,32(sp)
    80001446:	ec26                	sd	s1,24(sp)
    80001448:	e84a                	sd	s2,16(sp)
    8000144a:	e44e                	sd	s3,8(sp)
    8000144c:	e052                	sd	s4,0(sp)
    8000144e:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    80001450:	6785                	lui	a5,0x1
    80001452:	04f67863          	bgeu	a2,a5,800014a2 <uvmfirst+0x62>
    80001456:	8a2a                	mv	s4,a0
    80001458:	89ae                	mv	s3,a1
    8000145a:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    8000145c:	fffff097          	auipc	ra,0xfffff
    80001460:	68a080e7          	jalr	1674(ra) # 80000ae6 <kalloc>
    80001464:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    80001466:	6605                	lui	a2,0x1
    80001468:	4581                	li	a1,0
    8000146a:	00000097          	auipc	ra,0x0
    8000146e:	868080e7          	jalr	-1944(ra) # 80000cd2 <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    80001472:	4779                	li	a4,30
    80001474:	86ca                	mv	a3,s2
    80001476:	6605                	lui	a2,0x1
    80001478:	4581                	li	a1,0
    8000147a:	8552                	mv	a0,s4
    8000147c:	00000097          	auipc	ra,0x0
    80001480:	d0c080e7          	jalr	-756(ra) # 80001188 <mappages>
  memmove(mem, src, sz);
    80001484:	8626                	mv	a2,s1
    80001486:	85ce                	mv	a1,s3
    80001488:	854a                	mv	a0,s2
    8000148a:	00000097          	auipc	ra,0x0
    8000148e:	8a4080e7          	jalr	-1884(ra) # 80000d2e <memmove>
}
    80001492:	70a2                	ld	ra,40(sp)
    80001494:	7402                	ld	s0,32(sp)
    80001496:	64e2                	ld	s1,24(sp)
    80001498:	6942                	ld	s2,16(sp)
    8000149a:	69a2                	ld	s3,8(sp)
    8000149c:	6a02                	ld	s4,0(sp)
    8000149e:	6145                	addi	sp,sp,48
    800014a0:	8082                	ret
    panic("uvmfirst: more than a page");
    800014a2:	00007517          	auipc	a0,0x7
    800014a6:	cfe50513          	addi	a0,a0,-770 # 800081a0 <digits+0x160>
    800014aa:	fffff097          	auipc	ra,0xfffff
    800014ae:	096080e7          	jalr	150(ra) # 80000540 <panic>

00000000800014b2 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800014b2:	1101                	addi	sp,sp,-32
    800014b4:	ec06                	sd	ra,24(sp)
    800014b6:	e822                	sd	s0,16(sp)
    800014b8:	e426                	sd	s1,8(sp)
    800014ba:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800014bc:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800014be:	00b67d63          	bgeu	a2,a1,800014d8 <uvmdealloc+0x26>
    800014c2:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800014c4:	6785                	lui	a5,0x1
    800014c6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800014c8:	00f60733          	add	a4,a2,a5
    800014cc:	76fd                	lui	a3,0xfffff
    800014ce:	8f75                	and	a4,a4,a3
    800014d0:	97ae                	add	a5,a5,a1
    800014d2:	8ff5                	and	a5,a5,a3
    800014d4:	00f76863          	bltu	a4,a5,800014e4 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800014d8:	8526                	mv	a0,s1
    800014da:	60e2                	ld	ra,24(sp)
    800014dc:	6442                	ld	s0,16(sp)
    800014de:	64a2                	ld	s1,8(sp)
    800014e0:	6105                	addi	sp,sp,32
    800014e2:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800014e4:	8f99                	sub	a5,a5,a4
    800014e6:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800014e8:	4685                	li	a3,1
    800014ea:	0007861b          	sext.w	a2,a5
    800014ee:	85ba                	mv	a1,a4
    800014f0:	00000097          	auipc	ra,0x0
    800014f4:	e5e080e7          	jalr	-418(ra) # 8000134e <uvmunmap>
    800014f8:	b7c5                	j	800014d8 <uvmdealloc+0x26>

00000000800014fa <uvmalloc>:
  if(newsz < oldsz)
    800014fa:	0ab66563          	bltu	a2,a1,800015a4 <uvmalloc+0xaa>
{
    800014fe:	7139                	addi	sp,sp,-64
    80001500:	fc06                	sd	ra,56(sp)
    80001502:	f822                	sd	s0,48(sp)
    80001504:	f426                	sd	s1,40(sp)
    80001506:	f04a                	sd	s2,32(sp)
    80001508:	ec4e                	sd	s3,24(sp)
    8000150a:	e852                	sd	s4,16(sp)
    8000150c:	e456                	sd	s5,8(sp)
    8000150e:	e05a                	sd	s6,0(sp)
    80001510:	0080                	addi	s0,sp,64
    80001512:	8aaa                	mv	s5,a0
    80001514:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001516:	6785                	lui	a5,0x1
    80001518:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000151a:	95be                	add	a1,a1,a5
    8000151c:	77fd                	lui	a5,0xfffff
    8000151e:	00f5f9b3          	and	s3,a1,a5
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001522:	08c9f363          	bgeu	s3,a2,800015a8 <uvmalloc+0xae>
    80001526:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80001528:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    8000152c:	fffff097          	auipc	ra,0xfffff
    80001530:	5ba080e7          	jalr	1466(ra) # 80000ae6 <kalloc>
    80001534:	84aa                	mv	s1,a0
    if(mem == 0){
    80001536:	c51d                	beqz	a0,80001564 <uvmalloc+0x6a>
    memset(mem, 0, PGSIZE);
    80001538:	6605                	lui	a2,0x1
    8000153a:	4581                	li	a1,0
    8000153c:	fffff097          	auipc	ra,0xfffff
    80001540:	796080e7          	jalr	1942(ra) # 80000cd2 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80001544:	875a                	mv	a4,s6
    80001546:	86a6                	mv	a3,s1
    80001548:	6605                	lui	a2,0x1
    8000154a:	85ca                	mv	a1,s2
    8000154c:	8556                	mv	a0,s5
    8000154e:	00000097          	auipc	ra,0x0
    80001552:	c3a080e7          	jalr	-966(ra) # 80001188 <mappages>
    80001556:	e90d                	bnez	a0,80001588 <uvmalloc+0x8e>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001558:	6785                	lui	a5,0x1
    8000155a:	993e                	add	s2,s2,a5
    8000155c:	fd4968e3          	bltu	s2,s4,8000152c <uvmalloc+0x32>
  return newsz;
    80001560:	8552                	mv	a0,s4
    80001562:	a809                	j	80001574 <uvmalloc+0x7a>
      uvmdealloc(pagetable, a, oldsz);
    80001564:	864e                	mv	a2,s3
    80001566:	85ca                	mv	a1,s2
    80001568:	8556                	mv	a0,s5
    8000156a:	00000097          	auipc	ra,0x0
    8000156e:	f48080e7          	jalr	-184(ra) # 800014b2 <uvmdealloc>
      return 0;
    80001572:	4501                	li	a0,0
}
    80001574:	70e2                	ld	ra,56(sp)
    80001576:	7442                	ld	s0,48(sp)
    80001578:	74a2                	ld	s1,40(sp)
    8000157a:	7902                	ld	s2,32(sp)
    8000157c:	69e2                	ld	s3,24(sp)
    8000157e:	6a42                	ld	s4,16(sp)
    80001580:	6aa2                	ld	s5,8(sp)
    80001582:	6b02                	ld	s6,0(sp)
    80001584:	6121                	addi	sp,sp,64
    80001586:	8082                	ret
      kfree(mem);
    80001588:	8526                	mv	a0,s1
    8000158a:	fffff097          	auipc	ra,0xfffff
    8000158e:	45e080e7          	jalr	1118(ra) # 800009e8 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80001592:	864e                	mv	a2,s3
    80001594:	85ca                	mv	a1,s2
    80001596:	8556                	mv	a0,s5
    80001598:	00000097          	auipc	ra,0x0
    8000159c:	f1a080e7          	jalr	-230(ra) # 800014b2 <uvmdealloc>
      return 0;
    800015a0:	4501                	li	a0,0
    800015a2:	bfc9                	j	80001574 <uvmalloc+0x7a>
    return oldsz;
    800015a4:	852e                	mv	a0,a1
}
    800015a6:	8082                	ret
  return newsz;
    800015a8:	8532                	mv	a0,a2
    800015aa:	b7e9                	j	80001574 <uvmalloc+0x7a>

00000000800015ac <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800015ac:	7179                	addi	sp,sp,-48
    800015ae:	f406                	sd	ra,40(sp)
    800015b0:	f022                	sd	s0,32(sp)
    800015b2:	ec26                	sd	s1,24(sp)
    800015b4:	e84a                	sd	s2,16(sp)
    800015b6:	e44e                	sd	s3,8(sp)
    800015b8:	e052                	sd	s4,0(sp)
    800015ba:	1800                	addi	s0,sp,48
    800015bc:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800015be:	84aa                	mv	s1,a0
    800015c0:	6905                	lui	s2,0x1
    800015c2:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800015c4:	4985                	li	s3,1
    800015c6:	a829                	j	800015e0 <freewalk+0x34>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    800015c8:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800015ca:	00c79513          	slli	a0,a5,0xc
    800015ce:	00000097          	auipc	ra,0x0
    800015d2:	fde080e7          	jalr	-34(ra) # 800015ac <freewalk>
      pagetable[i] = 0;
    800015d6:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    800015da:	04a1                	addi	s1,s1,8
    800015dc:	03248163          	beq	s1,s2,800015fe <freewalk+0x52>
    pte_t pte = pagetable[i];
    800015e0:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800015e2:	00f7f713          	andi	a4,a5,15
    800015e6:	ff3701e3          	beq	a4,s3,800015c8 <freewalk+0x1c>
    } else if(pte & PTE_V){
    800015ea:	8b85                	andi	a5,a5,1
    800015ec:	d7fd                	beqz	a5,800015da <freewalk+0x2e>
      panic("freewalk: leaf");
    800015ee:	00007517          	auipc	a0,0x7
    800015f2:	bd250513          	addi	a0,a0,-1070 # 800081c0 <digits+0x180>
    800015f6:	fffff097          	auipc	ra,0xfffff
    800015fa:	f4a080e7          	jalr	-182(ra) # 80000540 <panic>
    }
  }
  kfree((void*)pagetable);
    800015fe:	8552                	mv	a0,s4
    80001600:	fffff097          	auipc	ra,0xfffff
    80001604:	3e8080e7          	jalr	1000(ra) # 800009e8 <kfree>
}
    80001608:	70a2                	ld	ra,40(sp)
    8000160a:	7402                	ld	s0,32(sp)
    8000160c:	64e2                	ld	s1,24(sp)
    8000160e:	6942                	ld	s2,16(sp)
    80001610:	69a2                	ld	s3,8(sp)
    80001612:	6a02                	ld	s4,0(sp)
    80001614:	6145                	addi	sp,sp,48
    80001616:	8082                	ret

0000000080001618 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80001618:	1101                	addi	sp,sp,-32
    8000161a:	ec06                	sd	ra,24(sp)
    8000161c:	e822                	sd	s0,16(sp)
    8000161e:	e426                	sd	s1,8(sp)
    80001620:	1000                	addi	s0,sp,32
    80001622:	84aa                	mv	s1,a0
  if(sz > 0)
    80001624:	e999                	bnez	a1,8000163a <uvmfree+0x22>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80001626:	8526                	mv	a0,s1
    80001628:	00000097          	auipc	ra,0x0
    8000162c:	f84080e7          	jalr	-124(ra) # 800015ac <freewalk>
}
    80001630:	60e2                	ld	ra,24(sp)
    80001632:	6442                	ld	s0,16(sp)
    80001634:	64a2                	ld	s1,8(sp)
    80001636:	6105                	addi	sp,sp,32
    80001638:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    8000163a:	6785                	lui	a5,0x1
    8000163c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000163e:	95be                	add	a1,a1,a5
    80001640:	4685                	li	a3,1
    80001642:	00c5d613          	srli	a2,a1,0xc
    80001646:	4581                	li	a1,0
    80001648:	00000097          	auipc	ra,0x0
    8000164c:	d06080e7          	jalr	-762(ra) # 8000134e <uvmunmap>
    80001650:	bfd9                	j	80001626 <uvmfree+0xe>

0000000080001652 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    80001652:	c679                	beqz	a2,80001720 <uvmcopy+0xce>
{
    80001654:	715d                	addi	sp,sp,-80
    80001656:	e486                	sd	ra,72(sp)
    80001658:	e0a2                	sd	s0,64(sp)
    8000165a:	fc26                	sd	s1,56(sp)
    8000165c:	f84a                	sd	s2,48(sp)
    8000165e:	f44e                	sd	s3,40(sp)
    80001660:	f052                	sd	s4,32(sp)
    80001662:	ec56                	sd	s5,24(sp)
    80001664:	e85a                	sd	s6,16(sp)
    80001666:	e45e                	sd	s7,8(sp)
    80001668:	0880                	addi	s0,sp,80
    8000166a:	8b2a                	mv	s6,a0
    8000166c:	8aae                	mv	s5,a1
    8000166e:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    80001670:	4981                	li	s3,0
    if((pte = walk(old, i, 0)) == 0)
    80001672:	4601                	li	a2,0
    80001674:	85ce                	mv	a1,s3
    80001676:	855a                	mv	a0,s6
    80001678:	00000097          	auipc	ra,0x0
    8000167c:	a28080e7          	jalr	-1496(ra) # 800010a0 <walk>
    80001680:	c531                	beqz	a0,800016cc <uvmcopy+0x7a>
      panic("uvmcopy: pte should exist");
    if((*pte & PTE_V) == 0)
    80001682:	6118                	ld	a4,0(a0)
    80001684:	00177793          	andi	a5,a4,1
    80001688:	cbb1                	beqz	a5,800016dc <uvmcopy+0x8a>
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    8000168a:	00a75593          	srli	a1,a4,0xa
    8000168e:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    80001692:	3ff77493          	andi	s1,a4,1023
    if((mem = kalloc()) == 0)
    80001696:	fffff097          	auipc	ra,0xfffff
    8000169a:	450080e7          	jalr	1104(ra) # 80000ae6 <kalloc>
    8000169e:	892a                	mv	s2,a0
    800016a0:	c939                	beqz	a0,800016f6 <uvmcopy+0xa4>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    800016a2:	6605                	lui	a2,0x1
    800016a4:	85de                	mv	a1,s7
    800016a6:	fffff097          	auipc	ra,0xfffff
    800016aa:	688080e7          	jalr	1672(ra) # 80000d2e <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    800016ae:	8726                	mv	a4,s1
    800016b0:	86ca                	mv	a3,s2
    800016b2:	6605                	lui	a2,0x1
    800016b4:	85ce                	mv	a1,s3
    800016b6:	8556                	mv	a0,s5
    800016b8:	00000097          	auipc	ra,0x0
    800016bc:	ad0080e7          	jalr	-1328(ra) # 80001188 <mappages>
    800016c0:	e515                	bnez	a0,800016ec <uvmcopy+0x9a>
  for(i = 0; i < sz; i += PGSIZE){
    800016c2:	6785                	lui	a5,0x1
    800016c4:	99be                	add	s3,s3,a5
    800016c6:	fb49e6e3          	bltu	s3,s4,80001672 <uvmcopy+0x20>
    800016ca:	a081                	j	8000170a <uvmcopy+0xb8>
      panic("uvmcopy: pte should exist");
    800016cc:	00007517          	auipc	a0,0x7
    800016d0:	b0450513          	addi	a0,a0,-1276 # 800081d0 <digits+0x190>
    800016d4:	fffff097          	auipc	ra,0xfffff
    800016d8:	e6c080e7          	jalr	-404(ra) # 80000540 <panic>
      panic("uvmcopy: page not present");
    800016dc:	00007517          	auipc	a0,0x7
    800016e0:	b1450513          	addi	a0,a0,-1260 # 800081f0 <digits+0x1b0>
    800016e4:	fffff097          	auipc	ra,0xfffff
    800016e8:	e5c080e7          	jalr	-420(ra) # 80000540 <panic>
      kfree(mem);
    800016ec:	854a                	mv	a0,s2
    800016ee:	fffff097          	auipc	ra,0xfffff
    800016f2:	2fa080e7          	jalr	762(ra) # 800009e8 <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800016f6:	4685                	li	a3,1
    800016f8:	00c9d613          	srli	a2,s3,0xc
    800016fc:	4581                	li	a1,0
    800016fe:	8556                	mv	a0,s5
    80001700:	00000097          	auipc	ra,0x0
    80001704:	c4e080e7          	jalr	-946(ra) # 8000134e <uvmunmap>
  return -1;
    80001708:	557d                	li	a0,-1
}
    8000170a:	60a6                	ld	ra,72(sp)
    8000170c:	6406                	ld	s0,64(sp)
    8000170e:	74e2                	ld	s1,56(sp)
    80001710:	7942                	ld	s2,48(sp)
    80001712:	79a2                	ld	s3,40(sp)
    80001714:	7a02                	ld	s4,32(sp)
    80001716:	6ae2                	ld	s5,24(sp)
    80001718:	6b42                	ld	s6,16(sp)
    8000171a:	6ba2                	ld	s7,8(sp)
    8000171c:	6161                	addi	sp,sp,80
    8000171e:	8082                	ret
  return 0;
    80001720:	4501                	li	a0,0
}
    80001722:	8082                	ret

0000000080001724 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80001724:	1141                	addi	sp,sp,-16
    80001726:	e406                	sd	ra,8(sp)
    80001728:	e022                	sd	s0,0(sp)
    8000172a:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    8000172c:	4601                	li	a2,0
    8000172e:	00000097          	auipc	ra,0x0
    80001732:	972080e7          	jalr	-1678(ra) # 800010a0 <walk>
  if(pte == 0)
    80001736:	c901                	beqz	a0,80001746 <uvmclear+0x22>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80001738:	611c                	ld	a5,0(a0)
    8000173a:	9bbd                	andi	a5,a5,-17
    8000173c:	e11c                	sd	a5,0(a0)
}
    8000173e:	60a2                	ld	ra,8(sp)
    80001740:	6402                	ld	s0,0(sp)
    80001742:	0141                	addi	sp,sp,16
    80001744:	8082                	ret
    panic("uvmclear");
    80001746:	00007517          	auipc	a0,0x7
    8000174a:	aca50513          	addi	a0,a0,-1334 # 80008210 <digits+0x1d0>
    8000174e:	fffff097          	auipc	ra,0xfffff
    80001752:	df2080e7          	jalr	-526(ra) # 80000540 <panic>

0000000080001756 <copyout>:
int
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    80001756:	c6bd                	beqz	a3,800017c4 <copyout+0x6e>
{
    80001758:	715d                	addi	sp,sp,-80
    8000175a:	e486                	sd	ra,72(sp)
    8000175c:	e0a2                	sd	s0,64(sp)
    8000175e:	fc26                	sd	s1,56(sp)
    80001760:	f84a                	sd	s2,48(sp)
    80001762:	f44e                	sd	s3,40(sp)
    80001764:	f052                	sd	s4,32(sp)
    80001766:	ec56                	sd	s5,24(sp)
    80001768:	e85a                	sd	s6,16(sp)
    8000176a:	e45e                	sd	s7,8(sp)
    8000176c:	e062                	sd	s8,0(sp)
    8000176e:	0880                	addi	s0,sp,80
    80001770:	8b2a                	mv	s6,a0
    80001772:	8c2e                	mv	s8,a1
    80001774:	8a32                	mv	s4,a2
    80001776:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(dstva);
    80001778:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (dstva - va0);
    8000177a:	6a85                	lui	s5,0x1
    8000177c:	a015                	j	800017a0 <copyout+0x4a>
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    8000177e:	9562                	add	a0,a0,s8
    80001780:	0004861b          	sext.w	a2,s1
    80001784:	85d2                	mv	a1,s4
    80001786:	41250533          	sub	a0,a0,s2
    8000178a:	fffff097          	auipc	ra,0xfffff
    8000178e:	5a4080e7          	jalr	1444(ra) # 80000d2e <memmove>

    len -= n;
    80001792:	409989b3          	sub	s3,s3,s1
    src += n;
    80001796:	9a26                	add	s4,s4,s1
    dstva = va0 + PGSIZE;
    80001798:	01590c33          	add	s8,s2,s5
  while(len > 0){
    8000179c:	02098263          	beqz	s3,800017c0 <copyout+0x6a>
    va0 = PGROUNDDOWN(dstva);
    800017a0:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    800017a4:	85ca                	mv	a1,s2
    800017a6:	855a                	mv	a0,s6
    800017a8:	00000097          	auipc	ra,0x0
    800017ac:	99e080e7          	jalr	-1634(ra) # 80001146 <walkaddr>
    if(pa0 == 0)
    800017b0:	cd01                	beqz	a0,800017c8 <copyout+0x72>
    n = PGSIZE - (dstva - va0);
    800017b2:	418904b3          	sub	s1,s2,s8
    800017b6:	94d6                	add	s1,s1,s5
    800017b8:	fc99f3e3          	bgeu	s3,s1,8000177e <copyout+0x28>
    800017bc:	84ce                	mv	s1,s3
    800017be:	b7c1                	j	8000177e <copyout+0x28>
  }
  return 0;
    800017c0:	4501                	li	a0,0
    800017c2:	a021                	j	800017ca <copyout+0x74>
    800017c4:	4501                	li	a0,0
}
    800017c6:	8082                	ret
      return -1;
    800017c8:	557d                	li	a0,-1
}
    800017ca:	60a6                	ld	ra,72(sp)
    800017cc:	6406                	ld	s0,64(sp)
    800017ce:	74e2                	ld	s1,56(sp)
    800017d0:	7942                	ld	s2,48(sp)
    800017d2:	79a2                	ld	s3,40(sp)
    800017d4:	7a02                	ld	s4,32(sp)
    800017d6:	6ae2                	ld	s5,24(sp)
    800017d8:	6b42                	ld	s6,16(sp)
    800017da:	6ba2                	ld	s7,8(sp)
    800017dc:	6c02                	ld	s8,0(sp)
    800017de:	6161                	addi	sp,sp,80
    800017e0:	8082                	ret

00000000800017e2 <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    800017e2:	caa5                	beqz	a3,80001852 <copyin+0x70>
{
    800017e4:	715d                	addi	sp,sp,-80
    800017e6:	e486                	sd	ra,72(sp)
    800017e8:	e0a2                	sd	s0,64(sp)
    800017ea:	fc26                	sd	s1,56(sp)
    800017ec:	f84a                	sd	s2,48(sp)
    800017ee:	f44e                	sd	s3,40(sp)
    800017f0:	f052                	sd	s4,32(sp)
    800017f2:	ec56                	sd	s5,24(sp)
    800017f4:	e85a                	sd	s6,16(sp)
    800017f6:	e45e                	sd	s7,8(sp)
    800017f8:	e062                	sd	s8,0(sp)
    800017fa:	0880                	addi	s0,sp,80
    800017fc:	8b2a                	mv	s6,a0
    800017fe:	8a2e                	mv	s4,a1
    80001800:	8c32                	mv	s8,a2
    80001802:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80001804:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80001806:	6a85                	lui	s5,0x1
    80001808:	a01d                	j	8000182e <copyin+0x4c>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    8000180a:	018505b3          	add	a1,a0,s8
    8000180e:	0004861b          	sext.w	a2,s1
    80001812:	412585b3          	sub	a1,a1,s2
    80001816:	8552                	mv	a0,s4
    80001818:	fffff097          	auipc	ra,0xfffff
    8000181c:	516080e7          	jalr	1302(ra) # 80000d2e <memmove>

    len -= n;
    80001820:	409989b3          	sub	s3,s3,s1
    dst += n;
    80001824:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80001826:	01590c33          	add	s8,s2,s5
  while(len > 0){
    8000182a:	02098263          	beqz	s3,8000184e <copyin+0x6c>
    va0 = PGROUNDDOWN(srcva);
    8000182e:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80001832:	85ca                	mv	a1,s2
    80001834:	855a                	mv	a0,s6
    80001836:	00000097          	auipc	ra,0x0
    8000183a:	910080e7          	jalr	-1776(ra) # 80001146 <walkaddr>
    if(pa0 == 0)
    8000183e:	cd01                	beqz	a0,80001856 <copyin+0x74>
    n = PGSIZE - (srcva - va0);
    80001840:	418904b3          	sub	s1,s2,s8
    80001844:	94d6                	add	s1,s1,s5
    80001846:	fc99f2e3          	bgeu	s3,s1,8000180a <copyin+0x28>
    8000184a:	84ce                	mv	s1,s3
    8000184c:	bf7d                	j	8000180a <copyin+0x28>
  }
  return 0;
    8000184e:	4501                	li	a0,0
    80001850:	a021                	j	80001858 <copyin+0x76>
    80001852:	4501                	li	a0,0
}
    80001854:	8082                	ret
      return -1;
    80001856:	557d                	li	a0,-1
}
    80001858:	60a6                	ld	ra,72(sp)
    8000185a:	6406                	ld	s0,64(sp)
    8000185c:	74e2                	ld	s1,56(sp)
    8000185e:	7942                	ld	s2,48(sp)
    80001860:	79a2                	ld	s3,40(sp)
    80001862:	7a02                	ld	s4,32(sp)
    80001864:	6ae2                	ld	s5,24(sp)
    80001866:	6b42                	ld	s6,16(sp)
    80001868:	6ba2                	ld	s7,8(sp)
    8000186a:	6c02                	ld	s8,0(sp)
    8000186c:	6161                	addi	sp,sp,80
    8000186e:	8082                	ret

0000000080001870 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80001870:	c2dd                	beqz	a3,80001916 <copyinstr+0xa6>
{
    80001872:	715d                	addi	sp,sp,-80
    80001874:	e486                	sd	ra,72(sp)
    80001876:	e0a2                	sd	s0,64(sp)
    80001878:	fc26                	sd	s1,56(sp)
    8000187a:	f84a                	sd	s2,48(sp)
    8000187c:	f44e                	sd	s3,40(sp)
    8000187e:	f052                	sd	s4,32(sp)
    80001880:	ec56                	sd	s5,24(sp)
    80001882:	e85a                	sd	s6,16(sp)
    80001884:	e45e                	sd	s7,8(sp)
    80001886:	0880                	addi	s0,sp,80
    80001888:	8a2a                	mv	s4,a0
    8000188a:	8b2e                	mv	s6,a1
    8000188c:	8bb2                	mv	s7,a2
    8000188e:	84b6                	mv	s1,a3
    va0 = PGROUNDDOWN(srcva);
    80001890:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80001892:	6985                	lui	s3,0x1
    80001894:	a02d                	j	800018be <copyinstr+0x4e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80001896:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    8000189a:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    8000189c:	37fd                	addiw	a5,a5,-1
    8000189e:	0007851b          	sext.w	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    800018a2:	60a6                	ld	ra,72(sp)
    800018a4:	6406                	ld	s0,64(sp)
    800018a6:	74e2                	ld	s1,56(sp)
    800018a8:	7942                	ld	s2,48(sp)
    800018aa:	79a2                	ld	s3,40(sp)
    800018ac:	7a02                	ld	s4,32(sp)
    800018ae:	6ae2                	ld	s5,24(sp)
    800018b0:	6b42                	ld	s6,16(sp)
    800018b2:	6ba2                	ld	s7,8(sp)
    800018b4:	6161                	addi	sp,sp,80
    800018b6:	8082                	ret
    srcva = va0 + PGSIZE;
    800018b8:	01390bb3          	add	s7,s2,s3
  while(got_null == 0 && max > 0){
    800018bc:	c8a9                	beqz	s1,8000190e <copyinstr+0x9e>
    va0 = PGROUNDDOWN(srcva);
    800018be:	015bf933          	and	s2,s7,s5
    pa0 = walkaddr(pagetable, va0);
    800018c2:	85ca                	mv	a1,s2
    800018c4:	8552                	mv	a0,s4
    800018c6:	00000097          	auipc	ra,0x0
    800018ca:	880080e7          	jalr	-1920(ra) # 80001146 <walkaddr>
    if(pa0 == 0)
    800018ce:	c131                	beqz	a0,80001912 <copyinstr+0xa2>
    n = PGSIZE - (srcva - va0);
    800018d0:	417906b3          	sub	a3,s2,s7
    800018d4:	96ce                	add	a3,a3,s3
    800018d6:	00d4f363          	bgeu	s1,a3,800018dc <copyinstr+0x6c>
    800018da:	86a6                	mv	a3,s1
    char *p = (char *) (pa0 + (srcva - va0));
    800018dc:	955e                	add	a0,a0,s7
    800018de:	41250533          	sub	a0,a0,s2
    while(n > 0){
    800018e2:	daf9                	beqz	a3,800018b8 <copyinstr+0x48>
    800018e4:	87da                	mv	a5,s6
      if(*p == '\0'){
    800018e6:	41650633          	sub	a2,a0,s6
    800018ea:	fff48593          	addi	a1,s1,-1
    800018ee:	95da                	add	a1,a1,s6
    while(n > 0){
    800018f0:	96da                	add	a3,a3,s6
      if(*p == '\0'){
    800018f2:	00f60733          	add	a4,a2,a5
    800018f6:	00074703          	lbu	a4,0(a4) # fffffffffffff000 <end+0xffffffff7ffdcda0>
    800018fa:	df51                	beqz	a4,80001896 <copyinstr+0x26>
        *dst = *p;
    800018fc:	00e78023          	sb	a4,0(a5)
      --max;
    80001900:	40f584b3          	sub	s1,a1,a5
      dst++;
    80001904:	0785                	addi	a5,a5,1
    while(n > 0){
    80001906:	fed796e3          	bne	a5,a3,800018f2 <copyinstr+0x82>
      dst++;
    8000190a:	8b3e                	mv	s6,a5
    8000190c:	b775                	j	800018b8 <copyinstr+0x48>
    8000190e:	4781                	li	a5,0
    80001910:	b771                	j	8000189c <copyinstr+0x2c>
      return -1;
    80001912:	557d                	li	a0,-1
    80001914:	b779                	j	800018a2 <copyinstr+0x32>
  int got_null = 0;
    80001916:	4781                	li	a5,0
  if(got_null){
    80001918:	37fd                	addiw	a5,a5,-1
    8000191a:	0007851b          	sext.w	a0,a5
}
    8000191e:	8082                	ret

0000000080001920 <proc_mapstacks>:
int index = 0;
int arr[32] = {0};

void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001920:	7139                	addi	sp,sp,-64
    80001922:	fc06                	sd	ra,56(sp)
    80001924:	f822                	sd	s0,48(sp)
    80001926:	f426                	sd	s1,40(sp)
    80001928:	f04a                	sd	s2,32(sp)
    8000192a:	ec4e                	sd	s3,24(sp)
    8000192c:	e852                	sd	s4,16(sp)
    8000192e:	e456                	sd	s5,8(sp)
    80001930:	e05a                	sd	s6,0(sp)
    80001932:	0080                	addi	s0,sp,64
    80001934:	89aa                	mv	s3,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80001936:	00010497          	auipc	s1,0x10
    8000193a:	94a48493          	addi	s1,s1,-1718 # 80011280 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    8000193e:	8b26                	mv	s6,s1
    80001940:	00006a97          	auipc	s5,0x6
    80001944:	6c0a8a93          	addi	s5,s5,1728 # 80008000 <etext>
    80001948:	04000937          	lui	s2,0x4000
    8000194c:	197d                	addi	s2,s2,-1 # 3ffffff <_entry-0x7c000001>
    8000194e:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001950:	00015a17          	auipc	s4,0x15
    80001954:	530a0a13          	addi	s4,s4,1328 # 80016e80 <tickslock>
    char *pa = kalloc();
    80001958:	fffff097          	auipc	ra,0xfffff
    8000195c:	18e080e7          	jalr	398(ra) # 80000ae6 <kalloc>
    80001960:	862a                	mv	a2,a0
    if(pa == 0)
    80001962:	c131                	beqz	a0,800019a6 <proc_mapstacks+0x86>
    uint64 va = KSTACK((int) (p - proc));
    80001964:	416485b3          	sub	a1,s1,s6
    80001968:	8591                	srai	a1,a1,0x4
    8000196a:	000ab783          	ld	a5,0(s5)
    8000196e:	02f585b3          	mul	a1,a1,a5
    80001972:	2585                	addiw	a1,a1,1
    80001974:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001978:	4719                	li	a4,6
    8000197a:	6685                	lui	a3,0x1
    8000197c:	40b905b3          	sub	a1,s2,a1
    80001980:	854e                	mv	a0,s3
    80001982:	00000097          	auipc	ra,0x0
    80001986:	8a6080e7          	jalr	-1882(ra) # 80001228 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000198a:	17048493          	addi	s1,s1,368
    8000198e:	fd4495e3          	bne	s1,s4,80001958 <proc_mapstacks+0x38>
  }
}
    80001992:	70e2                	ld	ra,56(sp)
    80001994:	7442                	ld	s0,48(sp)
    80001996:	74a2                	ld	s1,40(sp)
    80001998:	7902                	ld	s2,32(sp)
    8000199a:	69e2                	ld	s3,24(sp)
    8000199c:	6a42                	ld	s4,16(sp)
    8000199e:	6aa2                	ld	s5,8(sp)
    800019a0:	6b02                	ld	s6,0(sp)
    800019a2:	6121                	addi	sp,sp,64
    800019a4:	8082                	ret
      panic("kalloc");
    800019a6:	00007517          	auipc	a0,0x7
    800019aa:	87a50513          	addi	a0,a0,-1926 # 80008220 <digits+0x1e0>
    800019ae:	fffff097          	auipc	ra,0xfffff
    800019b2:	b92080e7          	jalr	-1134(ra) # 80000540 <panic>

00000000800019b6 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    800019b6:	7139                	addi	sp,sp,-64
    800019b8:	fc06                	sd	ra,56(sp)
    800019ba:	f822                	sd	s0,48(sp)
    800019bc:	f426                	sd	s1,40(sp)
    800019be:	f04a                	sd	s2,32(sp)
    800019c0:	ec4e                	sd	s3,24(sp)
    800019c2:	e852                	sd	s4,16(sp)
    800019c4:	e456                	sd	s5,8(sp)
    800019c6:	e05a                	sd	s6,0(sp)
    800019c8:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    800019ca:	00007597          	auipc	a1,0x7
    800019ce:	85e58593          	addi	a1,a1,-1954 # 80008228 <digits+0x1e8>
    800019d2:	0000f517          	auipc	a0,0xf
    800019d6:	1fe50513          	addi	a0,a0,510 # 80010bd0 <pid_lock>
    800019da:	fffff097          	auipc	ra,0xfffff
    800019de:	16c080e7          	jalr	364(ra) # 80000b46 <initlock>
  initlock(&wait_lock, "wait_lock");
    800019e2:	00007597          	auipc	a1,0x7
    800019e6:	84e58593          	addi	a1,a1,-1970 # 80008230 <digits+0x1f0>
    800019ea:	0000f517          	auipc	a0,0xf
    800019ee:	1fe50513          	addi	a0,a0,510 # 80010be8 <wait_lock>
    800019f2:	fffff097          	auipc	ra,0xfffff
    800019f6:	154080e7          	jalr	340(ra) # 80000b46 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    800019fa:	00010497          	auipc	s1,0x10
    800019fe:	88648493          	addi	s1,s1,-1914 # 80011280 <proc>
      initlock(&p->lock, "proc");
    80001a02:	00007b17          	auipc	s6,0x7
    80001a06:	83eb0b13          	addi	s6,s6,-1986 # 80008240 <digits+0x200>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80001a0a:	8aa6                	mv	s5,s1
    80001a0c:	00006a17          	auipc	s4,0x6
    80001a10:	5f4a0a13          	addi	s4,s4,1524 # 80008000 <etext>
    80001a14:	04000937          	lui	s2,0x4000
    80001a18:	197d                	addi	s2,s2,-1 # 3ffffff <_entry-0x7c000001>
    80001a1a:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001a1c:	00015997          	auipc	s3,0x15
    80001a20:	46498993          	addi	s3,s3,1124 # 80016e80 <tickslock>
      initlock(&p->lock, "proc");
    80001a24:	85da                	mv	a1,s6
    80001a26:	8526                	mv	a0,s1
    80001a28:	fffff097          	auipc	ra,0xfffff
    80001a2c:	11e080e7          	jalr	286(ra) # 80000b46 <initlock>
      p->state = UNUSED;
    80001a30:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80001a34:	415487b3          	sub	a5,s1,s5
    80001a38:	8791                	srai	a5,a5,0x4
    80001a3a:	000a3703          	ld	a4,0(s4)
    80001a3e:	02e787b3          	mul	a5,a5,a4
    80001a42:	2785                	addiw	a5,a5,1
    80001a44:	00d7979b          	slliw	a5,a5,0xd
    80001a48:	40f907b3          	sub	a5,s2,a5
    80001a4c:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80001a4e:	17048493          	addi	s1,s1,368
    80001a52:	fd3499e3          	bne	s1,s3,80001a24 <procinit+0x6e>
  }
}
    80001a56:	70e2                	ld	ra,56(sp)
    80001a58:	7442                	ld	s0,48(sp)
    80001a5a:	74a2                	ld	s1,40(sp)
    80001a5c:	7902                	ld	s2,32(sp)
    80001a5e:	69e2                	ld	s3,24(sp)
    80001a60:	6a42                	ld	s4,16(sp)
    80001a62:	6aa2                	ld	s5,8(sp)
    80001a64:	6b02                	ld	s6,0(sp)
    80001a66:	6121                	addi	sp,sp,64
    80001a68:	8082                	ret

0000000080001a6a <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80001a6a:	1141                	addi	sp,sp,-16
    80001a6c:	e422                	sd	s0,8(sp)
    80001a6e:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80001a70:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001a72:	2501                	sext.w	a0,a0
    80001a74:	6422                	ld	s0,8(sp)
    80001a76:	0141                	addi	sp,sp,16
    80001a78:	8082                	ret

0000000080001a7a <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80001a7a:	1141                	addi	sp,sp,-16
    80001a7c:	e422                	sd	s0,8(sp)
    80001a7e:	0800                	addi	s0,sp,16
    80001a80:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001a82:	2781                	sext.w	a5,a5
    80001a84:	079e                	slli	a5,a5,0x7
  return c;
}
    80001a86:	0000f517          	auipc	a0,0xf
    80001a8a:	17a50513          	addi	a0,a0,378 # 80010c00 <cpus>
    80001a8e:	953e                	add	a0,a0,a5
    80001a90:	6422                	ld	s0,8(sp)
    80001a92:	0141                	addi	sp,sp,16
    80001a94:	8082                	ret

0000000080001a96 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001a96:	1101                	addi	sp,sp,-32
    80001a98:	ec06                	sd	ra,24(sp)
    80001a9a:	e822                	sd	s0,16(sp)
    80001a9c:	e426                	sd	s1,8(sp)
    80001a9e:	1000                	addi	s0,sp,32
  push_off();
    80001aa0:	fffff097          	auipc	ra,0xfffff
    80001aa4:	0ea080e7          	jalr	234(ra) # 80000b8a <push_off>
    80001aa8:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001aaa:	2781                	sext.w	a5,a5
    80001aac:	079e                	slli	a5,a5,0x7
    80001aae:	0000f717          	auipc	a4,0xf
    80001ab2:	12270713          	addi	a4,a4,290 # 80010bd0 <pid_lock>
    80001ab6:	97ba                	add	a5,a5,a4
    80001ab8:	7b84                	ld	s1,48(a5)
  pop_off();
    80001aba:	fffff097          	auipc	ra,0xfffff
    80001abe:	170080e7          	jalr	368(ra) # 80000c2a <pop_off>
  return p;
}
    80001ac2:	8526                	mv	a0,s1
    80001ac4:	60e2                	ld	ra,24(sp)
    80001ac6:	6442                	ld	s0,16(sp)
    80001ac8:	64a2                	ld	s1,8(sp)
    80001aca:	6105                	addi	sp,sp,32
    80001acc:	8082                	ret

0000000080001ace <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001ace:	1141                	addi	sp,sp,-16
    80001ad0:	e406                	sd	ra,8(sp)
    80001ad2:	e022                	sd	s0,0(sp)
    80001ad4:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80001ad6:	00000097          	auipc	ra,0x0
    80001ada:	fc0080e7          	jalr	-64(ra) # 80001a96 <myproc>
    80001ade:	fffff097          	auipc	ra,0xfffff
    80001ae2:	1ac080e7          	jalr	428(ra) # 80000c8a <release>

  if (first) {
    80001ae6:	00007797          	auipc	a5,0x7
    80001aea:	dba7a783          	lw	a5,-582(a5) # 800088a0 <first.1>
    80001aee:	eb89                	bnez	a5,80001b00 <forkret+0x32>
    // be run from main().
    first = 0;
    fsinit(ROOTDEV);
  }

  usertrapret();
    80001af0:	00001097          	auipc	ra,0x1
    80001af4:	d4a080e7          	jalr	-694(ra) # 8000283a <usertrapret>
}
    80001af8:	60a2                	ld	ra,8(sp)
    80001afa:	6402                	ld	s0,0(sp)
    80001afc:	0141                	addi	sp,sp,16
    80001afe:	8082                	ret
    first = 0;
    80001b00:	00007797          	auipc	a5,0x7
    80001b04:	da07a023          	sw	zero,-608(a5) # 800088a0 <first.1>
    fsinit(ROOTDEV);
    80001b08:	4505                	li	a0,1
    80001b0a:	00002097          	auipc	ra,0x2
    80001b0e:	aca080e7          	jalr	-1334(ra) # 800035d4 <fsinit>
    80001b12:	bff9                	j	80001af0 <forkret+0x22>

0000000080001b14 <allocpid>:
{
    80001b14:	1101                	addi	sp,sp,-32
    80001b16:	ec06                	sd	ra,24(sp)
    80001b18:	e822                	sd	s0,16(sp)
    80001b1a:	e426                	sd	s1,8(sp)
    80001b1c:	e04a                	sd	s2,0(sp)
    80001b1e:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001b20:	0000f917          	auipc	s2,0xf
    80001b24:	0b090913          	addi	s2,s2,176 # 80010bd0 <pid_lock>
    80001b28:	854a                	mv	a0,s2
    80001b2a:	fffff097          	auipc	ra,0xfffff
    80001b2e:	0ac080e7          	jalr	172(ra) # 80000bd6 <acquire>
  pid = nextpid;
    80001b32:	00007797          	auipc	a5,0x7
    80001b36:	d7e78793          	addi	a5,a5,-642 # 800088b0 <nextpid>
    80001b3a:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001b3c:	0014871b          	addiw	a4,s1,1
    80001b40:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001b42:	854a                	mv	a0,s2
    80001b44:	fffff097          	auipc	ra,0xfffff
    80001b48:	146080e7          	jalr	326(ra) # 80000c8a <release>
}
    80001b4c:	8526                	mv	a0,s1
    80001b4e:	60e2                	ld	ra,24(sp)
    80001b50:	6442                	ld	s0,16(sp)
    80001b52:	64a2                	ld	s1,8(sp)
    80001b54:	6902                	ld	s2,0(sp)
    80001b56:	6105                	addi	sp,sp,32
    80001b58:	8082                	ret

0000000080001b5a <proc_pagetable>:
{
    80001b5a:	1101                	addi	sp,sp,-32
    80001b5c:	ec06                	sd	ra,24(sp)
    80001b5e:	e822                	sd	s0,16(sp)
    80001b60:	e426                	sd	s1,8(sp)
    80001b62:	e04a                	sd	s2,0(sp)
    80001b64:	1000                	addi	s0,sp,32
    80001b66:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001b68:	00000097          	auipc	ra,0x0
    80001b6c:	8aa080e7          	jalr	-1878(ra) # 80001412 <uvmcreate>
    80001b70:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001b72:	c121                	beqz	a0,80001bb2 <proc_pagetable+0x58>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001b74:	4729                	li	a4,10
    80001b76:	00005697          	auipc	a3,0x5
    80001b7a:	48a68693          	addi	a3,a3,1162 # 80007000 <_trampoline>
    80001b7e:	6605                	lui	a2,0x1
    80001b80:	040005b7          	lui	a1,0x4000
    80001b84:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001b86:	05b2                	slli	a1,a1,0xc
    80001b88:	fffff097          	auipc	ra,0xfffff
    80001b8c:	600080e7          	jalr	1536(ra) # 80001188 <mappages>
    80001b90:	02054863          	bltz	a0,80001bc0 <proc_pagetable+0x66>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001b94:	4719                	li	a4,6
    80001b96:	05893683          	ld	a3,88(s2)
    80001b9a:	6605                	lui	a2,0x1
    80001b9c:	020005b7          	lui	a1,0x2000
    80001ba0:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001ba2:	05b6                	slli	a1,a1,0xd
    80001ba4:	8526                	mv	a0,s1
    80001ba6:	fffff097          	auipc	ra,0xfffff
    80001baa:	5e2080e7          	jalr	1506(ra) # 80001188 <mappages>
    80001bae:	02054163          	bltz	a0,80001bd0 <proc_pagetable+0x76>
}
    80001bb2:	8526                	mv	a0,s1
    80001bb4:	60e2                	ld	ra,24(sp)
    80001bb6:	6442                	ld	s0,16(sp)
    80001bb8:	64a2                	ld	s1,8(sp)
    80001bba:	6902                	ld	s2,0(sp)
    80001bbc:	6105                	addi	sp,sp,32
    80001bbe:	8082                	ret
    uvmfree(pagetable, 0);
    80001bc0:	4581                	li	a1,0
    80001bc2:	8526                	mv	a0,s1
    80001bc4:	00000097          	auipc	ra,0x0
    80001bc8:	a54080e7          	jalr	-1452(ra) # 80001618 <uvmfree>
    return 0;
    80001bcc:	4481                	li	s1,0
    80001bce:	b7d5                	j	80001bb2 <proc_pagetable+0x58>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001bd0:	4681                	li	a3,0
    80001bd2:	4605                	li	a2,1
    80001bd4:	040005b7          	lui	a1,0x4000
    80001bd8:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001bda:	05b2                	slli	a1,a1,0xc
    80001bdc:	8526                	mv	a0,s1
    80001bde:	fffff097          	auipc	ra,0xfffff
    80001be2:	770080e7          	jalr	1904(ra) # 8000134e <uvmunmap>
    uvmfree(pagetable, 0);
    80001be6:	4581                	li	a1,0
    80001be8:	8526                	mv	a0,s1
    80001bea:	00000097          	auipc	ra,0x0
    80001bee:	a2e080e7          	jalr	-1490(ra) # 80001618 <uvmfree>
    return 0;
    80001bf2:	4481                	li	s1,0
    80001bf4:	bf7d                	j	80001bb2 <proc_pagetable+0x58>

0000000080001bf6 <proc_freepagetable>:
{
    80001bf6:	1101                	addi	sp,sp,-32
    80001bf8:	ec06                	sd	ra,24(sp)
    80001bfa:	e822                	sd	s0,16(sp)
    80001bfc:	e426                	sd	s1,8(sp)
    80001bfe:	e04a                	sd	s2,0(sp)
    80001c00:	1000                	addi	s0,sp,32
    80001c02:	84aa                	mv	s1,a0
    80001c04:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001c06:	4681                	li	a3,0
    80001c08:	4605                	li	a2,1
    80001c0a:	040005b7          	lui	a1,0x4000
    80001c0e:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001c10:	05b2                	slli	a1,a1,0xc
    80001c12:	fffff097          	auipc	ra,0xfffff
    80001c16:	73c080e7          	jalr	1852(ra) # 8000134e <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001c1a:	4681                	li	a3,0
    80001c1c:	4605                	li	a2,1
    80001c1e:	020005b7          	lui	a1,0x2000
    80001c22:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001c24:	05b6                	slli	a1,a1,0xd
    80001c26:	8526                	mv	a0,s1
    80001c28:	fffff097          	auipc	ra,0xfffff
    80001c2c:	726080e7          	jalr	1830(ra) # 8000134e <uvmunmap>
  uvmfree(pagetable, sz);
    80001c30:	85ca                	mv	a1,s2
    80001c32:	8526                	mv	a0,s1
    80001c34:	00000097          	auipc	ra,0x0
    80001c38:	9e4080e7          	jalr	-1564(ra) # 80001618 <uvmfree>
}
    80001c3c:	60e2                	ld	ra,24(sp)
    80001c3e:	6442                	ld	s0,16(sp)
    80001c40:	64a2                	ld	s1,8(sp)
    80001c42:	6902                	ld	s2,0(sp)
    80001c44:	6105                	addi	sp,sp,32
    80001c46:	8082                	ret

0000000080001c48 <freeproc>:
{
    80001c48:	1101                	addi	sp,sp,-32
    80001c4a:	ec06                	sd	ra,24(sp)
    80001c4c:	e822                	sd	s0,16(sp)
    80001c4e:	e426                	sd	s1,8(sp)
    80001c50:	1000                	addi	s0,sp,32
    80001c52:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001c54:	6d28                	ld	a0,88(a0)
    80001c56:	c509                	beqz	a0,80001c60 <freeproc+0x18>
    kfree((void*)p->trapframe);
    80001c58:	fffff097          	auipc	ra,0xfffff
    80001c5c:	d90080e7          	jalr	-624(ra) # 800009e8 <kfree>
  p->trapframe = 0;
    80001c60:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001c64:	68a8                	ld	a0,80(s1)
    80001c66:	c511                	beqz	a0,80001c72 <freeproc+0x2a>
    proc_freepagetable(p->pagetable, p->sz);
    80001c68:	64ac                	ld	a1,72(s1)
    80001c6a:	00000097          	auipc	ra,0x0
    80001c6e:	f8c080e7          	jalr	-116(ra) # 80001bf6 <proc_freepagetable>
  p->pagetable = 0;
    80001c72:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001c76:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001c7a:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001c7e:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001c82:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001c86:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001c8a:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001c8e:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001c92:	0004ac23          	sw	zero,24(s1)
}
    80001c96:	60e2                	ld	ra,24(sp)
    80001c98:	6442                	ld	s0,16(sp)
    80001c9a:	64a2                	ld	s1,8(sp)
    80001c9c:	6105                	addi	sp,sp,32
    80001c9e:	8082                	ret

0000000080001ca0 <allocproc>:
{
    80001ca0:	1101                	addi	sp,sp,-32
    80001ca2:	ec06                	sd	ra,24(sp)
    80001ca4:	e822                	sd	s0,16(sp)
    80001ca6:	e426                	sd	s1,8(sp)
    80001ca8:	e04a                	sd	s2,0(sp)
    80001caa:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001cac:	0000f497          	auipc	s1,0xf
    80001cb0:	5d448493          	addi	s1,s1,1492 # 80011280 <proc>
    80001cb4:	00015917          	auipc	s2,0x15
    80001cb8:	1cc90913          	addi	s2,s2,460 # 80016e80 <tickslock>
    acquire(&p->lock);
    80001cbc:	8526                	mv	a0,s1
    80001cbe:	fffff097          	auipc	ra,0xfffff
    80001cc2:	f18080e7          	jalr	-232(ra) # 80000bd6 <acquire>
    if(p->state == UNUSED) {
    80001cc6:	4c9c                	lw	a5,24(s1)
    80001cc8:	cf81                	beqz	a5,80001ce0 <allocproc+0x40>
      release(&p->lock);
    80001cca:	8526                	mv	a0,s1
    80001ccc:	fffff097          	auipc	ra,0xfffff
    80001cd0:	fbe080e7          	jalr	-66(ra) # 80000c8a <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001cd4:	17048493          	addi	s1,s1,368
    80001cd8:	ff2492e3          	bne	s1,s2,80001cbc <allocproc+0x1c>
  return 0;
    80001cdc:	4481                	li	s1,0
    80001cde:	a889                	j	80001d30 <allocproc+0x90>
  p->pid = allocpid();
    80001ce0:	00000097          	auipc	ra,0x0
    80001ce4:	e34080e7          	jalr	-460(ra) # 80001b14 <allocpid>
    80001ce8:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001cea:	4785                	li	a5,1
    80001cec:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001cee:	fffff097          	auipc	ra,0xfffff
    80001cf2:	df8080e7          	jalr	-520(ra) # 80000ae6 <kalloc>
    80001cf6:	892a                	mv	s2,a0
    80001cf8:	eca8                	sd	a0,88(s1)
    80001cfa:	c131                	beqz	a0,80001d3e <allocproc+0x9e>
  p->pagetable = proc_pagetable(p);
    80001cfc:	8526                	mv	a0,s1
    80001cfe:	00000097          	auipc	ra,0x0
    80001d02:	e5c080e7          	jalr	-420(ra) # 80001b5a <proc_pagetable>
    80001d06:	892a                	mv	s2,a0
    80001d08:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001d0a:	c531                	beqz	a0,80001d56 <allocproc+0xb6>
  memset(&p->context, 0, sizeof(p->context));
    80001d0c:	07000613          	li	a2,112
    80001d10:	4581                	li	a1,0
    80001d12:	06048513          	addi	a0,s1,96
    80001d16:	fffff097          	auipc	ra,0xfffff
    80001d1a:	fbc080e7          	jalr	-68(ra) # 80000cd2 <memset>
  p->context.ra = (uint64)forkret;
    80001d1e:	00000797          	auipc	a5,0x0
    80001d22:	db078793          	addi	a5,a5,-592 # 80001ace <forkret>
    80001d26:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001d28:	60bc                	ld	a5,64(s1)
    80001d2a:	6705                	lui	a4,0x1
    80001d2c:	97ba                	add	a5,a5,a4
    80001d2e:	f4bc                	sd	a5,104(s1)
}
    80001d30:	8526                	mv	a0,s1
    80001d32:	60e2                	ld	ra,24(sp)
    80001d34:	6442                	ld	s0,16(sp)
    80001d36:	64a2                	ld	s1,8(sp)
    80001d38:	6902                	ld	s2,0(sp)
    80001d3a:	6105                	addi	sp,sp,32
    80001d3c:	8082                	ret
    freeproc(p);
    80001d3e:	8526                	mv	a0,s1
    80001d40:	00000097          	auipc	ra,0x0
    80001d44:	f08080e7          	jalr	-248(ra) # 80001c48 <freeproc>
    release(&p->lock);
    80001d48:	8526                	mv	a0,s1
    80001d4a:	fffff097          	auipc	ra,0xfffff
    80001d4e:	f40080e7          	jalr	-192(ra) # 80000c8a <release>
    return 0;
    80001d52:	84ca                	mv	s1,s2
    80001d54:	bff1                	j	80001d30 <allocproc+0x90>
    freeproc(p);
    80001d56:	8526                	mv	a0,s1
    80001d58:	00000097          	auipc	ra,0x0
    80001d5c:	ef0080e7          	jalr	-272(ra) # 80001c48 <freeproc>
    release(&p->lock);
    80001d60:	8526                	mv	a0,s1
    80001d62:	fffff097          	auipc	ra,0xfffff
    80001d66:	f28080e7          	jalr	-216(ra) # 80000c8a <release>
    return 0;
    80001d6a:	84ca                	mv	s1,s2
    80001d6c:	b7d1                	j	80001d30 <allocproc+0x90>

0000000080001d6e <userinit>:
{
    80001d6e:	1101                	addi	sp,sp,-32
    80001d70:	ec06                	sd	ra,24(sp)
    80001d72:	e822                	sd	s0,16(sp)
    80001d74:	e426                	sd	s1,8(sp)
    80001d76:	1000                	addi	s0,sp,32
  p = allocproc();
    80001d78:	00000097          	auipc	ra,0x0
    80001d7c:	f28080e7          	jalr	-216(ra) # 80001ca0 <allocproc>
    80001d80:	84aa                	mv	s1,a0
  initproc = p;
    80001d82:	00007797          	auipc	a5,0x7
    80001d86:	bca7bf23          	sd	a0,-1058(a5) # 80008960 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001d8a:	03400613          	li	a2,52
    80001d8e:	00007597          	auipc	a1,0x7
    80001d92:	b3258593          	addi	a1,a1,-1230 # 800088c0 <initcode>
    80001d96:	6928                	ld	a0,80(a0)
    80001d98:	fffff097          	auipc	ra,0xfffff
    80001d9c:	6a8080e7          	jalr	1704(ra) # 80001440 <uvmfirst>
  p->sz = PGSIZE;
    80001da0:	6785                	lui	a5,0x1
    80001da2:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001da4:	6cb8                	ld	a4,88(s1)
    80001da6:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001daa:	6cb8                	ld	a4,88(s1)
    80001dac:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001dae:	4641                	li	a2,16
    80001db0:	00006597          	auipc	a1,0x6
    80001db4:	49858593          	addi	a1,a1,1176 # 80008248 <digits+0x208>
    80001db8:	15848513          	addi	a0,s1,344
    80001dbc:	fffff097          	auipc	ra,0xfffff
    80001dc0:	060080e7          	jalr	96(ra) # 80000e1c <safestrcpy>
  p->cwd = namei("/");
    80001dc4:	00006517          	auipc	a0,0x6
    80001dc8:	49450513          	addi	a0,a0,1172 # 80008258 <digits+0x218>
    80001dcc:	00002097          	auipc	ra,0x2
    80001dd0:	232080e7          	jalr	562(ra) # 80003ffe <namei>
    80001dd4:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001dd8:	478d                	li	a5,3
    80001dda:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001ddc:	8526                	mv	a0,s1
    80001dde:	fffff097          	auipc	ra,0xfffff
    80001de2:	eac080e7          	jalr	-340(ra) # 80000c8a <release>
}
    80001de6:	60e2                	ld	ra,24(sp)
    80001de8:	6442                	ld	s0,16(sp)
    80001dea:	64a2                	ld	s1,8(sp)
    80001dec:	6105                	addi	sp,sp,32
    80001dee:	8082                	ret

0000000080001df0 <growproc>:
{
    80001df0:	1101                	addi	sp,sp,-32
    80001df2:	ec06                	sd	ra,24(sp)
    80001df4:	e822                	sd	s0,16(sp)
    80001df6:	e426                	sd	s1,8(sp)
    80001df8:	e04a                	sd	s2,0(sp)
    80001dfa:	1000                	addi	s0,sp,32
    80001dfc:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001dfe:	00000097          	auipc	ra,0x0
    80001e02:	c98080e7          	jalr	-872(ra) # 80001a96 <myproc>
    80001e06:	84aa                	mv	s1,a0
  sz = p->sz;
    80001e08:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001e0a:	01204c63          	bgtz	s2,80001e22 <growproc+0x32>
  } else if(n < 0){
    80001e0e:	02094663          	bltz	s2,80001e3a <growproc+0x4a>
  p->sz = sz;
    80001e12:	e4ac                	sd	a1,72(s1)
  return 0;
    80001e14:	4501                	li	a0,0
}
    80001e16:	60e2                	ld	ra,24(sp)
    80001e18:	6442                	ld	s0,16(sp)
    80001e1a:	64a2                	ld	s1,8(sp)
    80001e1c:	6902                	ld	s2,0(sp)
    80001e1e:	6105                	addi	sp,sp,32
    80001e20:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001e22:	4691                	li	a3,4
    80001e24:	00b90633          	add	a2,s2,a1
    80001e28:	6928                	ld	a0,80(a0)
    80001e2a:	fffff097          	auipc	ra,0xfffff
    80001e2e:	6d0080e7          	jalr	1744(ra) # 800014fa <uvmalloc>
    80001e32:	85aa                	mv	a1,a0
    80001e34:	fd79                	bnez	a0,80001e12 <growproc+0x22>
      return -1;
    80001e36:	557d                	li	a0,-1
    80001e38:	bff9                	j	80001e16 <growproc+0x26>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001e3a:	00b90633          	add	a2,s2,a1
    80001e3e:	6928                	ld	a0,80(a0)
    80001e40:	fffff097          	auipc	ra,0xfffff
    80001e44:	672080e7          	jalr	1650(ra) # 800014b2 <uvmdealloc>
    80001e48:	85aa                	mv	a1,a0
    80001e4a:	b7e1                	j	80001e12 <growproc+0x22>

0000000080001e4c <fork>:
{
    80001e4c:	7139                	addi	sp,sp,-64
    80001e4e:	fc06                	sd	ra,56(sp)
    80001e50:	f822                	sd	s0,48(sp)
    80001e52:	f426                	sd	s1,40(sp)
    80001e54:	f04a                	sd	s2,32(sp)
    80001e56:	ec4e                	sd	s3,24(sp)
    80001e58:	e852                	sd	s4,16(sp)
    80001e5a:	e456                	sd	s5,8(sp)
    80001e5c:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001e5e:	00000097          	auipc	ra,0x0
    80001e62:	c38080e7          	jalr	-968(ra) # 80001a96 <myproc>
    80001e66:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001e68:	00000097          	auipc	ra,0x0
    80001e6c:	e38080e7          	jalr	-456(ra) # 80001ca0 <allocproc>
    80001e70:	10050f63          	beqz	a0,80001f8e <fork+0x142>
    80001e74:	89aa                	mv	s3,a0
  np->token = 1;
    80001e76:	4785                	li	a5,1
    80001e78:	16f53423          	sd	a5,360(a0)
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001e7c:	048ab603          	ld	a2,72(s5)
    80001e80:	692c                	ld	a1,80(a0)
    80001e82:	050ab503          	ld	a0,80(s5)
    80001e86:	fffff097          	auipc	ra,0xfffff
    80001e8a:	7cc080e7          	jalr	1996(ra) # 80001652 <uvmcopy>
    80001e8e:	04054863          	bltz	a0,80001ede <fork+0x92>
  np->sz = p->sz;
    80001e92:	048ab783          	ld	a5,72(s5)
    80001e96:	04f9b423          	sd	a5,72(s3)
  *(np->trapframe) = *(p->trapframe);
    80001e9a:	058ab683          	ld	a3,88(s5)
    80001e9e:	87b6                	mv	a5,a3
    80001ea0:	0589b703          	ld	a4,88(s3)
    80001ea4:	12068693          	addi	a3,a3,288
    80001ea8:	0007b803          	ld	a6,0(a5) # 1000 <_entry-0x7ffff000>
    80001eac:	6788                	ld	a0,8(a5)
    80001eae:	6b8c                	ld	a1,16(a5)
    80001eb0:	6f90                	ld	a2,24(a5)
    80001eb2:	01073023          	sd	a6,0(a4)
    80001eb6:	e708                	sd	a0,8(a4)
    80001eb8:	eb0c                	sd	a1,16(a4)
    80001eba:	ef10                	sd	a2,24(a4)
    80001ebc:	02078793          	addi	a5,a5,32
    80001ec0:	02070713          	addi	a4,a4,32
    80001ec4:	fed792e3          	bne	a5,a3,80001ea8 <fork+0x5c>
  np->trapframe->a0 = 0;
    80001ec8:	0589b783          	ld	a5,88(s3)
    80001ecc:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001ed0:	0d0a8493          	addi	s1,s5,208
    80001ed4:	0d098913          	addi	s2,s3,208
    80001ed8:	150a8a13          	addi	s4,s5,336
    80001edc:	a00d                	j	80001efe <fork+0xb2>
    freeproc(np);
    80001ede:	854e                	mv	a0,s3
    80001ee0:	00000097          	auipc	ra,0x0
    80001ee4:	d68080e7          	jalr	-664(ra) # 80001c48 <freeproc>
    release(&np->lock);
    80001ee8:	854e                	mv	a0,s3
    80001eea:	fffff097          	auipc	ra,0xfffff
    80001eee:	da0080e7          	jalr	-608(ra) # 80000c8a <release>
    return -1;
    80001ef2:	597d                	li	s2,-1
    80001ef4:	a059                	j	80001f7a <fork+0x12e>
  for(i = 0; i < NOFILE; i++)
    80001ef6:	04a1                	addi	s1,s1,8
    80001ef8:	0921                	addi	s2,s2,8
    80001efa:	01448b63          	beq	s1,s4,80001f10 <fork+0xc4>
    if(p->ofile[i])
    80001efe:	6088                	ld	a0,0(s1)
    80001f00:	d97d                	beqz	a0,80001ef6 <fork+0xaa>
      np->ofile[i] = filedup(p->ofile[i]);
    80001f02:	00002097          	auipc	ra,0x2
    80001f06:	792080e7          	jalr	1938(ra) # 80004694 <filedup>
    80001f0a:	00a93023          	sd	a0,0(s2)
    80001f0e:	b7e5                	j	80001ef6 <fork+0xaa>
  np->cwd = idup(p->cwd);
    80001f10:	150ab503          	ld	a0,336(s5)
    80001f14:	00002097          	auipc	ra,0x2
    80001f18:	900080e7          	jalr	-1792(ra) # 80003814 <idup>
    80001f1c:	14a9b823          	sd	a0,336(s3)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001f20:	4641                	li	a2,16
    80001f22:	158a8593          	addi	a1,s5,344
    80001f26:	15898513          	addi	a0,s3,344
    80001f2a:	fffff097          	auipc	ra,0xfffff
    80001f2e:	ef2080e7          	jalr	-270(ra) # 80000e1c <safestrcpy>
  pid = np->pid;
    80001f32:	0309a903          	lw	s2,48(s3)
  release(&np->lock);
    80001f36:	854e                	mv	a0,s3
    80001f38:	fffff097          	auipc	ra,0xfffff
    80001f3c:	d52080e7          	jalr	-686(ra) # 80000c8a <release>
  acquire(&wait_lock);
    80001f40:	0000f497          	auipc	s1,0xf
    80001f44:	ca848493          	addi	s1,s1,-856 # 80010be8 <wait_lock>
    80001f48:	8526                	mv	a0,s1
    80001f4a:	fffff097          	auipc	ra,0xfffff
    80001f4e:	c8c080e7          	jalr	-884(ra) # 80000bd6 <acquire>
  np->parent = p;
    80001f52:	0359bc23          	sd	s5,56(s3)
  release(&wait_lock);
    80001f56:	8526                	mv	a0,s1
    80001f58:	fffff097          	auipc	ra,0xfffff
    80001f5c:	d32080e7          	jalr	-718(ra) # 80000c8a <release>
  acquire(&np->lock);
    80001f60:	854e                	mv	a0,s3
    80001f62:	fffff097          	auipc	ra,0xfffff
    80001f66:	c74080e7          	jalr	-908(ra) # 80000bd6 <acquire>
  np->state = RUNNABLE;
    80001f6a:	478d                	li	a5,3
    80001f6c:	00f9ac23          	sw	a5,24(s3)
  release(&np->lock);
    80001f70:	854e                	mv	a0,s3
    80001f72:	fffff097          	auipc	ra,0xfffff
    80001f76:	d18080e7          	jalr	-744(ra) # 80000c8a <release>
}
    80001f7a:	854a                	mv	a0,s2
    80001f7c:	70e2                	ld	ra,56(sp)
    80001f7e:	7442                	ld	s0,48(sp)
    80001f80:	74a2                	ld	s1,40(sp)
    80001f82:	7902                	ld	s2,32(sp)
    80001f84:	69e2                	ld	s3,24(sp)
    80001f86:	6a42                	ld	s4,16(sp)
    80001f88:	6aa2                	ld	s5,8(sp)
    80001f8a:	6121                	addi	sp,sp,64
    80001f8c:	8082                	ret
    return -1;
    80001f8e:	597d                	li	s2,-1
    80001f90:	b7ed                	j	80001f7a <fork+0x12e>

0000000080001f92 <do_rand>:
{
    80001f92:	1141                	addi	sp,sp,-16
    80001f94:	e422                	sd	s0,8(sp)
    80001f96:	0800                	addi	s0,sp,16
    x = (*ctx % 0x7ffffffe) + 1;
    80001f98:	611c                	ld	a5,0(a0)
    80001f9a:	80000737          	lui	a4,0x80000
    80001f9e:	ffe74713          	xori	a4,a4,-2
    80001fa2:	02e7f7b3          	remu	a5,a5,a4
    80001fa6:	0785                	addi	a5,a5,1
    lo = x % 127773;
    80001fa8:	66fd                	lui	a3,0x1f
    80001faa:	31d68693          	addi	a3,a3,797 # 1f31d <_entry-0x7ffe0ce3>
    80001fae:	02d7e733          	rem	a4,a5,a3
    x = 16807 * lo - 2836 * hi;
    80001fb2:	6611                	lui	a2,0x4
    80001fb4:	1a760613          	addi	a2,a2,423 # 41a7 <_entry-0x7fffbe59>
    80001fb8:	02c70733          	mul	a4,a4,a2
    hi = x / 127773;
    80001fbc:	02d7c7b3          	div	a5,a5,a3
    x = 16807 * lo - 2836 * hi;
    80001fc0:	76fd                	lui	a3,0xfffff
    80001fc2:	4ec68693          	addi	a3,a3,1260 # fffffffffffff4ec <end+0xffffffff7ffdd28c>
    80001fc6:	02d787b3          	mul	a5,a5,a3
    80001fca:	97ba                	add	a5,a5,a4
    if (x < 0)
    80001fcc:	0007c963          	bltz	a5,80001fde <do_rand+0x4c>
    x--;
    80001fd0:	17fd                	addi	a5,a5,-1
    *ctx = x;
    80001fd2:	e11c                	sd	a5,0(a0)
}
    80001fd4:	0007851b          	sext.w	a0,a5
    80001fd8:	6422                	ld	s0,8(sp)
    80001fda:	0141                	addi	sp,sp,16
    80001fdc:	8082                	ret
        x += 0x7fffffff;
    80001fde:	80000737          	lui	a4,0x80000
    80001fe2:	fff74713          	not	a4,a4
    80001fe6:	97ba                	add	a5,a5,a4
    80001fe8:	b7e5                	j	80001fd0 <do_rand+0x3e>

0000000080001fea <rand>:
{
    80001fea:	1141                	addi	sp,sp,-16
    80001fec:	e406                	sd	ra,8(sp)
    80001fee:	e022                	sd	s0,0(sp)
    80001ff0:	0800                	addi	s0,sp,16
    return (do_rand(&rand_next));
    80001ff2:	00007517          	auipc	a0,0x7
    80001ff6:	8b650513          	addi	a0,a0,-1866 # 800088a8 <rand_next>
    80001ffa:	00000097          	auipc	ra,0x0
    80001ffe:	f98080e7          	jalr	-104(ra) # 80001f92 <do_rand>
}
    80002002:	60a2                	ld	ra,8(sp)
    80002004:	6402                	ld	s0,0(sp)
    80002006:	0141                	addi	sp,sp,16
    80002008:	8082                	ret

000000008000200a <scheduler>:
{
    8000200a:	715d                	addi	sp,sp,-80
    8000200c:	e486                	sd	ra,72(sp)
    8000200e:	e0a2                	sd	s0,64(sp)
    80002010:	fc26                	sd	s1,56(sp)
    80002012:	f84a                	sd	s2,48(sp)
    80002014:	f44e                	sd	s3,40(sp)
    80002016:	f052                	sd	s4,32(sp)
    80002018:	ec56                	sd	s5,24(sp)
    8000201a:	e85a                	sd	s6,16(sp)
    8000201c:	e45e                	sd	s7,8(sp)
    8000201e:	e062                	sd	s8,0(sp)
    80002020:	0880                	addi	s0,sp,80
    80002022:	8792                	mv	a5,tp
  int id = r_tp();
    80002024:	2781                	sext.w	a5,a5
  c->proc = 0;
    80002026:	00779b93          	slli	s7,a5,0x7
    8000202a:	0000f717          	auipc	a4,0xf
    8000202e:	ba670713          	addi	a4,a4,-1114 # 80010bd0 <pid_lock>
    80002032:	975e                	add	a4,a4,s7
    80002034:	02073823          	sd	zero,48(a4)
         swtch(&c->context, &p->context);
    80002038:	0000f717          	auipc	a4,0xf
    8000203c:	bd070713          	addi	a4,a4,-1072 # 80010c08 <cpus+0x8>
    80002040:	9bba                	add	s7,s7,a4
      if(p->state == RUNNABLE) {
    80002042:	498d                	li	s3,3
          arr[index % 32] = p->pid;
    80002044:	00007a97          	auipc	s5,0x7
    80002048:	914a8a93          	addi	s5,s5,-1772 # 80008958 <index>
    8000204c:	0000fc17          	auipc	s8,0xf
    80002050:	b84c0c13          	addi	s8,s8,-1148 # 80010bd0 <pid_lock>
          c->proc = p;
    80002054:	079e                	slli	a5,a5,0x7
    80002056:	00fc0a33          	add	s4,s8,a5
    for(p = proc; p < &proc[NPROC]; p++) {
    8000205a:	00015917          	auipc	s2,0x15
    8000205e:	e2690913          	addi	s2,s2,-474 # 80016e80 <tickslock>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002062:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80002066:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000206a:	10079073          	csrw	sstatus,a5
    8000206e:	0000f497          	auipc	s1,0xf
    80002072:	21248493          	addi	s1,s1,530 # 80011280 <proc>
          p->state = RUNNING;
    80002076:	4b11                	li	s6,4
    80002078:	a811                	j	8000208c <scheduler+0x82>
        release(&p->lock);
    8000207a:	8526                	mv	a0,s1
    8000207c:	fffff097          	auipc	ra,0xfffff
    80002080:	c0e080e7          	jalr	-1010(ra) # 80000c8a <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80002084:	17048493          	addi	s1,s1,368
    80002088:	fd248de3          	beq	s1,s2,80002062 <scheduler+0x58>
      acquire(&p->lock);
    8000208c:	8526                	mv	a0,s1
    8000208e:	fffff097          	auipc	ra,0xfffff
    80002092:	b48080e7          	jalr	-1208(ra) # 80000bd6 <acquire>
      if(p->state == RUNNABLE) {
    80002096:	4c9c                	lw	a5,24(s1)
    80002098:	ff3791e3          	bne	a5,s3,8000207a <scheduler+0x70>
          arr[index % 32] = p->pid;
    8000209c:	000aa703          	lw	a4,0(s5)
    800020a0:	41f7569b          	sraiw	a3,a4,0x1f
    800020a4:	01b6d69b          	srliw	a3,a3,0x1b
    800020a8:	00e687bb          	addw	a5,a3,a4
    800020ac:	8bfd                	andi	a5,a5,31
    800020ae:	9f95                	subw	a5,a5,a3
    800020b0:	078a                	slli	a5,a5,0x2
    800020b2:	97e2                	add	a5,a5,s8
    800020b4:	5894                	lw	a3,48(s1)
    800020b6:	42d7a823          	sw	a3,1072(a5)
          index++;
    800020ba:	2705                	addiw	a4,a4,1
    800020bc:	00eaa023          	sw	a4,0(s5)
          p->state = RUNNING;
    800020c0:	0164ac23          	sw	s6,24(s1)
          c->proc = p;
    800020c4:	029a3823          	sd	s1,48(s4)
         swtch(&c->context, &p->context);
    800020c8:	06048593          	addi	a1,s1,96
    800020cc:	855e                	mv	a0,s7
    800020ce:	00000097          	auipc	ra,0x0
    800020d2:	6c2080e7          	jalr	1730(ra) # 80002790 <swtch>
          c->proc = 0;
    800020d6:	020a3823          	sd	zero,48(s4)
    800020da:	b745                	j	8000207a <scheduler+0x70>

00000000800020dc <schedDisp>:
{
    800020dc:	1101                	addi	sp,sp,-32
    800020de:	ec06                	sd	ra,24(sp)
    800020e0:	e822                	sd	s0,16(sp)
    800020e2:	e426                	sd	s1,8(sp)
    800020e4:	1000                	addi	s0,sp,32
    800020e6:	84aa                	mv	s1,a0
  copyout(myproc()->pagetable, address, (char*)&arr, 128);
    800020e8:	00000097          	auipc	ra,0x0
    800020ec:	9ae080e7          	jalr	-1618(ra) # 80001a96 <myproc>
    800020f0:	08000693          	li	a3,128
    800020f4:	0000f617          	auipc	a2,0xf
    800020f8:	f0c60613          	addi	a2,a2,-244 # 80011000 <arr>
    800020fc:	85a6                	mv	a1,s1
    800020fe:	6928                	ld	a0,80(a0)
    80002100:	fffff097          	auipc	ra,0xfffff
    80002104:	656080e7          	jalr	1622(ra) # 80001756 <copyout>
}
    80002108:	00007517          	auipc	a0,0x7
    8000210c:	85052503          	lw	a0,-1968(a0) # 80008958 <index>
    80002110:	60e2                	ld	ra,24(sp)
    80002112:	6442                	ld	s0,16(sp)
    80002114:	64a2                	ld	s1,8(sp)
    80002116:	6105                	addi	sp,sp,32
    80002118:	8082                	ret

000000008000211a <sched>:
{
    8000211a:	7179                	addi	sp,sp,-48
    8000211c:	f406                	sd	ra,40(sp)
    8000211e:	f022                	sd	s0,32(sp)
    80002120:	ec26                	sd	s1,24(sp)
    80002122:	e84a                	sd	s2,16(sp)
    80002124:	e44e                	sd	s3,8(sp)
    80002126:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80002128:	00000097          	auipc	ra,0x0
    8000212c:	96e080e7          	jalr	-1682(ra) # 80001a96 <myproc>
    80002130:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80002132:	fffff097          	auipc	ra,0xfffff
    80002136:	a2a080e7          	jalr	-1494(ra) # 80000b5c <holding>
    8000213a:	c93d                	beqz	a0,800021b0 <sched+0x96>
  asm volatile("mv %0, tp" : "=r" (x) );
    8000213c:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    8000213e:	2781                	sext.w	a5,a5
    80002140:	079e                	slli	a5,a5,0x7
    80002142:	0000f717          	auipc	a4,0xf
    80002146:	a8e70713          	addi	a4,a4,-1394 # 80010bd0 <pid_lock>
    8000214a:	97ba                	add	a5,a5,a4
    8000214c:	0a87a703          	lw	a4,168(a5)
    80002150:	4785                	li	a5,1
    80002152:	06f71763          	bne	a4,a5,800021c0 <sched+0xa6>
  if(p->state == RUNNING)
    80002156:	4c98                	lw	a4,24(s1)
    80002158:	4791                	li	a5,4
    8000215a:	06f70b63          	beq	a4,a5,800021d0 <sched+0xb6>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000215e:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002162:	8b89                	andi	a5,a5,2
  if(intr_get())
    80002164:	efb5                	bnez	a5,800021e0 <sched+0xc6>
  asm volatile("mv %0, tp" : "=r" (x) );
    80002166:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80002168:	0000f917          	auipc	s2,0xf
    8000216c:	a6890913          	addi	s2,s2,-1432 # 80010bd0 <pid_lock>
    80002170:	2781                	sext.w	a5,a5
    80002172:	079e                	slli	a5,a5,0x7
    80002174:	97ca                	add	a5,a5,s2
    80002176:	0ac7a983          	lw	s3,172(a5)
    8000217a:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    8000217c:	2781                	sext.w	a5,a5
    8000217e:	079e                	slli	a5,a5,0x7
    80002180:	0000f597          	auipc	a1,0xf
    80002184:	a8858593          	addi	a1,a1,-1400 # 80010c08 <cpus+0x8>
    80002188:	95be                	add	a1,a1,a5
    8000218a:	06048513          	addi	a0,s1,96
    8000218e:	00000097          	auipc	ra,0x0
    80002192:	602080e7          	jalr	1538(ra) # 80002790 <swtch>
    80002196:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80002198:	2781                	sext.w	a5,a5
    8000219a:	079e                	slli	a5,a5,0x7
    8000219c:	993e                	add	s2,s2,a5
    8000219e:	0b392623          	sw	s3,172(s2)
}
    800021a2:	70a2                	ld	ra,40(sp)
    800021a4:	7402                	ld	s0,32(sp)
    800021a6:	64e2                	ld	s1,24(sp)
    800021a8:	6942                	ld	s2,16(sp)
    800021aa:	69a2                	ld	s3,8(sp)
    800021ac:	6145                	addi	sp,sp,48
    800021ae:	8082                	ret
    panic("sched p->lock");
    800021b0:	00006517          	auipc	a0,0x6
    800021b4:	0b050513          	addi	a0,a0,176 # 80008260 <digits+0x220>
    800021b8:	ffffe097          	auipc	ra,0xffffe
    800021bc:	388080e7          	jalr	904(ra) # 80000540 <panic>
    panic("sched locks");
    800021c0:	00006517          	auipc	a0,0x6
    800021c4:	0b050513          	addi	a0,a0,176 # 80008270 <digits+0x230>
    800021c8:	ffffe097          	auipc	ra,0xffffe
    800021cc:	378080e7          	jalr	888(ra) # 80000540 <panic>
    panic("sched running");
    800021d0:	00006517          	auipc	a0,0x6
    800021d4:	0b050513          	addi	a0,a0,176 # 80008280 <digits+0x240>
    800021d8:	ffffe097          	auipc	ra,0xffffe
    800021dc:	368080e7          	jalr	872(ra) # 80000540 <panic>
    panic("sched interruptible");
    800021e0:	00006517          	auipc	a0,0x6
    800021e4:	0b050513          	addi	a0,a0,176 # 80008290 <digits+0x250>
    800021e8:	ffffe097          	auipc	ra,0xffffe
    800021ec:	358080e7          	jalr	856(ra) # 80000540 <panic>

00000000800021f0 <yield>:
{
    800021f0:	1101                	addi	sp,sp,-32
    800021f2:	ec06                	sd	ra,24(sp)
    800021f4:	e822                	sd	s0,16(sp)
    800021f6:	e426                	sd	s1,8(sp)
    800021f8:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    800021fa:	00000097          	auipc	ra,0x0
    800021fe:	89c080e7          	jalr	-1892(ra) # 80001a96 <myproc>
    80002202:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002204:	fffff097          	auipc	ra,0xfffff
    80002208:	9d2080e7          	jalr	-1582(ra) # 80000bd6 <acquire>
  p->state = RUNNABLE;
    8000220c:	478d                	li	a5,3
    8000220e:	cc9c                	sw	a5,24(s1)
  sched();
    80002210:	00000097          	auipc	ra,0x0
    80002214:	f0a080e7          	jalr	-246(ra) # 8000211a <sched>
  release(&p->lock);
    80002218:	8526                	mv	a0,s1
    8000221a:	fffff097          	auipc	ra,0xfffff
    8000221e:	a70080e7          	jalr	-1424(ra) # 80000c8a <release>
}
    80002222:	60e2                	ld	ra,24(sp)
    80002224:	6442                	ld	s0,16(sp)
    80002226:	64a2                	ld	s1,8(sp)
    80002228:	6105                	addi	sp,sp,32
    8000222a:	8082                	ret

000000008000222c <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    8000222c:	7179                	addi	sp,sp,-48
    8000222e:	f406                	sd	ra,40(sp)
    80002230:	f022                	sd	s0,32(sp)
    80002232:	ec26                	sd	s1,24(sp)
    80002234:	e84a                	sd	s2,16(sp)
    80002236:	e44e                	sd	s3,8(sp)
    80002238:	1800                	addi	s0,sp,48
    8000223a:	89aa                	mv	s3,a0
    8000223c:	892e                	mv	s2,a1
  struct proc *p = myproc();
    8000223e:	00000097          	auipc	ra,0x0
    80002242:	858080e7          	jalr	-1960(ra) # 80001a96 <myproc>
    80002246:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80002248:	fffff097          	auipc	ra,0xfffff
    8000224c:	98e080e7          	jalr	-1650(ra) # 80000bd6 <acquire>
  release(lk);
    80002250:	854a                	mv	a0,s2
    80002252:	fffff097          	auipc	ra,0xfffff
    80002256:	a38080e7          	jalr	-1480(ra) # 80000c8a <release>

  // Go to sleep.
  p->chan = chan;
    8000225a:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    8000225e:	4789                	li	a5,2
    80002260:	cc9c                	sw	a5,24(s1)

  sched();
    80002262:	00000097          	auipc	ra,0x0
    80002266:	eb8080e7          	jalr	-328(ra) # 8000211a <sched>

  // Tidy up.
  p->chan = 0;
    8000226a:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    8000226e:	8526                	mv	a0,s1
    80002270:	fffff097          	auipc	ra,0xfffff
    80002274:	a1a080e7          	jalr	-1510(ra) # 80000c8a <release>
  acquire(lk);
    80002278:	854a                	mv	a0,s2
    8000227a:	fffff097          	auipc	ra,0xfffff
    8000227e:	95c080e7          	jalr	-1700(ra) # 80000bd6 <acquire>
}
    80002282:	70a2                	ld	ra,40(sp)
    80002284:	7402                	ld	s0,32(sp)
    80002286:	64e2                	ld	s1,24(sp)
    80002288:	6942                	ld	s2,16(sp)
    8000228a:	69a2                	ld	s3,8(sp)
    8000228c:	6145                	addi	sp,sp,48
    8000228e:	8082                	ret

0000000080002290 <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    80002290:	7139                	addi	sp,sp,-64
    80002292:	fc06                	sd	ra,56(sp)
    80002294:	f822                	sd	s0,48(sp)
    80002296:	f426                	sd	s1,40(sp)
    80002298:	f04a                	sd	s2,32(sp)
    8000229a:	ec4e                	sd	s3,24(sp)
    8000229c:	e852                	sd	s4,16(sp)
    8000229e:	e456                	sd	s5,8(sp)
    800022a0:	0080                	addi	s0,sp,64
    800022a2:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    800022a4:	0000f497          	auipc	s1,0xf
    800022a8:	fdc48493          	addi	s1,s1,-36 # 80011280 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    800022ac:	4989                	li	s3,2
        p->state = RUNNABLE;
    800022ae:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    800022b0:	00015917          	auipc	s2,0x15
    800022b4:	bd090913          	addi	s2,s2,-1072 # 80016e80 <tickslock>
    800022b8:	a811                	j	800022cc <wakeup+0x3c>
      }
      release(&p->lock);
    800022ba:	8526                	mv	a0,s1
    800022bc:	fffff097          	auipc	ra,0xfffff
    800022c0:	9ce080e7          	jalr	-1586(ra) # 80000c8a <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800022c4:	17048493          	addi	s1,s1,368
    800022c8:	03248663          	beq	s1,s2,800022f4 <wakeup+0x64>
    if(p != myproc()){
    800022cc:	fffff097          	auipc	ra,0xfffff
    800022d0:	7ca080e7          	jalr	1994(ra) # 80001a96 <myproc>
    800022d4:	fea488e3          	beq	s1,a0,800022c4 <wakeup+0x34>
      acquire(&p->lock);
    800022d8:	8526                	mv	a0,s1
    800022da:	fffff097          	auipc	ra,0xfffff
    800022de:	8fc080e7          	jalr	-1796(ra) # 80000bd6 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    800022e2:	4c9c                	lw	a5,24(s1)
    800022e4:	fd379be3          	bne	a5,s3,800022ba <wakeup+0x2a>
    800022e8:	709c                	ld	a5,32(s1)
    800022ea:	fd4798e3          	bne	a5,s4,800022ba <wakeup+0x2a>
        p->state = RUNNABLE;
    800022ee:	0154ac23          	sw	s5,24(s1)
    800022f2:	b7e1                	j	800022ba <wakeup+0x2a>
    }
  }
}
    800022f4:	70e2                	ld	ra,56(sp)
    800022f6:	7442                	ld	s0,48(sp)
    800022f8:	74a2                	ld	s1,40(sp)
    800022fa:	7902                	ld	s2,32(sp)
    800022fc:	69e2                	ld	s3,24(sp)
    800022fe:	6a42                	ld	s4,16(sp)
    80002300:	6aa2                	ld	s5,8(sp)
    80002302:	6121                	addi	sp,sp,64
    80002304:	8082                	ret

0000000080002306 <reparent>:
{
    80002306:	7179                	addi	sp,sp,-48
    80002308:	f406                	sd	ra,40(sp)
    8000230a:	f022                	sd	s0,32(sp)
    8000230c:	ec26                	sd	s1,24(sp)
    8000230e:	e84a                	sd	s2,16(sp)
    80002310:	e44e                	sd	s3,8(sp)
    80002312:	e052                	sd	s4,0(sp)
    80002314:	1800                	addi	s0,sp,48
    80002316:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80002318:	0000f497          	auipc	s1,0xf
    8000231c:	f6848493          	addi	s1,s1,-152 # 80011280 <proc>
      pp->parent = initproc;
    80002320:	00006a17          	auipc	s4,0x6
    80002324:	640a0a13          	addi	s4,s4,1600 # 80008960 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80002328:	00015997          	auipc	s3,0x15
    8000232c:	b5898993          	addi	s3,s3,-1192 # 80016e80 <tickslock>
    80002330:	a029                	j	8000233a <reparent+0x34>
    80002332:	17048493          	addi	s1,s1,368
    80002336:	01348d63          	beq	s1,s3,80002350 <reparent+0x4a>
    if(pp->parent == p){
    8000233a:	7c9c                	ld	a5,56(s1)
    8000233c:	ff279be3          	bne	a5,s2,80002332 <reparent+0x2c>
      pp->parent = initproc;
    80002340:	000a3503          	ld	a0,0(s4)
    80002344:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80002346:	00000097          	auipc	ra,0x0
    8000234a:	f4a080e7          	jalr	-182(ra) # 80002290 <wakeup>
    8000234e:	b7d5                	j	80002332 <reparent+0x2c>
}
    80002350:	70a2                	ld	ra,40(sp)
    80002352:	7402                	ld	s0,32(sp)
    80002354:	64e2                	ld	s1,24(sp)
    80002356:	6942                	ld	s2,16(sp)
    80002358:	69a2                	ld	s3,8(sp)
    8000235a:	6a02                	ld	s4,0(sp)
    8000235c:	6145                	addi	sp,sp,48
    8000235e:	8082                	ret

0000000080002360 <exit>:
{
    80002360:	7179                	addi	sp,sp,-48
    80002362:	f406                	sd	ra,40(sp)
    80002364:	f022                	sd	s0,32(sp)
    80002366:	ec26                	sd	s1,24(sp)
    80002368:	e84a                	sd	s2,16(sp)
    8000236a:	e44e                	sd	s3,8(sp)
    8000236c:	e052                	sd	s4,0(sp)
    8000236e:	1800                	addi	s0,sp,48
    80002370:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80002372:	fffff097          	auipc	ra,0xfffff
    80002376:	724080e7          	jalr	1828(ra) # 80001a96 <myproc>
    8000237a:	89aa                	mv	s3,a0
  if(p == initproc)
    8000237c:	00006797          	auipc	a5,0x6
    80002380:	5e47b783          	ld	a5,1508(a5) # 80008960 <initproc>
    80002384:	0d050493          	addi	s1,a0,208
    80002388:	15050913          	addi	s2,a0,336
    8000238c:	02a79363          	bne	a5,a0,800023b2 <exit+0x52>
    panic("init exiting");
    80002390:	00006517          	auipc	a0,0x6
    80002394:	f1850513          	addi	a0,a0,-232 # 800082a8 <digits+0x268>
    80002398:	ffffe097          	auipc	ra,0xffffe
    8000239c:	1a8080e7          	jalr	424(ra) # 80000540 <panic>
      fileclose(f);
    800023a0:	00002097          	auipc	ra,0x2
    800023a4:	346080e7          	jalr	838(ra) # 800046e6 <fileclose>
      p->ofile[fd] = 0;
    800023a8:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    800023ac:	04a1                	addi	s1,s1,8
    800023ae:	01248563          	beq	s1,s2,800023b8 <exit+0x58>
    if(p->ofile[fd]){
    800023b2:	6088                	ld	a0,0(s1)
    800023b4:	f575                	bnez	a0,800023a0 <exit+0x40>
    800023b6:	bfdd                	j	800023ac <exit+0x4c>
  begin_op();
    800023b8:	00002097          	auipc	ra,0x2
    800023bc:	e66080e7          	jalr	-410(ra) # 8000421e <begin_op>
  iput(p->cwd);
    800023c0:	1509b503          	ld	a0,336(s3)
    800023c4:	00001097          	auipc	ra,0x1
    800023c8:	648080e7          	jalr	1608(ra) # 80003a0c <iput>
  end_op();
    800023cc:	00002097          	auipc	ra,0x2
    800023d0:	ed0080e7          	jalr	-304(ra) # 8000429c <end_op>
  p->cwd = 0;
    800023d4:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800023d8:	0000f497          	auipc	s1,0xf
    800023dc:	81048493          	addi	s1,s1,-2032 # 80010be8 <wait_lock>
    800023e0:	8526                	mv	a0,s1
    800023e2:	ffffe097          	auipc	ra,0xffffe
    800023e6:	7f4080e7          	jalr	2036(ra) # 80000bd6 <acquire>
  reparent(p);
    800023ea:	854e                	mv	a0,s3
    800023ec:	00000097          	auipc	ra,0x0
    800023f0:	f1a080e7          	jalr	-230(ra) # 80002306 <reparent>
  wakeup(p->parent);
    800023f4:	0389b503          	ld	a0,56(s3)
    800023f8:	00000097          	auipc	ra,0x0
    800023fc:	e98080e7          	jalr	-360(ra) # 80002290 <wakeup>
  acquire(&p->lock);
    80002400:	854e                	mv	a0,s3
    80002402:	ffffe097          	auipc	ra,0xffffe
    80002406:	7d4080e7          	jalr	2004(ra) # 80000bd6 <acquire>
  p->xstate = status;
    8000240a:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    8000240e:	4795                	li	a5,5
    80002410:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80002414:	8526                	mv	a0,s1
    80002416:	fffff097          	auipc	ra,0xfffff
    8000241a:	874080e7          	jalr	-1932(ra) # 80000c8a <release>
  sched();
    8000241e:	00000097          	auipc	ra,0x0
    80002422:	cfc080e7          	jalr	-772(ra) # 8000211a <sched>
  panic("zombie exit");
    80002426:	00006517          	auipc	a0,0x6
    8000242a:	e9250513          	addi	a0,a0,-366 # 800082b8 <digits+0x278>
    8000242e:	ffffe097          	auipc	ra,0xffffe
    80002432:	112080e7          	jalr	274(ra) # 80000540 <panic>

0000000080002436 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80002436:	7179                	addi	sp,sp,-48
    80002438:	f406                	sd	ra,40(sp)
    8000243a:	f022                	sd	s0,32(sp)
    8000243c:	ec26                	sd	s1,24(sp)
    8000243e:	e84a                	sd	s2,16(sp)
    80002440:	e44e                	sd	s3,8(sp)
    80002442:	1800                	addi	s0,sp,48
    80002444:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80002446:	0000f497          	auipc	s1,0xf
    8000244a:	e3a48493          	addi	s1,s1,-454 # 80011280 <proc>
    8000244e:	00015997          	auipc	s3,0x15
    80002452:	a3298993          	addi	s3,s3,-1486 # 80016e80 <tickslock>
    acquire(&p->lock);
    80002456:	8526                	mv	a0,s1
    80002458:	ffffe097          	auipc	ra,0xffffe
    8000245c:	77e080e7          	jalr	1918(ra) # 80000bd6 <acquire>
    if(p->pid == pid){
    80002460:	589c                	lw	a5,48(s1)
    80002462:	01278d63          	beq	a5,s2,8000247c <kill+0x46>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80002466:	8526                	mv	a0,s1
    80002468:	fffff097          	auipc	ra,0xfffff
    8000246c:	822080e7          	jalr	-2014(ra) # 80000c8a <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80002470:	17048493          	addi	s1,s1,368
    80002474:	ff3491e3          	bne	s1,s3,80002456 <kill+0x20>
  }
  return -1;
    80002478:	557d                	li	a0,-1
    8000247a:	a829                	j	80002494 <kill+0x5e>
      p->killed = 1;
    8000247c:	4785                	li	a5,1
    8000247e:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80002480:	4c98                	lw	a4,24(s1)
    80002482:	4789                	li	a5,2
    80002484:	00f70f63          	beq	a4,a5,800024a2 <kill+0x6c>
      release(&p->lock);
    80002488:	8526                	mv	a0,s1
    8000248a:	fffff097          	auipc	ra,0xfffff
    8000248e:	800080e7          	jalr	-2048(ra) # 80000c8a <release>
      return 0;
    80002492:	4501                	li	a0,0
}
    80002494:	70a2                	ld	ra,40(sp)
    80002496:	7402                	ld	s0,32(sp)
    80002498:	64e2                	ld	s1,24(sp)
    8000249a:	6942                	ld	s2,16(sp)
    8000249c:	69a2                	ld	s3,8(sp)
    8000249e:	6145                	addi	sp,sp,48
    800024a0:	8082                	ret
        p->state = RUNNABLE;
    800024a2:	478d                	li	a5,3
    800024a4:	cc9c                	sw	a5,24(s1)
    800024a6:	b7cd                	j	80002488 <kill+0x52>

00000000800024a8 <setkilled>:

void
setkilled(struct proc *p)
{
    800024a8:	1101                	addi	sp,sp,-32
    800024aa:	ec06                	sd	ra,24(sp)
    800024ac:	e822                	sd	s0,16(sp)
    800024ae:	e426                	sd	s1,8(sp)
    800024b0:	1000                	addi	s0,sp,32
    800024b2:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800024b4:	ffffe097          	auipc	ra,0xffffe
    800024b8:	722080e7          	jalr	1826(ra) # 80000bd6 <acquire>
  p->killed = 1;
    800024bc:	4785                	li	a5,1
    800024be:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800024c0:	8526                	mv	a0,s1
    800024c2:	ffffe097          	auipc	ra,0xffffe
    800024c6:	7c8080e7          	jalr	1992(ra) # 80000c8a <release>
}
    800024ca:	60e2                	ld	ra,24(sp)
    800024cc:	6442                	ld	s0,16(sp)
    800024ce:	64a2                	ld	s1,8(sp)
    800024d0:	6105                	addi	sp,sp,32
    800024d2:	8082                	ret

00000000800024d4 <killed>:

int
killed(struct proc *p)
{
    800024d4:	1101                	addi	sp,sp,-32
    800024d6:	ec06                	sd	ra,24(sp)
    800024d8:	e822                	sd	s0,16(sp)
    800024da:	e426                	sd	s1,8(sp)
    800024dc:	e04a                	sd	s2,0(sp)
    800024de:	1000                	addi	s0,sp,32
    800024e0:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    800024e2:	ffffe097          	auipc	ra,0xffffe
    800024e6:	6f4080e7          	jalr	1780(ra) # 80000bd6 <acquire>
  k = p->killed;
    800024ea:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    800024ee:	8526                	mv	a0,s1
    800024f0:	ffffe097          	auipc	ra,0xffffe
    800024f4:	79a080e7          	jalr	1946(ra) # 80000c8a <release>
  return k;
}
    800024f8:	854a                	mv	a0,s2
    800024fa:	60e2                	ld	ra,24(sp)
    800024fc:	6442                	ld	s0,16(sp)
    800024fe:	64a2                	ld	s1,8(sp)
    80002500:	6902                	ld	s2,0(sp)
    80002502:	6105                	addi	sp,sp,32
    80002504:	8082                	ret

0000000080002506 <wait>:
{
    80002506:	715d                	addi	sp,sp,-80
    80002508:	e486                	sd	ra,72(sp)
    8000250a:	e0a2                	sd	s0,64(sp)
    8000250c:	fc26                	sd	s1,56(sp)
    8000250e:	f84a                	sd	s2,48(sp)
    80002510:	f44e                	sd	s3,40(sp)
    80002512:	f052                	sd	s4,32(sp)
    80002514:	ec56                	sd	s5,24(sp)
    80002516:	e85a                	sd	s6,16(sp)
    80002518:	e45e                	sd	s7,8(sp)
    8000251a:	e062                	sd	s8,0(sp)
    8000251c:	0880                	addi	s0,sp,80
    8000251e:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    80002520:	fffff097          	auipc	ra,0xfffff
    80002524:	576080e7          	jalr	1398(ra) # 80001a96 <myproc>
    80002528:	892a                	mv	s2,a0
  acquire(&wait_lock);
    8000252a:	0000e517          	auipc	a0,0xe
    8000252e:	6be50513          	addi	a0,a0,1726 # 80010be8 <wait_lock>
    80002532:	ffffe097          	auipc	ra,0xffffe
    80002536:	6a4080e7          	jalr	1700(ra) # 80000bd6 <acquire>
    havekids = 0;
    8000253a:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    8000253c:	4a15                	li	s4,5
        havekids = 1;
    8000253e:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002540:	00015997          	auipc	s3,0x15
    80002544:	94098993          	addi	s3,s3,-1728 # 80016e80 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002548:	0000ec17          	auipc	s8,0xe
    8000254c:	6a0c0c13          	addi	s8,s8,1696 # 80010be8 <wait_lock>
    havekids = 0;
    80002550:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002552:	0000f497          	auipc	s1,0xf
    80002556:	d2e48493          	addi	s1,s1,-722 # 80011280 <proc>
    8000255a:	a0bd                	j	800025c8 <wait+0xc2>
          pid = pp->pid;
    8000255c:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80002560:	000b0e63          	beqz	s6,8000257c <wait+0x76>
    80002564:	4691                	li	a3,4
    80002566:	02c48613          	addi	a2,s1,44
    8000256a:	85da                	mv	a1,s6
    8000256c:	05093503          	ld	a0,80(s2)
    80002570:	fffff097          	auipc	ra,0xfffff
    80002574:	1e6080e7          	jalr	486(ra) # 80001756 <copyout>
    80002578:	02054563          	bltz	a0,800025a2 <wait+0x9c>
          freeproc(pp);
    8000257c:	8526                	mv	a0,s1
    8000257e:	fffff097          	auipc	ra,0xfffff
    80002582:	6ca080e7          	jalr	1738(ra) # 80001c48 <freeproc>
          release(&pp->lock);
    80002586:	8526                	mv	a0,s1
    80002588:	ffffe097          	auipc	ra,0xffffe
    8000258c:	702080e7          	jalr	1794(ra) # 80000c8a <release>
          release(&wait_lock);
    80002590:	0000e517          	auipc	a0,0xe
    80002594:	65850513          	addi	a0,a0,1624 # 80010be8 <wait_lock>
    80002598:	ffffe097          	auipc	ra,0xffffe
    8000259c:	6f2080e7          	jalr	1778(ra) # 80000c8a <release>
          return pid;
    800025a0:	a0b5                	j	8000260c <wait+0x106>
            release(&pp->lock);
    800025a2:	8526                	mv	a0,s1
    800025a4:	ffffe097          	auipc	ra,0xffffe
    800025a8:	6e6080e7          	jalr	1766(ra) # 80000c8a <release>
            release(&wait_lock);
    800025ac:	0000e517          	auipc	a0,0xe
    800025b0:	63c50513          	addi	a0,a0,1596 # 80010be8 <wait_lock>
    800025b4:	ffffe097          	auipc	ra,0xffffe
    800025b8:	6d6080e7          	jalr	1750(ra) # 80000c8a <release>
            return -1;
    800025bc:	59fd                	li	s3,-1
    800025be:	a0b9                	j	8000260c <wait+0x106>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800025c0:	17048493          	addi	s1,s1,368
    800025c4:	03348463          	beq	s1,s3,800025ec <wait+0xe6>
      if(pp->parent == p){
    800025c8:	7c9c                	ld	a5,56(s1)
    800025ca:	ff279be3          	bne	a5,s2,800025c0 <wait+0xba>
        acquire(&pp->lock);
    800025ce:	8526                	mv	a0,s1
    800025d0:	ffffe097          	auipc	ra,0xffffe
    800025d4:	606080e7          	jalr	1542(ra) # 80000bd6 <acquire>
        if(pp->state == ZOMBIE){
    800025d8:	4c9c                	lw	a5,24(s1)
    800025da:	f94781e3          	beq	a5,s4,8000255c <wait+0x56>
        release(&pp->lock);
    800025de:	8526                	mv	a0,s1
    800025e0:	ffffe097          	auipc	ra,0xffffe
    800025e4:	6aa080e7          	jalr	1706(ra) # 80000c8a <release>
        havekids = 1;
    800025e8:	8756                	mv	a4,s5
    800025ea:	bfd9                	j	800025c0 <wait+0xba>
    if(!havekids || killed(p)){
    800025ec:	c719                	beqz	a4,800025fa <wait+0xf4>
    800025ee:	854a                	mv	a0,s2
    800025f0:	00000097          	auipc	ra,0x0
    800025f4:	ee4080e7          	jalr	-284(ra) # 800024d4 <killed>
    800025f8:	c51d                	beqz	a0,80002626 <wait+0x120>
      release(&wait_lock);
    800025fa:	0000e517          	auipc	a0,0xe
    800025fe:	5ee50513          	addi	a0,a0,1518 # 80010be8 <wait_lock>
    80002602:	ffffe097          	auipc	ra,0xffffe
    80002606:	688080e7          	jalr	1672(ra) # 80000c8a <release>
      return -1;
    8000260a:	59fd                	li	s3,-1
}
    8000260c:	854e                	mv	a0,s3
    8000260e:	60a6                	ld	ra,72(sp)
    80002610:	6406                	ld	s0,64(sp)
    80002612:	74e2                	ld	s1,56(sp)
    80002614:	7942                	ld	s2,48(sp)
    80002616:	79a2                	ld	s3,40(sp)
    80002618:	7a02                	ld	s4,32(sp)
    8000261a:	6ae2                	ld	s5,24(sp)
    8000261c:	6b42                	ld	s6,16(sp)
    8000261e:	6ba2                	ld	s7,8(sp)
    80002620:	6c02                	ld	s8,0(sp)
    80002622:	6161                	addi	sp,sp,80
    80002624:	8082                	ret
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002626:	85e2                	mv	a1,s8
    80002628:	854a                	mv	a0,s2
    8000262a:	00000097          	auipc	ra,0x0
    8000262e:	c02080e7          	jalr	-1022(ra) # 8000222c <sleep>
    havekids = 0;
    80002632:	bf39                	j	80002550 <wait+0x4a>

0000000080002634 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002634:	7179                	addi	sp,sp,-48
    80002636:	f406                	sd	ra,40(sp)
    80002638:	f022                	sd	s0,32(sp)
    8000263a:	ec26                	sd	s1,24(sp)
    8000263c:	e84a                	sd	s2,16(sp)
    8000263e:	e44e                	sd	s3,8(sp)
    80002640:	e052                	sd	s4,0(sp)
    80002642:	1800                	addi	s0,sp,48
    80002644:	84aa                	mv	s1,a0
    80002646:	892e                	mv	s2,a1
    80002648:	89b2                	mv	s3,a2
    8000264a:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    8000264c:	fffff097          	auipc	ra,0xfffff
    80002650:	44a080e7          	jalr	1098(ra) # 80001a96 <myproc>
  if(user_dst){
    80002654:	c08d                	beqz	s1,80002676 <either_copyout+0x42>
    return copyout(p->pagetable, dst, src, len);
    80002656:	86d2                	mv	a3,s4
    80002658:	864e                	mv	a2,s3
    8000265a:	85ca                	mv	a1,s2
    8000265c:	6928                	ld	a0,80(a0)
    8000265e:	fffff097          	auipc	ra,0xfffff
    80002662:	0f8080e7          	jalr	248(ra) # 80001756 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002666:	70a2                	ld	ra,40(sp)
    80002668:	7402                	ld	s0,32(sp)
    8000266a:	64e2                	ld	s1,24(sp)
    8000266c:	6942                	ld	s2,16(sp)
    8000266e:	69a2                	ld	s3,8(sp)
    80002670:	6a02                	ld	s4,0(sp)
    80002672:	6145                	addi	sp,sp,48
    80002674:	8082                	ret
    memmove((char *)dst, src, len);
    80002676:	000a061b          	sext.w	a2,s4
    8000267a:	85ce                	mv	a1,s3
    8000267c:	854a                	mv	a0,s2
    8000267e:	ffffe097          	auipc	ra,0xffffe
    80002682:	6b0080e7          	jalr	1712(ra) # 80000d2e <memmove>
    return 0;
    80002686:	8526                	mv	a0,s1
    80002688:	bff9                	j	80002666 <either_copyout+0x32>

000000008000268a <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    8000268a:	7179                	addi	sp,sp,-48
    8000268c:	f406                	sd	ra,40(sp)
    8000268e:	f022                	sd	s0,32(sp)
    80002690:	ec26                	sd	s1,24(sp)
    80002692:	e84a                	sd	s2,16(sp)
    80002694:	e44e                	sd	s3,8(sp)
    80002696:	e052                	sd	s4,0(sp)
    80002698:	1800                	addi	s0,sp,48
    8000269a:	892a                	mv	s2,a0
    8000269c:	84ae                	mv	s1,a1
    8000269e:	89b2                	mv	s3,a2
    800026a0:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800026a2:	fffff097          	auipc	ra,0xfffff
    800026a6:	3f4080e7          	jalr	1012(ra) # 80001a96 <myproc>
  if(user_src){
    800026aa:	c08d                	beqz	s1,800026cc <either_copyin+0x42>
    return copyin(p->pagetable, dst, src, len);
    800026ac:	86d2                	mv	a3,s4
    800026ae:	864e                	mv	a2,s3
    800026b0:	85ca                	mv	a1,s2
    800026b2:	6928                	ld	a0,80(a0)
    800026b4:	fffff097          	auipc	ra,0xfffff
    800026b8:	12e080e7          	jalr	302(ra) # 800017e2 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    800026bc:	70a2                	ld	ra,40(sp)
    800026be:	7402                	ld	s0,32(sp)
    800026c0:	64e2                	ld	s1,24(sp)
    800026c2:	6942                	ld	s2,16(sp)
    800026c4:	69a2                	ld	s3,8(sp)
    800026c6:	6a02                	ld	s4,0(sp)
    800026c8:	6145                	addi	sp,sp,48
    800026ca:	8082                	ret
    memmove(dst, (char*)src, len);
    800026cc:	000a061b          	sext.w	a2,s4
    800026d0:	85ce                	mv	a1,s3
    800026d2:	854a                	mv	a0,s2
    800026d4:	ffffe097          	auipc	ra,0xffffe
    800026d8:	65a080e7          	jalr	1626(ra) # 80000d2e <memmove>
    return 0;
    800026dc:	8526                	mv	a0,s1
    800026de:	bff9                	j	800026bc <either_copyin+0x32>

00000000800026e0 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800026e0:	715d                	addi	sp,sp,-80
    800026e2:	e486                	sd	ra,72(sp)
    800026e4:	e0a2                	sd	s0,64(sp)
    800026e6:	fc26                	sd	s1,56(sp)
    800026e8:	f84a                	sd	s2,48(sp)
    800026ea:	f44e                	sd	s3,40(sp)
    800026ec:	f052                	sd	s4,32(sp)
    800026ee:	ec56                	sd	s5,24(sp)
    800026f0:	e85a                	sd	s6,16(sp)
    800026f2:	e45e                	sd	s7,8(sp)
    800026f4:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800026f6:	00006517          	auipc	a0,0x6
    800026fa:	9d250513          	addi	a0,a0,-1582 # 800080c8 <digits+0x88>
    800026fe:	ffffe097          	auipc	ra,0xffffe
    80002702:	e8c080e7          	jalr	-372(ra) # 8000058a <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002706:	0000f497          	auipc	s1,0xf
    8000270a:	cd248493          	addi	s1,s1,-814 # 800113d8 <proc+0x158>
    8000270e:	00015917          	auipc	s2,0x15
    80002712:	8ca90913          	addi	s2,s2,-1846 # 80016fd8 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002716:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002718:	00006997          	auipc	s3,0x6
    8000271c:	bb098993          	addi	s3,s3,-1104 # 800082c8 <digits+0x288>
    printf("%d %s %s", p->pid, state, p->name);
    80002720:	00006a97          	auipc	s5,0x6
    80002724:	bb0a8a93          	addi	s5,s5,-1104 # 800082d0 <digits+0x290>
    printf("\n");
    80002728:	00006a17          	auipc	s4,0x6
    8000272c:	9a0a0a13          	addi	s4,s4,-1632 # 800080c8 <digits+0x88>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002730:	00006b97          	auipc	s7,0x6
    80002734:	be0b8b93          	addi	s7,s7,-1056 # 80008310 <states.0>
    80002738:	a00d                	j	8000275a <procdump+0x7a>
    printf("%d %s %s", p->pid, state, p->name);
    8000273a:	ed86a583          	lw	a1,-296(a3)
    8000273e:	8556                	mv	a0,s5
    80002740:	ffffe097          	auipc	ra,0xffffe
    80002744:	e4a080e7          	jalr	-438(ra) # 8000058a <printf>
    printf("\n");
    80002748:	8552                	mv	a0,s4
    8000274a:	ffffe097          	auipc	ra,0xffffe
    8000274e:	e40080e7          	jalr	-448(ra) # 8000058a <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002752:	17048493          	addi	s1,s1,368
    80002756:	03248263          	beq	s1,s2,8000277a <procdump+0x9a>
    if(p->state == UNUSED)
    8000275a:	86a6                	mv	a3,s1
    8000275c:	ec04a783          	lw	a5,-320(s1)
    80002760:	dbed                	beqz	a5,80002752 <procdump+0x72>
      state = "???";
    80002762:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002764:	fcfb6be3          	bltu	s6,a5,8000273a <procdump+0x5a>
    80002768:	02079713          	slli	a4,a5,0x20
    8000276c:	01d75793          	srli	a5,a4,0x1d
    80002770:	97de                	add	a5,a5,s7
    80002772:	6390                	ld	a2,0(a5)
    80002774:	f279                	bnez	a2,8000273a <procdump+0x5a>
      state = "???";
    80002776:	864e                	mv	a2,s3
    80002778:	b7c9                	j	8000273a <procdump+0x5a>
  }
}
    8000277a:	60a6                	ld	ra,72(sp)
    8000277c:	6406                	ld	s0,64(sp)
    8000277e:	74e2                	ld	s1,56(sp)
    80002780:	7942                	ld	s2,48(sp)
    80002782:	79a2                	ld	s3,40(sp)
    80002784:	7a02                	ld	s4,32(sp)
    80002786:	6ae2                	ld	s5,24(sp)
    80002788:	6b42                	ld	s6,16(sp)
    8000278a:	6ba2                	ld	s7,8(sp)
    8000278c:	6161                	addi	sp,sp,80
    8000278e:	8082                	ret

0000000080002790 <swtch>:
    80002790:	00153023          	sd	ra,0(a0)
    80002794:	00253423          	sd	sp,8(a0)
    80002798:	e900                	sd	s0,16(a0)
    8000279a:	ed04                	sd	s1,24(a0)
    8000279c:	03253023          	sd	s2,32(a0)
    800027a0:	03353423          	sd	s3,40(a0)
    800027a4:	03453823          	sd	s4,48(a0)
    800027a8:	03553c23          	sd	s5,56(a0)
    800027ac:	05653023          	sd	s6,64(a0)
    800027b0:	05753423          	sd	s7,72(a0)
    800027b4:	05853823          	sd	s8,80(a0)
    800027b8:	05953c23          	sd	s9,88(a0)
    800027bc:	07a53023          	sd	s10,96(a0)
    800027c0:	07b53423          	sd	s11,104(a0)
    800027c4:	0005b083          	ld	ra,0(a1)
    800027c8:	0085b103          	ld	sp,8(a1)
    800027cc:	6980                	ld	s0,16(a1)
    800027ce:	6d84                	ld	s1,24(a1)
    800027d0:	0205b903          	ld	s2,32(a1)
    800027d4:	0285b983          	ld	s3,40(a1)
    800027d8:	0305ba03          	ld	s4,48(a1)
    800027dc:	0385ba83          	ld	s5,56(a1)
    800027e0:	0405bb03          	ld	s6,64(a1)
    800027e4:	0485bb83          	ld	s7,72(a1)
    800027e8:	0505bc03          	ld	s8,80(a1)
    800027ec:	0585bc83          	ld	s9,88(a1)
    800027f0:	0605bd03          	ld	s10,96(a1)
    800027f4:	0685bd83          	ld	s11,104(a1)
    800027f8:	8082                	ret

00000000800027fa <trapinit>:

extern int devintr();

void
trapinit(void)
{
    800027fa:	1141                	addi	sp,sp,-16
    800027fc:	e406                	sd	ra,8(sp)
    800027fe:	e022                	sd	s0,0(sp)
    80002800:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002802:	00006597          	auipc	a1,0x6
    80002806:	b3e58593          	addi	a1,a1,-1218 # 80008340 <states.0+0x30>
    8000280a:	00014517          	auipc	a0,0x14
    8000280e:	67650513          	addi	a0,a0,1654 # 80016e80 <tickslock>
    80002812:	ffffe097          	auipc	ra,0xffffe
    80002816:	334080e7          	jalr	820(ra) # 80000b46 <initlock>
}
    8000281a:	60a2                	ld	ra,8(sp)
    8000281c:	6402                	ld	s0,0(sp)
    8000281e:	0141                	addi	sp,sp,16
    80002820:	8082                	ret

0000000080002822 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002822:	1141                	addi	sp,sp,-16
    80002824:	e422                	sd	s0,8(sp)
    80002826:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002828:	00003797          	auipc	a5,0x3
    8000282c:	51878793          	addi	a5,a5,1304 # 80005d40 <kernelvec>
    80002830:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002834:	6422                	ld	s0,8(sp)
    80002836:	0141                	addi	sp,sp,16
    80002838:	8082                	ret

000000008000283a <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    8000283a:	1141                	addi	sp,sp,-16
    8000283c:	e406                	sd	ra,8(sp)
    8000283e:	e022                	sd	s0,0(sp)
    80002840:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002842:	fffff097          	auipc	ra,0xfffff
    80002846:	254080e7          	jalr	596(ra) # 80001a96 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000284a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000284e:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002850:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002854:	00004697          	auipc	a3,0x4
    80002858:	7ac68693          	addi	a3,a3,1964 # 80007000 <_trampoline>
    8000285c:	00004717          	auipc	a4,0x4
    80002860:	7a470713          	addi	a4,a4,1956 # 80007000 <_trampoline>
    80002864:	8f15                	sub	a4,a4,a3
    80002866:	040007b7          	lui	a5,0x4000
    8000286a:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    8000286c:	07b2                	slli	a5,a5,0xc
    8000286e:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002870:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002874:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80002876:	18002673          	csrr	a2,satp
    8000287a:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    8000287c:	6d30                	ld	a2,88(a0)
    8000287e:	6138                	ld	a4,64(a0)
    80002880:	6585                	lui	a1,0x1
    80002882:	972e                	add	a4,a4,a1
    80002884:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002886:	6d38                	ld	a4,88(a0)
    80002888:	00000617          	auipc	a2,0x0
    8000288c:	13060613          	addi	a2,a2,304 # 800029b8 <usertrap>
    80002890:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80002892:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80002894:	8612                	mv	a2,tp
    80002896:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002898:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000289c:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800028a0:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800028a4:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800028a8:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    800028aa:	6f18                	ld	a4,24(a4)
    800028ac:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    800028b0:	6928                	ld	a0,80(a0)
    800028b2:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800028b4:	00004717          	auipc	a4,0x4
    800028b8:	7e870713          	addi	a4,a4,2024 # 8000709c <userret>
    800028bc:	8f15                	sub	a4,a4,a3
    800028be:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800028c0:	577d                	li	a4,-1
    800028c2:	177e                	slli	a4,a4,0x3f
    800028c4:	8d59                	or	a0,a0,a4
    800028c6:	9782                	jalr	a5
}
    800028c8:	60a2                	ld	ra,8(sp)
    800028ca:	6402                	ld	s0,0(sp)
    800028cc:	0141                	addi	sp,sp,16
    800028ce:	8082                	ret

00000000800028d0 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800028d0:	1101                	addi	sp,sp,-32
    800028d2:	ec06                	sd	ra,24(sp)
    800028d4:	e822                	sd	s0,16(sp)
    800028d6:	e426                	sd	s1,8(sp)
    800028d8:	1000                	addi	s0,sp,32
  acquire(&tickslock);
    800028da:	00014497          	auipc	s1,0x14
    800028de:	5a648493          	addi	s1,s1,1446 # 80016e80 <tickslock>
    800028e2:	8526                	mv	a0,s1
    800028e4:	ffffe097          	auipc	ra,0xffffe
    800028e8:	2f2080e7          	jalr	754(ra) # 80000bd6 <acquire>
  ticks++;
    800028ec:	00006517          	auipc	a0,0x6
    800028f0:	07c50513          	addi	a0,a0,124 # 80008968 <ticks>
    800028f4:	411c                	lw	a5,0(a0)
    800028f6:	2785                	addiw	a5,a5,1
    800028f8:	c11c                	sw	a5,0(a0)
  wakeup(&ticks);
    800028fa:	00000097          	auipc	ra,0x0
    800028fe:	996080e7          	jalr	-1642(ra) # 80002290 <wakeup>
  release(&tickslock);
    80002902:	8526                	mv	a0,s1
    80002904:	ffffe097          	auipc	ra,0xffffe
    80002908:	386080e7          	jalr	902(ra) # 80000c8a <release>
}
    8000290c:	60e2                	ld	ra,24(sp)
    8000290e:	6442                	ld	s0,16(sp)
    80002910:	64a2                	ld	s1,8(sp)
    80002912:	6105                	addi	sp,sp,32
    80002914:	8082                	ret

0000000080002916 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002916:	1101                	addi	sp,sp,-32
    80002918:	ec06                	sd	ra,24(sp)
    8000291a:	e822                	sd	s0,16(sp)
    8000291c:	e426                	sd	s1,8(sp)
    8000291e:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002920:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if((scause & 0x8000000000000000L) &&
    80002924:	00074d63          	bltz	a4,8000293e <devintr+0x28>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000001L){
    80002928:	57fd                	li	a5,-1
    8000292a:	17fe                	slli	a5,a5,0x3f
    8000292c:	0785                	addi	a5,a5,1
    // the SSIP bit in sip.
    w_sip(r_sip() & ~2);

    return 2;
  } else {
    return 0;
    8000292e:	4501                	li	a0,0
  } else if(scause == 0x8000000000000001L){
    80002930:	06f70363          	beq	a4,a5,80002996 <devintr+0x80>
  }
}
    80002934:	60e2                	ld	ra,24(sp)
    80002936:	6442                	ld	s0,16(sp)
    80002938:	64a2                	ld	s1,8(sp)
    8000293a:	6105                	addi	sp,sp,32
    8000293c:	8082                	ret
     (scause & 0xff) == 9){
    8000293e:	0ff77793          	zext.b	a5,a4
  if((scause & 0x8000000000000000L) &&
    80002942:	46a5                	li	a3,9
    80002944:	fed792e3          	bne	a5,a3,80002928 <devintr+0x12>
    int irq = plic_claim();
    80002948:	00003097          	auipc	ra,0x3
    8000294c:	500080e7          	jalr	1280(ra) # 80005e48 <plic_claim>
    80002950:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002952:	47a9                	li	a5,10
    80002954:	02f50763          	beq	a0,a5,80002982 <devintr+0x6c>
    } else if(irq == VIRTIO0_IRQ){
    80002958:	4785                	li	a5,1
    8000295a:	02f50963          	beq	a0,a5,8000298c <devintr+0x76>
    return 1;
    8000295e:	4505                	li	a0,1
    } else if(irq){
    80002960:	d8f1                	beqz	s1,80002934 <devintr+0x1e>
      printf("unexpected interrupt irq=%d\n", irq);
    80002962:	85a6                	mv	a1,s1
    80002964:	00006517          	auipc	a0,0x6
    80002968:	9e450513          	addi	a0,a0,-1564 # 80008348 <states.0+0x38>
    8000296c:	ffffe097          	auipc	ra,0xffffe
    80002970:	c1e080e7          	jalr	-994(ra) # 8000058a <printf>
      plic_complete(irq);
    80002974:	8526                	mv	a0,s1
    80002976:	00003097          	auipc	ra,0x3
    8000297a:	4f6080e7          	jalr	1270(ra) # 80005e6c <plic_complete>
    return 1;
    8000297e:	4505                	li	a0,1
    80002980:	bf55                	j	80002934 <devintr+0x1e>
      uartintr();
    80002982:	ffffe097          	auipc	ra,0xffffe
    80002986:	016080e7          	jalr	22(ra) # 80000998 <uartintr>
    8000298a:	b7ed                	j	80002974 <devintr+0x5e>
      virtio_disk_intr();
    8000298c:	00004097          	auipc	ra,0x4
    80002990:	9a8080e7          	jalr	-1624(ra) # 80006334 <virtio_disk_intr>
    80002994:	b7c5                	j	80002974 <devintr+0x5e>
    if(cpuid() == 0){
    80002996:	fffff097          	auipc	ra,0xfffff
    8000299a:	0d4080e7          	jalr	212(ra) # 80001a6a <cpuid>
    8000299e:	c901                	beqz	a0,800029ae <devintr+0x98>
  asm volatile("csrr %0, sip" : "=r" (x) );
    800029a0:	144027f3          	csrr	a5,sip
    w_sip(r_sip() & ~2);
    800029a4:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sip, %0" : : "r" (x));
    800029a6:	14479073          	csrw	sip,a5
    return 2;
    800029aa:	4509                	li	a0,2
    800029ac:	b761                	j	80002934 <devintr+0x1e>
      clockintr();
    800029ae:	00000097          	auipc	ra,0x0
    800029b2:	f22080e7          	jalr	-222(ra) # 800028d0 <clockintr>
    800029b6:	b7ed                	j	800029a0 <devintr+0x8a>

00000000800029b8 <usertrap>:
{
    800029b8:	1101                	addi	sp,sp,-32
    800029ba:	ec06                	sd	ra,24(sp)
    800029bc:	e822                	sd	s0,16(sp)
    800029be:	e426                	sd	s1,8(sp)
    800029c0:	e04a                	sd	s2,0(sp)
    800029c2:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800029c4:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    800029c8:	1007f793          	andi	a5,a5,256
    800029cc:	e3b1                	bnez	a5,80002a10 <usertrap+0x58>
  asm volatile("csrw stvec, %0" : : "r" (x));
    800029ce:	00003797          	auipc	a5,0x3
    800029d2:	37278793          	addi	a5,a5,882 # 80005d40 <kernelvec>
    800029d6:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800029da:	fffff097          	auipc	ra,0xfffff
    800029de:	0bc080e7          	jalr	188(ra) # 80001a96 <myproc>
    800029e2:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800029e4:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800029e6:	14102773          	csrr	a4,sepc
    800029ea:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    800029ec:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800029f0:	47a1                	li	a5,8
    800029f2:	02f70763          	beq	a4,a5,80002a20 <usertrap+0x68>
  } else if((which_dev = devintr()) != 0){
    800029f6:	00000097          	auipc	ra,0x0
    800029fa:	f20080e7          	jalr	-224(ra) # 80002916 <devintr>
    800029fe:	892a                	mv	s2,a0
    80002a00:	c151                	beqz	a0,80002a84 <usertrap+0xcc>
  if(killed(p))
    80002a02:	8526                	mv	a0,s1
    80002a04:	00000097          	auipc	ra,0x0
    80002a08:	ad0080e7          	jalr	-1328(ra) # 800024d4 <killed>
    80002a0c:	c929                	beqz	a0,80002a5e <usertrap+0xa6>
    80002a0e:	a099                	j	80002a54 <usertrap+0x9c>
    panic("usertrap: not from user mode");
    80002a10:	00006517          	auipc	a0,0x6
    80002a14:	95850513          	addi	a0,a0,-1704 # 80008368 <states.0+0x58>
    80002a18:	ffffe097          	auipc	ra,0xffffe
    80002a1c:	b28080e7          	jalr	-1240(ra) # 80000540 <panic>
    if(killed(p))
    80002a20:	00000097          	auipc	ra,0x0
    80002a24:	ab4080e7          	jalr	-1356(ra) # 800024d4 <killed>
    80002a28:	e921                	bnez	a0,80002a78 <usertrap+0xc0>
    p->trapframe->epc += 4;
    80002a2a:	6cb8                	ld	a4,88(s1)
    80002a2c:	6f1c                	ld	a5,24(a4)
    80002a2e:	0791                	addi	a5,a5,4
    80002a30:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002a32:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80002a36:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002a3a:	10079073          	csrw	sstatus,a5
    syscall();
    80002a3e:	00000097          	auipc	ra,0x0
    80002a42:	2d4080e7          	jalr	724(ra) # 80002d12 <syscall>
  if(killed(p))
    80002a46:	8526                	mv	a0,s1
    80002a48:	00000097          	auipc	ra,0x0
    80002a4c:	a8c080e7          	jalr	-1396(ra) # 800024d4 <killed>
    80002a50:	c911                	beqz	a0,80002a64 <usertrap+0xac>
    80002a52:	4901                	li	s2,0
    exit(-1);
    80002a54:	557d                	li	a0,-1
    80002a56:	00000097          	auipc	ra,0x0
    80002a5a:	90a080e7          	jalr	-1782(ra) # 80002360 <exit>
  if(which_dev == 2)
    80002a5e:	4789                	li	a5,2
    80002a60:	04f90f63          	beq	s2,a5,80002abe <usertrap+0x106>
  usertrapret();
    80002a64:	00000097          	auipc	ra,0x0
    80002a68:	dd6080e7          	jalr	-554(ra) # 8000283a <usertrapret>
}
    80002a6c:	60e2                	ld	ra,24(sp)
    80002a6e:	6442                	ld	s0,16(sp)
    80002a70:	64a2                	ld	s1,8(sp)
    80002a72:	6902                	ld	s2,0(sp)
    80002a74:	6105                	addi	sp,sp,32
    80002a76:	8082                	ret
      exit(-1);
    80002a78:	557d                	li	a0,-1
    80002a7a:	00000097          	auipc	ra,0x0
    80002a7e:	8e6080e7          	jalr	-1818(ra) # 80002360 <exit>
    80002a82:	b765                	j	80002a2a <usertrap+0x72>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002a84:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause %p pid=%d\n", r_scause(), p->pid);
    80002a88:	5890                	lw	a2,48(s1)
    80002a8a:	00006517          	auipc	a0,0x6
    80002a8e:	8fe50513          	addi	a0,a0,-1794 # 80008388 <states.0+0x78>
    80002a92:	ffffe097          	auipc	ra,0xffffe
    80002a96:	af8080e7          	jalr	-1288(ra) # 8000058a <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002a9a:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002a9e:	14302673          	csrr	a2,stval
    printf("            sepc=%p stval=%p\n", r_sepc(), r_stval());
    80002aa2:	00006517          	auipc	a0,0x6
    80002aa6:	91650513          	addi	a0,a0,-1770 # 800083b8 <states.0+0xa8>
    80002aaa:	ffffe097          	auipc	ra,0xffffe
    80002aae:	ae0080e7          	jalr	-1312(ra) # 8000058a <printf>
    setkilled(p);
    80002ab2:	8526                	mv	a0,s1
    80002ab4:	00000097          	auipc	ra,0x0
    80002ab8:	9f4080e7          	jalr	-1548(ra) # 800024a8 <setkilled>
    80002abc:	b769                	j	80002a46 <usertrap+0x8e>
    yield();
    80002abe:	fffff097          	auipc	ra,0xfffff
    80002ac2:	732080e7          	jalr	1842(ra) # 800021f0 <yield>
    80002ac6:	bf79                	j	80002a64 <usertrap+0xac>

0000000080002ac8 <kerneltrap>:
{
    80002ac8:	7179                	addi	sp,sp,-48
    80002aca:	f406                	sd	ra,40(sp)
    80002acc:	f022                	sd	s0,32(sp)
    80002ace:	ec26                	sd	s1,24(sp)
    80002ad0:	e84a                	sd	s2,16(sp)
    80002ad2:	e44e                	sd	s3,8(sp)
    80002ad4:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002ad6:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002ada:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002ade:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    80002ae2:	1004f793          	andi	a5,s1,256
    80002ae6:	cb85                	beqz	a5,80002b16 <kerneltrap+0x4e>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002ae8:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002aec:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80002aee:	ef85                	bnez	a5,80002b26 <kerneltrap+0x5e>
  if((which_dev = devintr()) == 0){
    80002af0:	00000097          	auipc	ra,0x0
    80002af4:	e26080e7          	jalr	-474(ra) # 80002916 <devintr>
    80002af8:	cd1d                	beqz	a0,80002b36 <kerneltrap+0x6e>
  if(which_dev == 2 && myproc() != 0 && myproc()->state == RUNNING)
    80002afa:	4789                	li	a5,2
    80002afc:	06f50a63          	beq	a0,a5,80002b70 <kerneltrap+0xa8>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002b00:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002b04:	10049073          	csrw	sstatus,s1
}
    80002b08:	70a2                	ld	ra,40(sp)
    80002b0a:	7402                	ld	s0,32(sp)
    80002b0c:	64e2                	ld	s1,24(sp)
    80002b0e:	6942                	ld	s2,16(sp)
    80002b10:	69a2                	ld	s3,8(sp)
    80002b12:	6145                	addi	sp,sp,48
    80002b14:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002b16:	00006517          	auipc	a0,0x6
    80002b1a:	8c250513          	addi	a0,a0,-1854 # 800083d8 <states.0+0xc8>
    80002b1e:	ffffe097          	auipc	ra,0xffffe
    80002b22:	a22080e7          	jalr	-1502(ra) # 80000540 <panic>
    panic("kerneltrap: interrupts enabled");
    80002b26:	00006517          	auipc	a0,0x6
    80002b2a:	8da50513          	addi	a0,a0,-1830 # 80008400 <states.0+0xf0>
    80002b2e:	ffffe097          	auipc	ra,0xffffe
    80002b32:	a12080e7          	jalr	-1518(ra) # 80000540 <panic>
    printf("scause %p\n", scause);
    80002b36:	85ce                	mv	a1,s3
    80002b38:	00006517          	auipc	a0,0x6
    80002b3c:	8e850513          	addi	a0,a0,-1816 # 80008420 <states.0+0x110>
    80002b40:	ffffe097          	auipc	ra,0xffffe
    80002b44:	a4a080e7          	jalr	-1462(ra) # 8000058a <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002b48:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002b4c:	14302673          	csrr	a2,stval
    printf("sepc=%p stval=%p\n", r_sepc(), r_stval());
    80002b50:	00006517          	auipc	a0,0x6
    80002b54:	8e050513          	addi	a0,a0,-1824 # 80008430 <states.0+0x120>
    80002b58:	ffffe097          	auipc	ra,0xffffe
    80002b5c:	a32080e7          	jalr	-1486(ra) # 8000058a <printf>
    panic("kerneltrap");
    80002b60:	00006517          	auipc	a0,0x6
    80002b64:	8e850513          	addi	a0,a0,-1816 # 80008448 <states.0+0x138>
    80002b68:	ffffe097          	auipc	ra,0xffffe
    80002b6c:	9d8080e7          	jalr	-1576(ra) # 80000540 <panic>
  if(which_dev == 2 && myproc() != 0 && myproc()->state == RUNNING)
    80002b70:	fffff097          	auipc	ra,0xfffff
    80002b74:	f26080e7          	jalr	-218(ra) # 80001a96 <myproc>
    80002b78:	d541                	beqz	a0,80002b00 <kerneltrap+0x38>
    80002b7a:	fffff097          	auipc	ra,0xfffff
    80002b7e:	f1c080e7          	jalr	-228(ra) # 80001a96 <myproc>
    80002b82:	4d18                	lw	a4,24(a0)
    80002b84:	4791                	li	a5,4
    80002b86:	f6f71de3          	bne	a4,a5,80002b00 <kerneltrap+0x38>
    yield();
    80002b8a:	fffff097          	auipc	ra,0xfffff
    80002b8e:	666080e7          	jalr	1638(ra) # 800021f0 <yield>
    80002b92:	b7bd                	j	80002b00 <kerneltrap+0x38>

0000000080002b94 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002b94:	1101                	addi	sp,sp,-32
    80002b96:	ec06                	sd	ra,24(sp)
    80002b98:	e822                	sd	s0,16(sp)
    80002b9a:	e426                	sd	s1,8(sp)
    80002b9c:	1000                	addi	s0,sp,32
    80002b9e:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002ba0:	fffff097          	auipc	ra,0xfffff
    80002ba4:	ef6080e7          	jalr	-266(ra) # 80001a96 <myproc>
  switch (n) {
    80002ba8:	4795                	li	a5,5
    80002baa:	0497e163          	bltu	a5,s1,80002bec <argraw+0x58>
    80002bae:	048a                	slli	s1,s1,0x2
    80002bb0:	00006717          	auipc	a4,0x6
    80002bb4:	8d070713          	addi	a4,a4,-1840 # 80008480 <states.0+0x170>
    80002bb8:	94ba                	add	s1,s1,a4
    80002bba:	409c                	lw	a5,0(s1)
    80002bbc:	97ba                	add	a5,a5,a4
    80002bbe:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002bc0:	6d3c                	ld	a5,88(a0)
    80002bc2:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002bc4:	60e2                	ld	ra,24(sp)
    80002bc6:	6442                	ld	s0,16(sp)
    80002bc8:	64a2                	ld	s1,8(sp)
    80002bca:	6105                	addi	sp,sp,32
    80002bcc:	8082                	ret
    return p->trapframe->a1;
    80002bce:	6d3c                	ld	a5,88(a0)
    80002bd0:	7fa8                	ld	a0,120(a5)
    80002bd2:	bfcd                	j	80002bc4 <argraw+0x30>
    return p->trapframe->a2;
    80002bd4:	6d3c                	ld	a5,88(a0)
    80002bd6:	63c8                	ld	a0,128(a5)
    80002bd8:	b7f5                	j	80002bc4 <argraw+0x30>
    return p->trapframe->a3;
    80002bda:	6d3c                	ld	a5,88(a0)
    80002bdc:	67c8                	ld	a0,136(a5)
    80002bde:	b7dd                	j	80002bc4 <argraw+0x30>
    return p->trapframe->a4;
    80002be0:	6d3c                	ld	a5,88(a0)
    80002be2:	6bc8                	ld	a0,144(a5)
    80002be4:	b7c5                	j	80002bc4 <argraw+0x30>
    return p->trapframe->a5;
    80002be6:	6d3c                	ld	a5,88(a0)
    80002be8:	6fc8                	ld	a0,152(a5)
    80002bea:	bfe9                	j	80002bc4 <argraw+0x30>
  panic("argraw");
    80002bec:	00006517          	auipc	a0,0x6
    80002bf0:	86c50513          	addi	a0,a0,-1940 # 80008458 <states.0+0x148>
    80002bf4:	ffffe097          	auipc	ra,0xffffe
    80002bf8:	94c080e7          	jalr	-1716(ra) # 80000540 <panic>

0000000080002bfc <fetchaddr>:
{
    80002bfc:	1101                	addi	sp,sp,-32
    80002bfe:	ec06                	sd	ra,24(sp)
    80002c00:	e822                	sd	s0,16(sp)
    80002c02:	e426                	sd	s1,8(sp)
    80002c04:	e04a                	sd	s2,0(sp)
    80002c06:	1000                	addi	s0,sp,32
    80002c08:	84aa                	mv	s1,a0
    80002c0a:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002c0c:	fffff097          	auipc	ra,0xfffff
    80002c10:	e8a080e7          	jalr	-374(ra) # 80001a96 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002c14:	653c                	ld	a5,72(a0)
    80002c16:	02f4f863          	bgeu	s1,a5,80002c46 <fetchaddr+0x4a>
    80002c1a:	00848713          	addi	a4,s1,8
    80002c1e:	02e7e663          	bltu	a5,a4,80002c4a <fetchaddr+0x4e>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80002c22:	46a1                	li	a3,8
    80002c24:	8626                	mv	a2,s1
    80002c26:	85ca                	mv	a1,s2
    80002c28:	6928                	ld	a0,80(a0)
    80002c2a:	fffff097          	auipc	ra,0xfffff
    80002c2e:	bb8080e7          	jalr	-1096(ra) # 800017e2 <copyin>
    80002c32:	00a03533          	snez	a0,a0
    80002c36:	40a00533          	neg	a0,a0
}
    80002c3a:	60e2                	ld	ra,24(sp)
    80002c3c:	6442                	ld	s0,16(sp)
    80002c3e:	64a2                	ld	s1,8(sp)
    80002c40:	6902                	ld	s2,0(sp)
    80002c42:	6105                	addi	sp,sp,32
    80002c44:	8082                	ret
    return -1;
    80002c46:	557d                	li	a0,-1
    80002c48:	bfcd                	j	80002c3a <fetchaddr+0x3e>
    80002c4a:	557d                	li	a0,-1
    80002c4c:	b7fd                	j	80002c3a <fetchaddr+0x3e>

0000000080002c4e <fetchstr>:
{
    80002c4e:	7179                	addi	sp,sp,-48
    80002c50:	f406                	sd	ra,40(sp)
    80002c52:	f022                	sd	s0,32(sp)
    80002c54:	ec26                	sd	s1,24(sp)
    80002c56:	e84a                	sd	s2,16(sp)
    80002c58:	e44e                	sd	s3,8(sp)
    80002c5a:	1800                	addi	s0,sp,48
    80002c5c:	892a                	mv	s2,a0
    80002c5e:	84ae                	mv	s1,a1
    80002c60:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80002c62:	fffff097          	auipc	ra,0xfffff
    80002c66:	e34080e7          	jalr	-460(ra) # 80001a96 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80002c6a:	86ce                	mv	a3,s3
    80002c6c:	864a                	mv	a2,s2
    80002c6e:	85a6                	mv	a1,s1
    80002c70:	6928                	ld	a0,80(a0)
    80002c72:	fffff097          	auipc	ra,0xfffff
    80002c76:	bfe080e7          	jalr	-1026(ra) # 80001870 <copyinstr>
    80002c7a:	00054e63          	bltz	a0,80002c96 <fetchstr+0x48>
  return strlen(buf);
    80002c7e:	8526                	mv	a0,s1
    80002c80:	ffffe097          	auipc	ra,0xffffe
    80002c84:	1ce080e7          	jalr	462(ra) # 80000e4e <strlen>
}
    80002c88:	70a2                	ld	ra,40(sp)
    80002c8a:	7402                	ld	s0,32(sp)
    80002c8c:	64e2                	ld	s1,24(sp)
    80002c8e:	6942                	ld	s2,16(sp)
    80002c90:	69a2                	ld	s3,8(sp)
    80002c92:	6145                	addi	sp,sp,48
    80002c94:	8082                	ret
    return -1;
    80002c96:	557d                	li	a0,-1
    80002c98:	bfc5                	j	80002c88 <fetchstr+0x3a>

0000000080002c9a <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002c9a:	1101                	addi	sp,sp,-32
    80002c9c:	ec06                	sd	ra,24(sp)
    80002c9e:	e822                	sd	s0,16(sp)
    80002ca0:	e426                	sd	s1,8(sp)
    80002ca2:	1000                	addi	s0,sp,32
    80002ca4:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002ca6:	00000097          	auipc	ra,0x0
    80002caa:	eee080e7          	jalr	-274(ra) # 80002b94 <argraw>
    80002cae:	c088                	sw	a0,0(s1)
}
    80002cb0:	60e2                	ld	ra,24(sp)
    80002cb2:	6442                	ld	s0,16(sp)
    80002cb4:	64a2                	ld	s1,8(sp)
    80002cb6:	6105                	addi	sp,sp,32
    80002cb8:	8082                	ret

0000000080002cba <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002cba:	1101                	addi	sp,sp,-32
    80002cbc:	ec06                	sd	ra,24(sp)
    80002cbe:	e822                	sd	s0,16(sp)
    80002cc0:	e426                	sd	s1,8(sp)
    80002cc2:	1000                	addi	s0,sp,32
    80002cc4:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002cc6:	00000097          	auipc	ra,0x0
    80002cca:	ece080e7          	jalr	-306(ra) # 80002b94 <argraw>
    80002cce:	e088                	sd	a0,0(s1)
}
    80002cd0:	60e2                	ld	ra,24(sp)
    80002cd2:	6442                	ld	s0,16(sp)
    80002cd4:	64a2                	ld	s1,8(sp)
    80002cd6:	6105                	addi	sp,sp,32
    80002cd8:	8082                	ret

0000000080002cda <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002cda:	7179                	addi	sp,sp,-48
    80002cdc:	f406                	sd	ra,40(sp)
    80002cde:	f022                	sd	s0,32(sp)
    80002ce0:	ec26                	sd	s1,24(sp)
    80002ce2:	e84a                	sd	s2,16(sp)
    80002ce4:	1800                	addi	s0,sp,48
    80002ce6:	84ae                	mv	s1,a1
    80002ce8:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002cea:	fd840593          	addi	a1,s0,-40
    80002cee:	00000097          	auipc	ra,0x0
    80002cf2:	fcc080e7          	jalr	-52(ra) # 80002cba <argaddr>
  return fetchstr(addr, buf, max);
    80002cf6:	864a                	mv	a2,s2
    80002cf8:	85a6                	mv	a1,s1
    80002cfa:	fd843503          	ld	a0,-40(s0)
    80002cfe:	00000097          	auipc	ra,0x0
    80002d02:	f50080e7          	jalr	-176(ra) # 80002c4e <fetchstr>
}
    80002d06:	70a2                	ld	ra,40(sp)
    80002d08:	7402                	ld	s0,32(sp)
    80002d0a:	64e2                	ld	s1,24(sp)
    80002d0c:	6942                	ld	s2,16(sp)
    80002d0e:	6145                	addi	sp,sp,48
    80002d10:	8082                	ret

0000000080002d12 <syscall>:
[SYS_prtpgtbl] sys_prtpgtble
};

void
syscall(void)
{
    80002d12:	1101                	addi	sp,sp,-32
    80002d14:	ec06                	sd	ra,24(sp)
    80002d16:	e822                	sd	s0,16(sp)
    80002d18:	e426                	sd	s1,8(sp)
    80002d1a:	e04a                	sd	s2,0(sp)
    80002d1c:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002d1e:	fffff097          	auipc	ra,0xfffff
    80002d22:	d78080e7          	jalr	-648(ra) # 80001a96 <myproc>
    80002d26:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002d28:	05853903          	ld	s2,88(a0)
    80002d2c:	0a893783          	ld	a5,168(s2)
    80002d30:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002d34:	37fd                	addiw	a5,a5,-1
    80002d36:	4759                	li	a4,22
    80002d38:	00f76f63          	bltu	a4,a5,80002d56 <syscall+0x44>
    80002d3c:	00369713          	slli	a4,a3,0x3
    80002d40:	00005797          	auipc	a5,0x5
    80002d44:	75878793          	addi	a5,a5,1880 # 80008498 <syscalls>
    80002d48:	97ba                	add	a5,a5,a4
    80002d4a:	639c                	ld	a5,0(a5)
    80002d4c:	c789                	beqz	a5,80002d56 <syscall+0x44>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002d4e:	9782                	jalr	a5
    80002d50:	06a93823          	sd	a0,112(s2)
    80002d54:	a839                	j	80002d72 <syscall+0x60>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002d56:	15848613          	addi	a2,s1,344
    80002d5a:	588c                	lw	a1,48(s1)
    80002d5c:	00005517          	auipc	a0,0x5
    80002d60:	70450513          	addi	a0,a0,1796 # 80008460 <states.0+0x150>
    80002d64:	ffffe097          	auipc	ra,0xffffe
    80002d68:	826080e7          	jalr	-2010(ra) # 8000058a <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002d6c:	6cbc                	ld	a5,88(s1)
    80002d6e:	577d                	li	a4,-1
    80002d70:	fbb8                	sd	a4,112(a5)
  }
}
    80002d72:	60e2                	ld	ra,24(sp)
    80002d74:	6442                	ld	s0,16(sp)
    80002d76:	64a2                	ld	s1,8(sp)
    80002d78:	6902                	ld	s2,0(sp)
    80002d7a:	6105                	addi	sp,sp,32
    80002d7c:	8082                	ret

0000000080002d7e <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80002d7e:	1101                	addi	sp,sp,-32
    80002d80:	ec06                	sd	ra,24(sp)
    80002d82:	e822                	sd	s0,16(sp)
    80002d84:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002d86:	fec40593          	addi	a1,s0,-20
    80002d8a:	4501                	li	a0,0
    80002d8c:	00000097          	auipc	ra,0x0
    80002d90:	f0e080e7          	jalr	-242(ra) # 80002c9a <argint>
  exit(n);
    80002d94:	fec42503          	lw	a0,-20(s0)
    80002d98:	fffff097          	auipc	ra,0xfffff
    80002d9c:	5c8080e7          	jalr	1480(ra) # 80002360 <exit>
  return 0;  // not reached
}
    80002da0:	4501                	li	a0,0
    80002da2:	60e2                	ld	ra,24(sp)
    80002da4:	6442                	ld	s0,16(sp)
    80002da6:	6105                	addi	sp,sp,32
    80002da8:	8082                	ret

0000000080002daa <sys_getpid>:

uint64
sys_getpid(void)
{
    80002daa:	1141                	addi	sp,sp,-16
    80002dac:	e406                	sd	ra,8(sp)
    80002dae:	e022                	sd	s0,0(sp)
    80002db0:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002db2:	fffff097          	auipc	ra,0xfffff
    80002db6:	ce4080e7          	jalr	-796(ra) # 80001a96 <myproc>
}
    80002dba:	5908                	lw	a0,48(a0)
    80002dbc:	60a2                	ld	ra,8(sp)
    80002dbe:	6402                	ld	s0,0(sp)
    80002dc0:	0141                	addi	sp,sp,16
    80002dc2:	8082                	ret

0000000080002dc4 <sys_fork>:

uint64
sys_fork(void)
{
    80002dc4:	1141                	addi	sp,sp,-16
    80002dc6:	e406                	sd	ra,8(sp)
    80002dc8:	e022                	sd	s0,0(sp)
    80002dca:	0800                	addi	s0,sp,16
  return fork();
    80002dcc:	fffff097          	auipc	ra,0xfffff
    80002dd0:	080080e7          	jalr	128(ra) # 80001e4c <fork>
}
    80002dd4:	60a2                	ld	ra,8(sp)
    80002dd6:	6402                	ld	s0,0(sp)
    80002dd8:	0141                	addi	sp,sp,16
    80002dda:	8082                	ret

0000000080002ddc <sys_wait>:

uint64
sys_wait(void)
{
    80002ddc:	1101                	addi	sp,sp,-32
    80002dde:	ec06                	sd	ra,24(sp)
    80002de0:	e822                	sd	s0,16(sp)
    80002de2:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002de4:	fe840593          	addi	a1,s0,-24
    80002de8:	4501                	li	a0,0
    80002dea:	00000097          	auipc	ra,0x0
    80002dee:	ed0080e7          	jalr	-304(ra) # 80002cba <argaddr>
  return wait(p);
    80002df2:	fe843503          	ld	a0,-24(s0)
    80002df6:	fffff097          	auipc	ra,0xfffff
    80002dfa:	710080e7          	jalr	1808(ra) # 80002506 <wait>
}
    80002dfe:	60e2                	ld	ra,24(sp)
    80002e00:	6442                	ld	s0,16(sp)
    80002e02:	6105                	addi	sp,sp,32
    80002e04:	8082                	ret

0000000080002e06 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002e06:	7179                	addi	sp,sp,-48
    80002e08:	f406                	sd	ra,40(sp)
    80002e0a:	f022                	sd	s0,32(sp)
    80002e0c:	ec26                	sd	s1,24(sp)
    80002e0e:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80002e10:	fdc40593          	addi	a1,s0,-36
    80002e14:	4501                	li	a0,0
    80002e16:	00000097          	auipc	ra,0x0
    80002e1a:	e84080e7          	jalr	-380(ra) # 80002c9a <argint>
  addr = myproc()->sz;
    80002e1e:	fffff097          	auipc	ra,0xfffff
    80002e22:	c78080e7          	jalr	-904(ra) # 80001a96 <myproc>
    80002e26:	6524                	ld	s1,72(a0)
  if(growproc(n) < 0)
    80002e28:	fdc42503          	lw	a0,-36(s0)
    80002e2c:	fffff097          	auipc	ra,0xfffff
    80002e30:	fc4080e7          	jalr	-60(ra) # 80001df0 <growproc>
    80002e34:	00054863          	bltz	a0,80002e44 <sys_sbrk+0x3e>
    return -1;
  return addr;
}
    80002e38:	8526                	mv	a0,s1
    80002e3a:	70a2                	ld	ra,40(sp)
    80002e3c:	7402                	ld	s0,32(sp)
    80002e3e:	64e2                	ld	s1,24(sp)
    80002e40:	6145                	addi	sp,sp,48
    80002e42:	8082                	ret
    return -1;
    80002e44:	54fd                	li	s1,-1
    80002e46:	bfcd                	j	80002e38 <sys_sbrk+0x32>

0000000080002e48 <sys_sleep>:

uint64
sys_sleep(void)
{
    80002e48:	7139                	addi	sp,sp,-64
    80002e4a:	fc06                	sd	ra,56(sp)
    80002e4c:	f822                	sd	s0,48(sp)
    80002e4e:	f426                	sd	s1,40(sp)
    80002e50:	f04a                	sd	s2,32(sp)
    80002e52:	ec4e                	sd	s3,24(sp)
    80002e54:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002e56:	fcc40593          	addi	a1,s0,-52
    80002e5a:	4501                	li	a0,0
    80002e5c:	00000097          	auipc	ra,0x0
    80002e60:	e3e080e7          	jalr	-450(ra) # 80002c9a <argint>
  acquire(&tickslock);
    80002e64:	00014517          	auipc	a0,0x14
    80002e68:	01c50513          	addi	a0,a0,28 # 80016e80 <tickslock>
    80002e6c:	ffffe097          	auipc	ra,0xffffe
    80002e70:	d6a080e7          	jalr	-662(ra) # 80000bd6 <acquire>
  ticks0 = ticks;
    80002e74:	00006917          	auipc	s2,0x6
    80002e78:	af492903          	lw	s2,-1292(s2) # 80008968 <ticks>
  while(ticks - ticks0 < n){
    80002e7c:	fcc42783          	lw	a5,-52(s0)
    80002e80:	cf9d                	beqz	a5,80002ebe <sys_sleep+0x76>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002e82:	00014997          	auipc	s3,0x14
    80002e86:	ffe98993          	addi	s3,s3,-2 # 80016e80 <tickslock>
    80002e8a:	00006497          	auipc	s1,0x6
    80002e8e:	ade48493          	addi	s1,s1,-1314 # 80008968 <ticks>
    if(killed(myproc())){
    80002e92:	fffff097          	auipc	ra,0xfffff
    80002e96:	c04080e7          	jalr	-1020(ra) # 80001a96 <myproc>
    80002e9a:	fffff097          	auipc	ra,0xfffff
    80002e9e:	63a080e7          	jalr	1594(ra) # 800024d4 <killed>
    80002ea2:	ed15                	bnez	a0,80002ede <sys_sleep+0x96>
    sleep(&ticks, &tickslock);
    80002ea4:	85ce                	mv	a1,s3
    80002ea6:	8526                	mv	a0,s1
    80002ea8:	fffff097          	auipc	ra,0xfffff
    80002eac:	384080e7          	jalr	900(ra) # 8000222c <sleep>
  while(ticks - ticks0 < n){
    80002eb0:	409c                	lw	a5,0(s1)
    80002eb2:	412787bb          	subw	a5,a5,s2
    80002eb6:	fcc42703          	lw	a4,-52(s0)
    80002eba:	fce7ece3          	bltu	a5,a4,80002e92 <sys_sleep+0x4a>
  }
  release(&tickslock);
    80002ebe:	00014517          	auipc	a0,0x14
    80002ec2:	fc250513          	addi	a0,a0,-62 # 80016e80 <tickslock>
    80002ec6:	ffffe097          	auipc	ra,0xffffe
    80002eca:	dc4080e7          	jalr	-572(ra) # 80000c8a <release>
  return 0;
    80002ece:	4501                	li	a0,0
}
    80002ed0:	70e2                	ld	ra,56(sp)
    80002ed2:	7442                	ld	s0,48(sp)
    80002ed4:	74a2                	ld	s1,40(sp)
    80002ed6:	7902                	ld	s2,32(sp)
    80002ed8:	69e2                	ld	s3,24(sp)
    80002eda:	6121                	addi	sp,sp,64
    80002edc:	8082                	ret
      release(&tickslock);
    80002ede:	00014517          	auipc	a0,0x14
    80002ee2:	fa250513          	addi	a0,a0,-94 # 80016e80 <tickslock>
    80002ee6:	ffffe097          	auipc	ra,0xffffe
    80002eea:	da4080e7          	jalr	-604(ra) # 80000c8a <release>
      return -1;
    80002eee:	557d                	li	a0,-1
    80002ef0:	b7c5                	j	80002ed0 <sys_sleep+0x88>

0000000080002ef2 <sys_kill>:

uint64
sys_kill(void)
{
    80002ef2:	1101                	addi	sp,sp,-32
    80002ef4:	ec06                	sd	ra,24(sp)
    80002ef6:	e822                	sd	s0,16(sp)
    80002ef8:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002efa:	fec40593          	addi	a1,s0,-20
    80002efe:	4501                	li	a0,0
    80002f00:	00000097          	auipc	ra,0x0
    80002f04:	d9a080e7          	jalr	-614(ra) # 80002c9a <argint>
  return kill(pid);
    80002f08:	fec42503          	lw	a0,-20(s0)
    80002f0c:	fffff097          	auipc	ra,0xfffff
    80002f10:	52a080e7          	jalr	1322(ra) # 80002436 <kill>
}
    80002f14:	60e2                	ld	ra,24(sp)
    80002f16:	6442                	ld	s0,16(sp)
    80002f18:	6105                	addi	sp,sp,32
    80002f1a:	8082                	ret

0000000080002f1c <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002f1c:	1101                	addi	sp,sp,-32
    80002f1e:	ec06                	sd	ra,24(sp)
    80002f20:	e822                	sd	s0,16(sp)
    80002f22:	e426                	sd	s1,8(sp)
    80002f24:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002f26:	00014517          	auipc	a0,0x14
    80002f2a:	f5a50513          	addi	a0,a0,-166 # 80016e80 <tickslock>
    80002f2e:	ffffe097          	auipc	ra,0xffffe
    80002f32:	ca8080e7          	jalr	-856(ra) # 80000bd6 <acquire>
  xticks = ticks;
    80002f36:	00006497          	auipc	s1,0x6
    80002f3a:	a324a483          	lw	s1,-1486(s1) # 80008968 <ticks>
  release(&tickslock);
    80002f3e:	00014517          	auipc	a0,0x14
    80002f42:	f4250513          	addi	a0,a0,-190 # 80016e80 <tickslock>
    80002f46:	ffffe097          	auipc	ra,0xffffe
    80002f4a:	d44080e7          	jalr	-700(ra) # 80000c8a <release>
  return xticks;
}
    80002f4e:	02049513          	slli	a0,s1,0x20
    80002f52:	9101                	srli	a0,a0,0x20
    80002f54:	60e2                	ld	ra,24(sp)
    80002f56:	6442                	ld	s0,16(sp)
    80002f58:	64a2                	ld	s1,8(sp)
    80002f5a:	6105                	addi	sp,sp,32
    80002f5c:	8082                	ret

0000000080002f5e <sys_schedDisp>:

//schdedDisp() syscall
uint64
sys_schedDisp()
{
    80002f5e:	1101                	addi	sp,sp,-32
    80002f60:	ec06                	sd	ra,24(sp)
    80002f62:	e822                	sd	s0,16(sp)
    80002f64:	1000                	addi	s0,sp,32
  uint64 userSpaceArrayAdd;
  argaddr(0, &userSpaceArrayAdd);
    80002f66:	fe840593          	addi	a1,s0,-24
    80002f6a:	4501                	li	a0,0
    80002f6c:	00000097          	auipc	ra,0x0
    80002f70:	d4e080e7          	jalr	-690(ra) # 80002cba <argaddr>
  int ind = schedDisp(userSpaceArrayAdd);
    80002f74:	fe843503          	ld	a0,-24(s0)
    80002f78:	fffff097          	auipc	ra,0xfffff
    80002f7c:	164080e7          	jalr	356(ra) # 800020dc <schedDisp>
  return ind;
}
    80002f80:	60e2                	ld	ra,24(sp)
    80002f82:	6442                	ld	s0,16(sp)
    80002f84:	6105                	addi	sp,sp,32
    80002f86:	8082                	ret

0000000080002f88 <sys_prtpgtble>:

uint64
sys_prtpgtble()
{
    80002f88:	1141                	addi	sp,sp,-16
    80002f8a:	e406                	sd	ra,8(sp)
    80002f8c:	e022                	sd	s0,0(sp)
    80002f8e:	0800                	addi	s0,sp,16
  //struct proc *currentProc = myproc();
  prtpgtble(myproc()->pagetable);
    80002f90:	fffff097          	auipc	ra,0xfffff
    80002f94:	b06080e7          	jalr	-1274(ra) # 80001a96 <myproc>
    80002f98:	6928                	ld	a0,80(a0)
    80002f9a:	ffffe097          	auipc	ra,0xffffe
    80002f9e:	0ac080e7          	jalr	172(ra) # 80001046 <prtpgtble>
  return 0;
}
    80002fa2:	4501                	li	a0,0
    80002fa4:	60a2                	ld	ra,8(sp)
    80002fa6:	6402                	ld	s0,0(sp)
    80002fa8:	0141                	addi	sp,sp,16
    80002faa:	8082                	ret

0000000080002fac <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002fac:	7179                	addi	sp,sp,-48
    80002fae:	f406                	sd	ra,40(sp)
    80002fb0:	f022                	sd	s0,32(sp)
    80002fb2:	ec26                	sd	s1,24(sp)
    80002fb4:	e84a                	sd	s2,16(sp)
    80002fb6:	e44e                	sd	s3,8(sp)
    80002fb8:	e052                	sd	s4,0(sp)
    80002fba:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002fbc:	00005597          	auipc	a1,0x5
    80002fc0:	59c58593          	addi	a1,a1,1436 # 80008558 <syscalls+0xc0>
    80002fc4:	00014517          	auipc	a0,0x14
    80002fc8:	ed450513          	addi	a0,a0,-300 # 80016e98 <bcache>
    80002fcc:	ffffe097          	auipc	ra,0xffffe
    80002fd0:	b7a080e7          	jalr	-1158(ra) # 80000b46 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002fd4:	0001c797          	auipc	a5,0x1c
    80002fd8:	ec478793          	addi	a5,a5,-316 # 8001ee98 <bcache+0x8000>
    80002fdc:	0001c717          	auipc	a4,0x1c
    80002fe0:	12470713          	addi	a4,a4,292 # 8001f100 <bcache+0x8268>
    80002fe4:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002fe8:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002fec:	00014497          	auipc	s1,0x14
    80002ff0:	ec448493          	addi	s1,s1,-316 # 80016eb0 <bcache+0x18>
    b->next = bcache.head.next;
    80002ff4:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002ff6:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002ff8:	00005a17          	auipc	s4,0x5
    80002ffc:	568a0a13          	addi	s4,s4,1384 # 80008560 <syscalls+0xc8>
    b->next = bcache.head.next;
    80003000:	2b893783          	ld	a5,696(s2)
    80003004:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80003006:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    8000300a:	85d2                	mv	a1,s4
    8000300c:	01048513          	addi	a0,s1,16
    80003010:	00001097          	auipc	ra,0x1
    80003014:	4c8080e7          	jalr	1224(ra) # 800044d8 <initsleeplock>
    bcache.head.next->prev = b;
    80003018:	2b893783          	ld	a5,696(s2)
    8000301c:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    8000301e:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80003022:	45848493          	addi	s1,s1,1112
    80003026:	fd349de3          	bne	s1,s3,80003000 <binit+0x54>
  }
}
    8000302a:	70a2                	ld	ra,40(sp)
    8000302c:	7402                	ld	s0,32(sp)
    8000302e:	64e2                	ld	s1,24(sp)
    80003030:	6942                	ld	s2,16(sp)
    80003032:	69a2                	ld	s3,8(sp)
    80003034:	6a02                	ld	s4,0(sp)
    80003036:	6145                	addi	sp,sp,48
    80003038:	8082                	ret

000000008000303a <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    8000303a:	7179                	addi	sp,sp,-48
    8000303c:	f406                	sd	ra,40(sp)
    8000303e:	f022                	sd	s0,32(sp)
    80003040:	ec26                	sd	s1,24(sp)
    80003042:	e84a                	sd	s2,16(sp)
    80003044:	e44e                	sd	s3,8(sp)
    80003046:	1800                	addi	s0,sp,48
    80003048:	892a                	mv	s2,a0
    8000304a:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    8000304c:	00014517          	auipc	a0,0x14
    80003050:	e4c50513          	addi	a0,a0,-436 # 80016e98 <bcache>
    80003054:	ffffe097          	auipc	ra,0xffffe
    80003058:	b82080e7          	jalr	-1150(ra) # 80000bd6 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    8000305c:	0001c497          	auipc	s1,0x1c
    80003060:	0f44b483          	ld	s1,244(s1) # 8001f150 <bcache+0x82b8>
    80003064:	0001c797          	auipc	a5,0x1c
    80003068:	09c78793          	addi	a5,a5,156 # 8001f100 <bcache+0x8268>
    8000306c:	02f48f63          	beq	s1,a5,800030aa <bread+0x70>
    80003070:	873e                	mv	a4,a5
    80003072:	a021                	j	8000307a <bread+0x40>
    80003074:	68a4                	ld	s1,80(s1)
    80003076:	02e48a63          	beq	s1,a4,800030aa <bread+0x70>
    if(b->dev == dev && b->blockno == blockno){
    8000307a:	449c                	lw	a5,8(s1)
    8000307c:	ff279ce3          	bne	a5,s2,80003074 <bread+0x3a>
    80003080:	44dc                	lw	a5,12(s1)
    80003082:	ff3799e3          	bne	a5,s3,80003074 <bread+0x3a>
      b->refcnt++;
    80003086:	40bc                	lw	a5,64(s1)
    80003088:	2785                	addiw	a5,a5,1
    8000308a:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    8000308c:	00014517          	auipc	a0,0x14
    80003090:	e0c50513          	addi	a0,a0,-500 # 80016e98 <bcache>
    80003094:	ffffe097          	auipc	ra,0xffffe
    80003098:	bf6080e7          	jalr	-1034(ra) # 80000c8a <release>
      acquiresleep(&b->lock);
    8000309c:	01048513          	addi	a0,s1,16
    800030a0:	00001097          	auipc	ra,0x1
    800030a4:	472080e7          	jalr	1138(ra) # 80004512 <acquiresleep>
      return b;
    800030a8:	a8b9                	j	80003106 <bread+0xcc>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800030aa:	0001c497          	auipc	s1,0x1c
    800030ae:	09e4b483          	ld	s1,158(s1) # 8001f148 <bcache+0x82b0>
    800030b2:	0001c797          	auipc	a5,0x1c
    800030b6:	04e78793          	addi	a5,a5,78 # 8001f100 <bcache+0x8268>
    800030ba:	00f48863          	beq	s1,a5,800030ca <bread+0x90>
    800030be:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    800030c0:	40bc                	lw	a5,64(s1)
    800030c2:	cf81                	beqz	a5,800030da <bread+0xa0>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800030c4:	64a4                	ld	s1,72(s1)
    800030c6:	fee49de3          	bne	s1,a4,800030c0 <bread+0x86>
  panic("bget: no buffers");
    800030ca:	00005517          	auipc	a0,0x5
    800030ce:	49e50513          	addi	a0,a0,1182 # 80008568 <syscalls+0xd0>
    800030d2:	ffffd097          	auipc	ra,0xffffd
    800030d6:	46e080e7          	jalr	1134(ra) # 80000540 <panic>
      b->dev = dev;
    800030da:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    800030de:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    800030e2:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    800030e6:	4785                	li	a5,1
    800030e8:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    800030ea:	00014517          	auipc	a0,0x14
    800030ee:	dae50513          	addi	a0,a0,-594 # 80016e98 <bcache>
    800030f2:	ffffe097          	auipc	ra,0xffffe
    800030f6:	b98080e7          	jalr	-1128(ra) # 80000c8a <release>
      acquiresleep(&b->lock);
    800030fa:	01048513          	addi	a0,s1,16
    800030fe:	00001097          	auipc	ra,0x1
    80003102:	414080e7          	jalr	1044(ra) # 80004512 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80003106:	409c                	lw	a5,0(s1)
    80003108:	cb89                	beqz	a5,8000311a <bread+0xe0>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    8000310a:	8526                	mv	a0,s1
    8000310c:	70a2                	ld	ra,40(sp)
    8000310e:	7402                	ld	s0,32(sp)
    80003110:	64e2                	ld	s1,24(sp)
    80003112:	6942                	ld	s2,16(sp)
    80003114:	69a2                	ld	s3,8(sp)
    80003116:	6145                	addi	sp,sp,48
    80003118:	8082                	ret
    virtio_disk_rw(b, 0);
    8000311a:	4581                	li	a1,0
    8000311c:	8526                	mv	a0,s1
    8000311e:	00003097          	auipc	ra,0x3
    80003122:	fe4080e7          	jalr	-28(ra) # 80006102 <virtio_disk_rw>
    b->valid = 1;
    80003126:	4785                	li	a5,1
    80003128:	c09c                	sw	a5,0(s1)
  return b;
    8000312a:	b7c5                	j	8000310a <bread+0xd0>

000000008000312c <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    8000312c:	1101                	addi	sp,sp,-32
    8000312e:	ec06                	sd	ra,24(sp)
    80003130:	e822                	sd	s0,16(sp)
    80003132:	e426                	sd	s1,8(sp)
    80003134:	1000                	addi	s0,sp,32
    80003136:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80003138:	0541                	addi	a0,a0,16
    8000313a:	00001097          	auipc	ra,0x1
    8000313e:	472080e7          	jalr	1138(ra) # 800045ac <holdingsleep>
    80003142:	cd01                	beqz	a0,8000315a <bwrite+0x2e>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80003144:	4585                	li	a1,1
    80003146:	8526                	mv	a0,s1
    80003148:	00003097          	auipc	ra,0x3
    8000314c:	fba080e7          	jalr	-70(ra) # 80006102 <virtio_disk_rw>
}
    80003150:	60e2                	ld	ra,24(sp)
    80003152:	6442                	ld	s0,16(sp)
    80003154:	64a2                	ld	s1,8(sp)
    80003156:	6105                	addi	sp,sp,32
    80003158:	8082                	ret
    panic("bwrite");
    8000315a:	00005517          	auipc	a0,0x5
    8000315e:	42650513          	addi	a0,a0,1062 # 80008580 <syscalls+0xe8>
    80003162:	ffffd097          	auipc	ra,0xffffd
    80003166:	3de080e7          	jalr	990(ra) # 80000540 <panic>

000000008000316a <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    8000316a:	1101                	addi	sp,sp,-32
    8000316c:	ec06                	sd	ra,24(sp)
    8000316e:	e822                	sd	s0,16(sp)
    80003170:	e426                	sd	s1,8(sp)
    80003172:	e04a                	sd	s2,0(sp)
    80003174:	1000                	addi	s0,sp,32
    80003176:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80003178:	01050913          	addi	s2,a0,16
    8000317c:	854a                	mv	a0,s2
    8000317e:	00001097          	auipc	ra,0x1
    80003182:	42e080e7          	jalr	1070(ra) # 800045ac <holdingsleep>
    80003186:	c92d                	beqz	a0,800031f8 <brelse+0x8e>
    panic("brelse");

  releasesleep(&b->lock);
    80003188:	854a                	mv	a0,s2
    8000318a:	00001097          	auipc	ra,0x1
    8000318e:	3de080e7          	jalr	990(ra) # 80004568 <releasesleep>

  acquire(&bcache.lock);
    80003192:	00014517          	auipc	a0,0x14
    80003196:	d0650513          	addi	a0,a0,-762 # 80016e98 <bcache>
    8000319a:	ffffe097          	auipc	ra,0xffffe
    8000319e:	a3c080e7          	jalr	-1476(ra) # 80000bd6 <acquire>
  b->refcnt--;
    800031a2:	40bc                	lw	a5,64(s1)
    800031a4:	37fd                	addiw	a5,a5,-1
    800031a6:	0007871b          	sext.w	a4,a5
    800031aa:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    800031ac:	eb05                	bnez	a4,800031dc <brelse+0x72>
    // no one is waiting for it.
    b->next->prev = b->prev;
    800031ae:	68bc                	ld	a5,80(s1)
    800031b0:	64b8                	ld	a4,72(s1)
    800031b2:	e7b8                	sd	a4,72(a5)
    b->prev->next = b->next;
    800031b4:	64bc                	ld	a5,72(s1)
    800031b6:	68b8                	ld	a4,80(s1)
    800031b8:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    800031ba:	0001c797          	auipc	a5,0x1c
    800031be:	cde78793          	addi	a5,a5,-802 # 8001ee98 <bcache+0x8000>
    800031c2:	2b87b703          	ld	a4,696(a5)
    800031c6:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    800031c8:	0001c717          	auipc	a4,0x1c
    800031cc:	f3870713          	addi	a4,a4,-200 # 8001f100 <bcache+0x8268>
    800031d0:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    800031d2:	2b87b703          	ld	a4,696(a5)
    800031d6:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    800031d8:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    800031dc:	00014517          	auipc	a0,0x14
    800031e0:	cbc50513          	addi	a0,a0,-836 # 80016e98 <bcache>
    800031e4:	ffffe097          	auipc	ra,0xffffe
    800031e8:	aa6080e7          	jalr	-1370(ra) # 80000c8a <release>
}
    800031ec:	60e2                	ld	ra,24(sp)
    800031ee:	6442                	ld	s0,16(sp)
    800031f0:	64a2                	ld	s1,8(sp)
    800031f2:	6902                	ld	s2,0(sp)
    800031f4:	6105                	addi	sp,sp,32
    800031f6:	8082                	ret
    panic("brelse");
    800031f8:	00005517          	auipc	a0,0x5
    800031fc:	39050513          	addi	a0,a0,912 # 80008588 <syscalls+0xf0>
    80003200:	ffffd097          	auipc	ra,0xffffd
    80003204:	340080e7          	jalr	832(ra) # 80000540 <panic>

0000000080003208 <bpin>:

void
bpin(struct buf *b) {
    80003208:	1101                	addi	sp,sp,-32
    8000320a:	ec06                	sd	ra,24(sp)
    8000320c:	e822                	sd	s0,16(sp)
    8000320e:	e426                	sd	s1,8(sp)
    80003210:	1000                	addi	s0,sp,32
    80003212:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80003214:	00014517          	auipc	a0,0x14
    80003218:	c8450513          	addi	a0,a0,-892 # 80016e98 <bcache>
    8000321c:	ffffe097          	auipc	ra,0xffffe
    80003220:	9ba080e7          	jalr	-1606(ra) # 80000bd6 <acquire>
  b->refcnt++;
    80003224:	40bc                	lw	a5,64(s1)
    80003226:	2785                	addiw	a5,a5,1
    80003228:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    8000322a:	00014517          	auipc	a0,0x14
    8000322e:	c6e50513          	addi	a0,a0,-914 # 80016e98 <bcache>
    80003232:	ffffe097          	auipc	ra,0xffffe
    80003236:	a58080e7          	jalr	-1448(ra) # 80000c8a <release>
}
    8000323a:	60e2                	ld	ra,24(sp)
    8000323c:	6442                	ld	s0,16(sp)
    8000323e:	64a2                	ld	s1,8(sp)
    80003240:	6105                	addi	sp,sp,32
    80003242:	8082                	ret

0000000080003244 <bunpin>:

void
bunpin(struct buf *b) {
    80003244:	1101                	addi	sp,sp,-32
    80003246:	ec06                	sd	ra,24(sp)
    80003248:	e822                	sd	s0,16(sp)
    8000324a:	e426                	sd	s1,8(sp)
    8000324c:	1000                	addi	s0,sp,32
    8000324e:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80003250:	00014517          	auipc	a0,0x14
    80003254:	c4850513          	addi	a0,a0,-952 # 80016e98 <bcache>
    80003258:	ffffe097          	auipc	ra,0xffffe
    8000325c:	97e080e7          	jalr	-1666(ra) # 80000bd6 <acquire>
  b->refcnt--;
    80003260:	40bc                	lw	a5,64(s1)
    80003262:	37fd                	addiw	a5,a5,-1
    80003264:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80003266:	00014517          	auipc	a0,0x14
    8000326a:	c3250513          	addi	a0,a0,-974 # 80016e98 <bcache>
    8000326e:	ffffe097          	auipc	ra,0xffffe
    80003272:	a1c080e7          	jalr	-1508(ra) # 80000c8a <release>
}
    80003276:	60e2                	ld	ra,24(sp)
    80003278:	6442                	ld	s0,16(sp)
    8000327a:	64a2                	ld	s1,8(sp)
    8000327c:	6105                	addi	sp,sp,32
    8000327e:	8082                	ret

0000000080003280 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80003280:	1101                	addi	sp,sp,-32
    80003282:	ec06                	sd	ra,24(sp)
    80003284:	e822                	sd	s0,16(sp)
    80003286:	e426                	sd	s1,8(sp)
    80003288:	e04a                	sd	s2,0(sp)
    8000328a:	1000                	addi	s0,sp,32
    8000328c:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    8000328e:	00d5d59b          	srliw	a1,a1,0xd
    80003292:	0001c797          	auipc	a5,0x1c
    80003296:	2e27a783          	lw	a5,738(a5) # 8001f574 <sb+0x1c>
    8000329a:	9dbd                	addw	a1,a1,a5
    8000329c:	00000097          	auipc	ra,0x0
    800032a0:	d9e080e7          	jalr	-610(ra) # 8000303a <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    800032a4:	0074f713          	andi	a4,s1,7
    800032a8:	4785                	li	a5,1
    800032aa:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    800032ae:	14ce                	slli	s1,s1,0x33
    800032b0:	90d9                	srli	s1,s1,0x36
    800032b2:	00950733          	add	a4,a0,s1
    800032b6:	05874703          	lbu	a4,88(a4)
    800032ba:	00e7f6b3          	and	a3,a5,a4
    800032be:	c69d                	beqz	a3,800032ec <bfree+0x6c>
    800032c0:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    800032c2:	94aa                	add	s1,s1,a0
    800032c4:	fff7c793          	not	a5,a5
    800032c8:	8f7d                	and	a4,a4,a5
    800032ca:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    800032ce:	00001097          	auipc	ra,0x1
    800032d2:	126080e7          	jalr	294(ra) # 800043f4 <log_write>
  brelse(bp);
    800032d6:	854a                	mv	a0,s2
    800032d8:	00000097          	auipc	ra,0x0
    800032dc:	e92080e7          	jalr	-366(ra) # 8000316a <brelse>
}
    800032e0:	60e2                	ld	ra,24(sp)
    800032e2:	6442                	ld	s0,16(sp)
    800032e4:	64a2                	ld	s1,8(sp)
    800032e6:	6902                	ld	s2,0(sp)
    800032e8:	6105                	addi	sp,sp,32
    800032ea:	8082                	ret
    panic("freeing free block");
    800032ec:	00005517          	auipc	a0,0x5
    800032f0:	2a450513          	addi	a0,a0,676 # 80008590 <syscalls+0xf8>
    800032f4:	ffffd097          	auipc	ra,0xffffd
    800032f8:	24c080e7          	jalr	588(ra) # 80000540 <panic>

00000000800032fc <balloc>:
{
    800032fc:	711d                	addi	sp,sp,-96
    800032fe:	ec86                	sd	ra,88(sp)
    80003300:	e8a2                	sd	s0,80(sp)
    80003302:	e4a6                	sd	s1,72(sp)
    80003304:	e0ca                	sd	s2,64(sp)
    80003306:	fc4e                	sd	s3,56(sp)
    80003308:	f852                	sd	s4,48(sp)
    8000330a:	f456                	sd	s5,40(sp)
    8000330c:	f05a                	sd	s6,32(sp)
    8000330e:	ec5e                	sd	s7,24(sp)
    80003310:	e862                	sd	s8,16(sp)
    80003312:	e466                	sd	s9,8(sp)
    80003314:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    80003316:	0001c797          	auipc	a5,0x1c
    8000331a:	2467a783          	lw	a5,582(a5) # 8001f55c <sb+0x4>
    8000331e:	cff5                	beqz	a5,8000341a <balloc+0x11e>
    80003320:	8baa                	mv	s7,a0
    80003322:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80003324:	0001cb17          	auipc	s6,0x1c
    80003328:	234b0b13          	addi	s6,s6,564 # 8001f558 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000332c:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    8000332e:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003330:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80003332:	6c89                	lui	s9,0x2
    80003334:	a061                	j	800033bc <balloc+0xc0>
        bp->data[bi/8] |= m;  // Mark block in use.
    80003336:	97ca                	add	a5,a5,s2
    80003338:	8e55                	or	a2,a2,a3
    8000333a:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    8000333e:	854a                	mv	a0,s2
    80003340:	00001097          	auipc	ra,0x1
    80003344:	0b4080e7          	jalr	180(ra) # 800043f4 <log_write>
        brelse(bp);
    80003348:	854a                	mv	a0,s2
    8000334a:	00000097          	auipc	ra,0x0
    8000334e:	e20080e7          	jalr	-480(ra) # 8000316a <brelse>
  bp = bread(dev, bno);
    80003352:	85a6                	mv	a1,s1
    80003354:	855e                	mv	a0,s7
    80003356:	00000097          	auipc	ra,0x0
    8000335a:	ce4080e7          	jalr	-796(ra) # 8000303a <bread>
    8000335e:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80003360:	40000613          	li	a2,1024
    80003364:	4581                	li	a1,0
    80003366:	05850513          	addi	a0,a0,88
    8000336a:	ffffe097          	auipc	ra,0xffffe
    8000336e:	968080e7          	jalr	-1688(ra) # 80000cd2 <memset>
  log_write(bp);
    80003372:	854a                	mv	a0,s2
    80003374:	00001097          	auipc	ra,0x1
    80003378:	080080e7          	jalr	128(ra) # 800043f4 <log_write>
  brelse(bp);
    8000337c:	854a                	mv	a0,s2
    8000337e:	00000097          	auipc	ra,0x0
    80003382:	dec080e7          	jalr	-532(ra) # 8000316a <brelse>
}
    80003386:	8526                	mv	a0,s1
    80003388:	60e6                	ld	ra,88(sp)
    8000338a:	6446                	ld	s0,80(sp)
    8000338c:	64a6                	ld	s1,72(sp)
    8000338e:	6906                	ld	s2,64(sp)
    80003390:	79e2                	ld	s3,56(sp)
    80003392:	7a42                	ld	s4,48(sp)
    80003394:	7aa2                	ld	s5,40(sp)
    80003396:	7b02                	ld	s6,32(sp)
    80003398:	6be2                	ld	s7,24(sp)
    8000339a:	6c42                	ld	s8,16(sp)
    8000339c:	6ca2                	ld	s9,8(sp)
    8000339e:	6125                	addi	sp,sp,96
    800033a0:	8082                	ret
    brelse(bp);
    800033a2:	854a                	mv	a0,s2
    800033a4:	00000097          	auipc	ra,0x0
    800033a8:	dc6080e7          	jalr	-570(ra) # 8000316a <brelse>
  for(b = 0; b < sb.size; b += BPB){
    800033ac:	015c87bb          	addw	a5,s9,s5
    800033b0:	00078a9b          	sext.w	s5,a5
    800033b4:	004b2703          	lw	a4,4(s6)
    800033b8:	06eaf163          	bgeu	s5,a4,8000341a <balloc+0x11e>
    bp = bread(dev, BBLOCK(b, sb));
    800033bc:	41fad79b          	sraiw	a5,s5,0x1f
    800033c0:	0137d79b          	srliw	a5,a5,0x13
    800033c4:	015787bb          	addw	a5,a5,s5
    800033c8:	40d7d79b          	sraiw	a5,a5,0xd
    800033cc:	01cb2583          	lw	a1,28(s6)
    800033d0:	9dbd                	addw	a1,a1,a5
    800033d2:	855e                	mv	a0,s7
    800033d4:	00000097          	auipc	ra,0x0
    800033d8:	c66080e7          	jalr	-922(ra) # 8000303a <bread>
    800033dc:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800033de:	004b2503          	lw	a0,4(s6)
    800033e2:	000a849b          	sext.w	s1,s5
    800033e6:	8762                	mv	a4,s8
    800033e8:	faa4fde3          	bgeu	s1,a0,800033a2 <balloc+0xa6>
      m = 1 << (bi % 8);
    800033ec:	00777693          	andi	a3,a4,7
    800033f0:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    800033f4:	41f7579b          	sraiw	a5,a4,0x1f
    800033f8:	01d7d79b          	srliw	a5,a5,0x1d
    800033fc:	9fb9                	addw	a5,a5,a4
    800033fe:	4037d79b          	sraiw	a5,a5,0x3
    80003402:	00f90633          	add	a2,s2,a5
    80003406:	05864603          	lbu	a2,88(a2)
    8000340a:	00c6f5b3          	and	a1,a3,a2
    8000340e:	d585                	beqz	a1,80003336 <balloc+0x3a>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003410:	2705                	addiw	a4,a4,1
    80003412:	2485                	addiw	s1,s1,1
    80003414:	fd471ae3          	bne	a4,s4,800033e8 <balloc+0xec>
    80003418:	b769                	j	800033a2 <balloc+0xa6>
  printf("balloc: out of blocks\n");
    8000341a:	00005517          	auipc	a0,0x5
    8000341e:	18e50513          	addi	a0,a0,398 # 800085a8 <syscalls+0x110>
    80003422:	ffffd097          	auipc	ra,0xffffd
    80003426:	168080e7          	jalr	360(ra) # 8000058a <printf>
  return 0;
    8000342a:	4481                	li	s1,0
    8000342c:	bfa9                	j	80003386 <balloc+0x8a>

000000008000342e <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    8000342e:	7179                	addi	sp,sp,-48
    80003430:	f406                	sd	ra,40(sp)
    80003432:	f022                	sd	s0,32(sp)
    80003434:	ec26                	sd	s1,24(sp)
    80003436:	e84a                	sd	s2,16(sp)
    80003438:	e44e                	sd	s3,8(sp)
    8000343a:	e052                	sd	s4,0(sp)
    8000343c:	1800                	addi	s0,sp,48
    8000343e:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80003440:	47ad                	li	a5,11
    80003442:	02b7e863          	bltu	a5,a1,80003472 <bmap+0x44>
    if((addr = ip->addrs[bn]) == 0){
    80003446:	02059793          	slli	a5,a1,0x20
    8000344a:	01e7d593          	srli	a1,a5,0x1e
    8000344e:	00b504b3          	add	s1,a0,a1
    80003452:	0504a903          	lw	s2,80(s1)
    80003456:	06091e63          	bnez	s2,800034d2 <bmap+0xa4>
      addr = balloc(ip->dev);
    8000345a:	4108                	lw	a0,0(a0)
    8000345c:	00000097          	auipc	ra,0x0
    80003460:	ea0080e7          	jalr	-352(ra) # 800032fc <balloc>
    80003464:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80003468:	06090563          	beqz	s2,800034d2 <bmap+0xa4>
        return 0;
      ip->addrs[bn] = addr;
    8000346c:	0524a823          	sw	s2,80(s1)
    80003470:	a08d                	j	800034d2 <bmap+0xa4>
    }
    return addr;
  }
  bn -= NDIRECT;
    80003472:	ff45849b          	addiw	s1,a1,-12
    80003476:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    8000347a:	0ff00793          	li	a5,255
    8000347e:	08e7e563          	bltu	a5,a4,80003508 <bmap+0xda>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80003482:	08052903          	lw	s2,128(a0)
    80003486:	00091d63          	bnez	s2,800034a0 <bmap+0x72>
      addr = balloc(ip->dev);
    8000348a:	4108                	lw	a0,0(a0)
    8000348c:	00000097          	auipc	ra,0x0
    80003490:	e70080e7          	jalr	-400(ra) # 800032fc <balloc>
    80003494:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80003498:	02090d63          	beqz	s2,800034d2 <bmap+0xa4>
        return 0;
      ip->addrs[NDIRECT] = addr;
    8000349c:	0929a023          	sw	s2,128(s3)
    }
    bp = bread(ip->dev, addr);
    800034a0:	85ca                	mv	a1,s2
    800034a2:	0009a503          	lw	a0,0(s3)
    800034a6:	00000097          	auipc	ra,0x0
    800034aa:	b94080e7          	jalr	-1132(ra) # 8000303a <bread>
    800034ae:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    800034b0:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    800034b4:	02049713          	slli	a4,s1,0x20
    800034b8:	01e75593          	srli	a1,a4,0x1e
    800034bc:	00b784b3          	add	s1,a5,a1
    800034c0:	0004a903          	lw	s2,0(s1)
    800034c4:	02090063          	beqz	s2,800034e4 <bmap+0xb6>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    800034c8:	8552                	mv	a0,s4
    800034ca:	00000097          	auipc	ra,0x0
    800034ce:	ca0080e7          	jalr	-864(ra) # 8000316a <brelse>
    return addr;
  }

  panic("bmap: out of range");
}
    800034d2:	854a                	mv	a0,s2
    800034d4:	70a2                	ld	ra,40(sp)
    800034d6:	7402                	ld	s0,32(sp)
    800034d8:	64e2                	ld	s1,24(sp)
    800034da:	6942                	ld	s2,16(sp)
    800034dc:	69a2                	ld	s3,8(sp)
    800034de:	6a02                	ld	s4,0(sp)
    800034e0:	6145                	addi	sp,sp,48
    800034e2:	8082                	ret
      addr = balloc(ip->dev);
    800034e4:	0009a503          	lw	a0,0(s3)
    800034e8:	00000097          	auipc	ra,0x0
    800034ec:	e14080e7          	jalr	-492(ra) # 800032fc <balloc>
    800034f0:	0005091b          	sext.w	s2,a0
      if(addr){
    800034f4:	fc090ae3          	beqz	s2,800034c8 <bmap+0x9a>
        a[bn] = addr;
    800034f8:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    800034fc:	8552                	mv	a0,s4
    800034fe:	00001097          	auipc	ra,0x1
    80003502:	ef6080e7          	jalr	-266(ra) # 800043f4 <log_write>
    80003506:	b7c9                	j	800034c8 <bmap+0x9a>
  panic("bmap: out of range");
    80003508:	00005517          	auipc	a0,0x5
    8000350c:	0b850513          	addi	a0,a0,184 # 800085c0 <syscalls+0x128>
    80003510:	ffffd097          	auipc	ra,0xffffd
    80003514:	030080e7          	jalr	48(ra) # 80000540 <panic>

0000000080003518 <iget>:
{
    80003518:	7179                	addi	sp,sp,-48
    8000351a:	f406                	sd	ra,40(sp)
    8000351c:	f022                	sd	s0,32(sp)
    8000351e:	ec26                	sd	s1,24(sp)
    80003520:	e84a                	sd	s2,16(sp)
    80003522:	e44e                	sd	s3,8(sp)
    80003524:	e052                	sd	s4,0(sp)
    80003526:	1800                	addi	s0,sp,48
    80003528:	89aa                	mv	s3,a0
    8000352a:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    8000352c:	0001c517          	auipc	a0,0x1c
    80003530:	04c50513          	addi	a0,a0,76 # 8001f578 <itable>
    80003534:	ffffd097          	auipc	ra,0xffffd
    80003538:	6a2080e7          	jalr	1698(ra) # 80000bd6 <acquire>
  empty = 0;
    8000353c:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    8000353e:	0001c497          	auipc	s1,0x1c
    80003542:	05248493          	addi	s1,s1,82 # 8001f590 <itable+0x18>
    80003546:	0001e697          	auipc	a3,0x1e
    8000354a:	ada68693          	addi	a3,a3,-1318 # 80021020 <log>
    8000354e:	a039                	j	8000355c <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80003550:	02090b63          	beqz	s2,80003586 <iget+0x6e>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003554:	08848493          	addi	s1,s1,136
    80003558:	02d48a63          	beq	s1,a3,8000358c <iget+0x74>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    8000355c:	449c                	lw	a5,8(s1)
    8000355e:	fef059e3          	blez	a5,80003550 <iget+0x38>
    80003562:	4098                	lw	a4,0(s1)
    80003564:	ff3716e3          	bne	a4,s3,80003550 <iget+0x38>
    80003568:	40d8                	lw	a4,4(s1)
    8000356a:	ff4713e3          	bne	a4,s4,80003550 <iget+0x38>
      ip->ref++;
    8000356e:	2785                	addiw	a5,a5,1
    80003570:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80003572:	0001c517          	auipc	a0,0x1c
    80003576:	00650513          	addi	a0,a0,6 # 8001f578 <itable>
    8000357a:	ffffd097          	auipc	ra,0xffffd
    8000357e:	710080e7          	jalr	1808(ra) # 80000c8a <release>
      return ip;
    80003582:	8926                	mv	s2,s1
    80003584:	a03d                	j	800035b2 <iget+0x9a>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80003586:	f7f9                	bnez	a5,80003554 <iget+0x3c>
    80003588:	8926                	mv	s2,s1
    8000358a:	b7e9                	j	80003554 <iget+0x3c>
  if(empty == 0)
    8000358c:	02090c63          	beqz	s2,800035c4 <iget+0xac>
  ip->dev = dev;
    80003590:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80003594:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80003598:	4785                	li	a5,1
    8000359a:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    8000359e:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    800035a2:	0001c517          	auipc	a0,0x1c
    800035a6:	fd650513          	addi	a0,a0,-42 # 8001f578 <itable>
    800035aa:	ffffd097          	auipc	ra,0xffffd
    800035ae:	6e0080e7          	jalr	1760(ra) # 80000c8a <release>
}
    800035b2:	854a                	mv	a0,s2
    800035b4:	70a2                	ld	ra,40(sp)
    800035b6:	7402                	ld	s0,32(sp)
    800035b8:	64e2                	ld	s1,24(sp)
    800035ba:	6942                	ld	s2,16(sp)
    800035bc:	69a2                	ld	s3,8(sp)
    800035be:	6a02                	ld	s4,0(sp)
    800035c0:	6145                	addi	sp,sp,48
    800035c2:	8082                	ret
    panic("iget: no inodes");
    800035c4:	00005517          	auipc	a0,0x5
    800035c8:	01450513          	addi	a0,a0,20 # 800085d8 <syscalls+0x140>
    800035cc:	ffffd097          	auipc	ra,0xffffd
    800035d0:	f74080e7          	jalr	-140(ra) # 80000540 <panic>

00000000800035d4 <fsinit>:
fsinit(int dev) {
    800035d4:	7179                	addi	sp,sp,-48
    800035d6:	f406                	sd	ra,40(sp)
    800035d8:	f022                	sd	s0,32(sp)
    800035da:	ec26                	sd	s1,24(sp)
    800035dc:	e84a                	sd	s2,16(sp)
    800035de:	e44e                	sd	s3,8(sp)
    800035e0:	1800                	addi	s0,sp,48
    800035e2:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    800035e4:	4585                	li	a1,1
    800035e6:	00000097          	auipc	ra,0x0
    800035ea:	a54080e7          	jalr	-1452(ra) # 8000303a <bread>
    800035ee:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    800035f0:	0001c997          	auipc	s3,0x1c
    800035f4:	f6898993          	addi	s3,s3,-152 # 8001f558 <sb>
    800035f8:	02000613          	li	a2,32
    800035fc:	05850593          	addi	a1,a0,88
    80003600:	854e                	mv	a0,s3
    80003602:	ffffd097          	auipc	ra,0xffffd
    80003606:	72c080e7          	jalr	1836(ra) # 80000d2e <memmove>
  brelse(bp);
    8000360a:	8526                	mv	a0,s1
    8000360c:	00000097          	auipc	ra,0x0
    80003610:	b5e080e7          	jalr	-1186(ra) # 8000316a <brelse>
  if(sb.magic != FSMAGIC)
    80003614:	0009a703          	lw	a4,0(s3)
    80003618:	102037b7          	lui	a5,0x10203
    8000361c:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003620:	02f71263          	bne	a4,a5,80003644 <fsinit+0x70>
  initlog(dev, &sb);
    80003624:	0001c597          	auipc	a1,0x1c
    80003628:	f3458593          	addi	a1,a1,-204 # 8001f558 <sb>
    8000362c:	854a                	mv	a0,s2
    8000362e:	00001097          	auipc	ra,0x1
    80003632:	b4a080e7          	jalr	-1206(ra) # 80004178 <initlog>
}
    80003636:	70a2                	ld	ra,40(sp)
    80003638:	7402                	ld	s0,32(sp)
    8000363a:	64e2                	ld	s1,24(sp)
    8000363c:	6942                	ld	s2,16(sp)
    8000363e:	69a2                	ld	s3,8(sp)
    80003640:	6145                	addi	sp,sp,48
    80003642:	8082                	ret
    panic("invalid file system");
    80003644:	00005517          	auipc	a0,0x5
    80003648:	fa450513          	addi	a0,a0,-92 # 800085e8 <syscalls+0x150>
    8000364c:	ffffd097          	auipc	ra,0xffffd
    80003650:	ef4080e7          	jalr	-268(ra) # 80000540 <panic>

0000000080003654 <iinit>:
{
    80003654:	7179                	addi	sp,sp,-48
    80003656:	f406                	sd	ra,40(sp)
    80003658:	f022                	sd	s0,32(sp)
    8000365a:	ec26                	sd	s1,24(sp)
    8000365c:	e84a                	sd	s2,16(sp)
    8000365e:	e44e                	sd	s3,8(sp)
    80003660:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003662:	00005597          	auipc	a1,0x5
    80003666:	f9e58593          	addi	a1,a1,-98 # 80008600 <syscalls+0x168>
    8000366a:	0001c517          	auipc	a0,0x1c
    8000366e:	f0e50513          	addi	a0,a0,-242 # 8001f578 <itable>
    80003672:	ffffd097          	auipc	ra,0xffffd
    80003676:	4d4080e7          	jalr	1236(ra) # 80000b46 <initlock>
  for(i = 0; i < NINODE; i++) {
    8000367a:	0001c497          	auipc	s1,0x1c
    8000367e:	f2648493          	addi	s1,s1,-218 # 8001f5a0 <itable+0x28>
    80003682:	0001e997          	auipc	s3,0x1e
    80003686:	9ae98993          	addi	s3,s3,-1618 # 80021030 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    8000368a:	00005917          	auipc	s2,0x5
    8000368e:	f7e90913          	addi	s2,s2,-130 # 80008608 <syscalls+0x170>
    80003692:	85ca                	mv	a1,s2
    80003694:	8526                	mv	a0,s1
    80003696:	00001097          	auipc	ra,0x1
    8000369a:	e42080e7          	jalr	-446(ra) # 800044d8 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    8000369e:	08848493          	addi	s1,s1,136
    800036a2:	ff3498e3          	bne	s1,s3,80003692 <iinit+0x3e>
}
    800036a6:	70a2                	ld	ra,40(sp)
    800036a8:	7402                	ld	s0,32(sp)
    800036aa:	64e2                	ld	s1,24(sp)
    800036ac:	6942                	ld	s2,16(sp)
    800036ae:	69a2                	ld	s3,8(sp)
    800036b0:	6145                	addi	sp,sp,48
    800036b2:	8082                	ret

00000000800036b4 <ialloc>:
{
    800036b4:	715d                	addi	sp,sp,-80
    800036b6:	e486                	sd	ra,72(sp)
    800036b8:	e0a2                	sd	s0,64(sp)
    800036ba:	fc26                	sd	s1,56(sp)
    800036bc:	f84a                	sd	s2,48(sp)
    800036be:	f44e                	sd	s3,40(sp)
    800036c0:	f052                	sd	s4,32(sp)
    800036c2:	ec56                	sd	s5,24(sp)
    800036c4:	e85a                	sd	s6,16(sp)
    800036c6:	e45e                	sd	s7,8(sp)
    800036c8:	0880                	addi	s0,sp,80
  for(inum = 1; inum < sb.ninodes; inum++){
    800036ca:	0001c717          	auipc	a4,0x1c
    800036ce:	e9a72703          	lw	a4,-358(a4) # 8001f564 <sb+0xc>
    800036d2:	4785                	li	a5,1
    800036d4:	04e7fa63          	bgeu	a5,a4,80003728 <ialloc+0x74>
    800036d8:	8aaa                	mv	s5,a0
    800036da:	8bae                	mv	s7,a1
    800036dc:	4485                	li	s1,1
    bp = bread(dev, IBLOCK(inum, sb));
    800036de:	0001ca17          	auipc	s4,0x1c
    800036e2:	e7aa0a13          	addi	s4,s4,-390 # 8001f558 <sb>
    800036e6:	00048b1b          	sext.w	s6,s1
    800036ea:	0044d593          	srli	a1,s1,0x4
    800036ee:	018a2783          	lw	a5,24(s4)
    800036f2:	9dbd                	addw	a1,a1,a5
    800036f4:	8556                	mv	a0,s5
    800036f6:	00000097          	auipc	ra,0x0
    800036fa:	944080e7          	jalr	-1724(ra) # 8000303a <bread>
    800036fe:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80003700:	05850993          	addi	s3,a0,88
    80003704:	00f4f793          	andi	a5,s1,15
    80003708:	079a                	slli	a5,a5,0x6
    8000370a:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    8000370c:	00099783          	lh	a5,0(s3)
    80003710:	c3a1                	beqz	a5,80003750 <ialloc+0x9c>
    brelse(bp);
    80003712:	00000097          	auipc	ra,0x0
    80003716:	a58080e7          	jalr	-1448(ra) # 8000316a <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    8000371a:	0485                	addi	s1,s1,1
    8000371c:	00ca2703          	lw	a4,12(s4)
    80003720:	0004879b          	sext.w	a5,s1
    80003724:	fce7e1e3          	bltu	a5,a4,800036e6 <ialloc+0x32>
  printf("ialloc: no inodes\n");
    80003728:	00005517          	auipc	a0,0x5
    8000372c:	ee850513          	addi	a0,a0,-280 # 80008610 <syscalls+0x178>
    80003730:	ffffd097          	auipc	ra,0xffffd
    80003734:	e5a080e7          	jalr	-422(ra) # 8000058a <printf>
  return 0;
    80003738:	4501                	li	a0,0
}
    8000373a:	60a6                	ld	ra,72(sp)
    8000373c:	6406                	ld	s0,64(sp)
    8000373e:	74e2                	ld	s1,56(sp)
    80003740:	7942                	ld	s2,48(sp)
    80003742:	79a2                	ld	s3,40(sp)
    80003744:	7a02                	ld	s4,32(sp)
    80003746:	6ae2                	ld	s5,24(sp)
    80003748:	6b42                	ld	s6,16(sp)
    8000374a:	6ba2                	ld	s7,8(sp)
    8000374c:	6161                	addi	sp,sp,80
    8000374e:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003750:	04000613          	li	a2,64
    80003754:	4581                	li	a1,0
    80003756:	854e                	mv	a0,s3
    80003758:	ffffd097          	auipc	ra,0xffffd
    8000375c:	57a080e7          	jalr	1402(ra) # 80000cd2 <memset>
      dip->type = type;
    80003760:	01799023          	sh	s7,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003764:	854a                	mv	a0,s2
    80003766:	00001097          	auipc	ra,0x1
    8000376a:	c8e080e7          	jalr	-882(ra) # 800043f4 <log_write>
      brelse(bp);
    8000376e:	854a                	mv	a0,s2
    80003770:	00000097          	auipc	ra,0x0
    80003774:	9fa080e7          	jalr	-1542(ra) # 8000316a <brelse>
      return iget(dev, inum);
    80003778:	85da                	mv	a1,s6
    8000377a:	8556                	mv	a0,s5
    8000377c:	00000097          	auipc	ra,0x0
    80003780:	d9c080e7          	jalr	-612(ra) # 80003518 <iget>
    80003784:	bf5d                	j	8000373a <ialloc+0x86>

0000000080003786 <iupdate>:
{
    80003786:	1101                	addi	sp,sp,-32
    80003788:	ec06                	sd	ra,24(sp)
    8000378a:	e822                	sd	s0,16(sp)
    8000378c:	e426                	sd	s1,8(sp)
    8000378e:	e04a                	sd	s2,0(sp)
    80003790:	1000                	addi	s0,sp,32
    80003792:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003794:	415c                	lw	a5,4(a0)
    80003796:	0047d79b          	srliw	a5,a5,0x4
    8000379a:	0001c597          	auipc	a1,0x1c
    8000379e:	dd65a583          	lw	a1,-554(a1) # 8001f570 <sb+0x18>
    800037a2:	9dbd                	addw	a1,a1,a5
    800037a4:	4108                	lw	a0,0(a0)
    800037a6:	00000097          	auipc	ra,0x0
    800037aa:	894080e7          	jalr	-1900(ra) # 8000303a <bread>
    800037ae:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800037b0:	05850793          	addi	a5,a0,88
    800037b4:	40d8                	lw	a4,4(s1)
    800037b6:	8b3d                	andi	a4,a4,15
    800037b8:	071a                	slli	a4,a4,0x6
    800037ba:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800037bc:	04449703          	lh	a4,68(s1)
    800037c0:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800037c4:	04649703          	lh	a4,70(s1)
    800037c8:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800037cc:	04849703          	lh	a4,72(s1)
    800037d0:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    800037d4:	04a49703          	lh	a4,74(s1)
    800037d8:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    800037dc:	44f8                	lw	a4,76(s1)
    800037de:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800037e0:	03400613          	li	a2,52
    800037e4:	05048593          	addi	a1,s1,80
    800037e8:	00c78513          	addi	a0,a5,12
    800037ec:	ffffd097          	auipc	ra,0xffffd
    800037f0:	542080e7          	jalr	1346(ra) # 80000d2e <memmove>
  log_write(bp);
    800037f4:	854a                	mv	a0,s2
    800037f6:	00001097          	auipc	ra,0x1
    800037fa:	bfe080e7          	jalr	-1026(ra) # 800043f4 <log_write>
  brelse(bp);
    800037fe:	854a                	mv	a0,s2
    80003800:	00000097          	auipc	ra,0x0
    80003804:	96a080e7          	jalr	-1686(ra) # 8000316a <brelse>
}
    80003808:	60e2                	ld	ra,24(sp)
    8000380a:	6442                	ld	s0,16(sp)
    8000380c:	64a2                	ld	s1,8(sp)
    8000380e:	6902                	ld	s2,0(sp)
    80003810:	6105                	addi	sp,sp,32
    80003812:	8082                	ret

0000000080003814 <idup>:
{
    80003814:	1101                	addi	sp,sp,-32
    80003816:	ec06                	sd	ra,24(sp)
    80003818:	e822                	sd	s0,16(sp)
    8000381a:	e426                	sd	s1,8(sp)
    8000381c:	1000                	addi	s0,sp,32
    8000381e:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003820:	0001c517          	auipc	a0,0x1c
    80003824:	d5850513          	addi	a0,a0,-680 # 8001f578 <itable>
    80003828:	ffffd097          	auipc	ra,0xffffd
    8000382c:	3ae080e7          	jalr	942(ra) # 80000bd6 <acquire>
  ip->ref++;
    80003830:	449c                	lw	a5,8(s1)
    80003832:	2785                	addiw	a5,a5,1
    80003834:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003836:	0001c517          	auipc	a0,0x1c
    8000383a:	d4250513          	addi	a0,a0,-702 # 8001f578 <itable>
    8000383e:	ffffd097          	auipc	ra,0xffffd
    80003842:	44c080e7          	jalr	1100(ra) # 80000c8a <release>
}
    80003846:	8526                	mv	a0,s1
    80003848:	60e2                	ld	ra,24(sp)
    8000384a:	6442                	ld	s0,16(sp)
    8000384c:	64a2                	ld	s1,8(sp)
    8000384e:	6105                	addi	sp,sp,32
    80003850:	8082                	ret

0000000080003852 <ilock>:
{
    80003852:	1101                	addi	sp,sp,-32
    80003854:	ec06                	sd	ra,24(sp)
    80003856:	e822                	sd	s0,16(sp)
    80003858:	e426                	sd	s1,8(sp)
    8000385a:	e04a                	sd	s2,0(sp)
    8000385c:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    8000385e:	c115                	beqz	a0,80003882 <ilock+0x30>
    80003860:	84aa                	mv	s1,a0
    80003862:	451c                	lw	a5,8(a0)
    80003864:	00f05f63          	blez	a5,80003882 <ilock+0x30>
  acquiresleep(&ip->lock);
    80003868:	0541                	addi	a0,a0,16
    8000386a:	00001097          	auipc	ra,0x1
    8000386e:	ca8080e7          	jalr	-856(ra) # 80004512 <acquiresleep>
  if(ip->valid == 0){
    80003872:	40bc                	lw	a5,64(s1)
    80003874:	cf99                	beqz	a5,80003892 <ilock+0x40>
}
    80003876:	60e2                	ld	ra,24(sp)
    80003878:	6442                	ld	s0,16(sp)
    8000387a:	64a2                	ld	s1,8(sp)
    8000387c:	6902                	ld	s2,0(sp)
    8000387e:	6105                	addi	sp,sp,32
    80003880:	8082                	ret
    panic("ilock");
    80003882:	00005517          	auipc	a0,0x5
    80003886:	da650513          	addi	a0,a0,-602 # 80008628 <syscalls+0x190>
    8000388a:	ffffd097          	auipc	ra,0xffffd
    8000388e:	cb6080e7          	jalr	-842(ra) # 80000540 <panic>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003892:	40dc                	lw	a5,4(s1)
    80003894:	0047d79b          	srliw	a5,a5,0x4
    80003898:	0001c597          	auipc	a1,0x1c
    8000389c:	cd85a583          	lw	a1,-808(a1) # 8001f570 <sb+0x18>
    800038a0:	9dbd                	addw	a1,a1,a5
    800038a2:	4088                	lw	a0,0(s1)
    800038a4:	fffff097          	auipc	ra,0xfffff
    800038a8:	796080e7          	jalr	1942(ra) # 8000303a <bread>
    800038ac:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    800038ae:	05850593          	addi	a1,a0,88
    800038b2:	40dc                	lw	a5,4(s1)
    800038b4:	8bbd                	andi	a5,a5,15
    800038b6:	079a                	slli	a5,a5,0x6
    800038b8:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800038ba:	00059783          	lh	a5,0(a1)
    800038be:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800038c2:	00259783          	lh	a5,2(a1)
    800038c6:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800038ca:	00459783          	lh	a5,4(a1)
    800038ce:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800038d2:	00659783          	lh	a5,6(a1)
    800038d6:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800038da:	459c                	lw	a5,8(a1)
    800038dc:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800038de:	03400613          	li	a2,52
    800038e2:	05b1                	addi	a1,a1,12
    800038e4:	05048513          	addi	a0,s1,80
    800038e8:	ffffd097          	auipc	ra,0xffffd
    800038ec:	446080e7          	jalr	1094(ra) # 80000d2e <memmove>
    brelse(bp);
    800038f0:	854a                	mv	a0,s2
    800038f2:	00000097          	auipc	ra,0x0
    800038f6:	878080e7          	jalr	-1928(ra) # 8000316a <brelse>
    ip->valid = 1;
    800038fa:	4785                	li	a5,1
    800038fc:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    800038fe:	04449783          	lh	a5,68(s1)
    80003902:	fbb5                	bnez	a5,80003876 <ilock+0x24>
      panic("ilock: no type");
    80003904:	00005517          	auipc	a0,0x5
    80003908:	d2c50513          	addi	a0,a0,-724 # 80008630 <syscalls+0x198>
    8000390c:	ffffd097          	auipc	ra,0xffffd
    80003910:	c34080e7          	jalr	-972(ra) # 80000540 <panic>

0000000080003914 <iunlock>:
{
    80003914:	1101                	addi	sp,sp,-32
    80003916:	ec06                	sd	ra,24(sp)
    80003918:	e822                	sd	s0,16(sp)
    8000391a:	e426                	sd	s1,8(sp)
    8000391c:	e04a                	sd	s2,0(sp)
    8000391e:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003920:	c905                	beqz	a0,80003950 <iunlock+0x3c>
    80003922:	84aa                	mv	s1,a0
    80003924:	01050913          	addi	s2,a0,16
    80003928:	854a                	mv	a0,s2
    8000392a:	00001097          	auipc	ra,0x1
    8000392e:	c82080e7          	jalr	-894(ra) # 800045ac <holdingsleep>
    80003932:	cd19                	beqz	a0,80003950 <iunlock+0x3c>
    80003934:	449c                	lw	a5,8(s1)
    80003936:	00f05d63          	blez	a5,80003950 <iunlock+0x3c>
  releasesleep(&ip->lock);
    8000393a:	854a                	mv	a0,s2
    8000393c:	00001097          	auipc	ra,0x1
    80003940:	c2c080e7          	jalr	-980(ra) # 80004568 <releasesleep>
}
    80003944:	60e2                	ld	ra,24(sp)
    80003946:	6442                	ld	s0,16(sp)
    80003948:	64a2                	ld	s1,8(sp)
    8000394a:	6902                	ld	s2,0(sp)
    8000394c:	6105                	addi	sp,sp,32
    8000394e:	8082                	ret
    panic("iunlock");
    80003950:	00005517          	auipc	a0,0x5
    80003954:	cf050513          	addi	a0,a0,-784 # 80008640 <syscalls+0x1a8>
    80003958:	ffffd097          	auipc	ra,0xffffd
    8000395c:	be8080e7          	jalr	-1048(ra) # 80000540 <panic>

0000000080003960 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80003960:	7179                	addi	sp,sp,-48
    80003962:	f406                	sd	ra,40(sp)
    80003964:	f022                	sd	s0,32(sp)
    80003966:	ec26                	sd	s1,24(sp)
    80003968:	e84a                	sd	s2,16(sp)
    8000396a:	e44e                	sd	s3,8(sp)
    8000396c:	e052                	sd	s4,0(sp)
    8000396e:	1800                	addi	s0,sp,48
    80003970:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80003972:	05050493          	addi	s1,a0,80
    80003976:	08050913          	addi	s2,a0,128
    8000397a:	a021                	j	80003982 <itrunc+0x22>
    8000397c:	0491                	addi	s1,s1,4
    8000397e:	01248d63          	beq	s1,s2,80003998 <itrunc+0x38>
    if(ip->addrs[i]){
    80003982:	408c                	lw	a1,0(s1)
    80003984:	dde5                	beqz	a1,8000397c <itrunc+0x1c>
      bfree(ip->dev, ip->addrs[i]);
    80003986:	0009a503          	lw	a0,0(s3)
    8000398a:	00000097          	auipc	ra,0x0
    8000398e:	8f6080e7          	jalr	-1802(ra) # 80003280 <bfree>
      ip->addrs[i] = 0;
    80003992:	0004a023          	sw	zero,0(s1)
    80003996:	b7dd                	j	8000397c <itrunc+0x1c>
    }
  }

  if(ip->addrs[NDIRECT]){
    80003998:	0809a583          	lw	a1,128(s3)
    8000399c:	e185                	bnez	a1,800039bc <itrunc+0x5c>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    8000399e:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800039a2:	854e                	mv	a0,s3
    800039a4:	00000097          	auipc	ra,0x0
    800039a8:	de2080e7          	jalr	-542(ra) # 80003786 <iupdate>
}
    800039ac:	70a2                	ld	ra,40(sp)
    800039ae:	7402                	ld	s0,32(sp)
    800039b0:	64e2                	ld	s1,24(sp)
    800039b2:	6942                	ld	s2,16(sp)
    800039b4:	69a2                	ld	s3,8(sp)
    800039b6:	6a02                	ld	s4,0(sp)
    800039b8:	6145                	addi	sp,sp,48
    800039ba:	8082                	ret
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800039bc:	0009a503          	lw	a0,0(s3)
    800039c0:	fffff097          	auipc	ra,0xfffff
    800039c4:	67a080e7          	jalr	1658(ra) # 8000303a <bread>
    800039c8:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    800039ca:	05850493          	addi	s1,a0,88
    800039ce:	45850913          	addi	s2,a0,1112
    800039d2:	a021                	j	800039da <itrunc+0x7a>
    800039d4:	0491                	addi	s1,s1,4
    800039d6:	01248b63          	beq	s1,s2,800039ec <itrunc+0x8c>
      if(a[j])
    800039da:	408c                	lw	a1,0(s1)
    800039dc:	dde5                	beqz	a1,800039d4 <itrunc+0x74>
        bfree(ip->dev, a[j]);
    800039de:	0009a503          	lw	a0,0(s3)
    800039e2:	00000097          	auipc	ra,0x0
    800039e6:	89e080e7          	jalr	-1890(ra) # 80003280 <bfree>
    800039ea:	b7ed                	j	800039d4 <itrunc+0x74>
    brelse(bp);
    800039ec:	8552                	mv	a0,s4
    800039ee:	fffff097          	auipc	ra,0xfffff
    800039f2:	77c080e7          	jalr	1916(ra) # 8000316a <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800039f6:	0809a583          	lw	a1,128(s3)
    800039fa:	0009a503          	lw	a0,0(s3)
    800039fe:	00000097          	auipc	ra,0x0
    80003a02:	882080e7          	jalr	-1918(ra) # 80003280 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003a06:	0809a023          	sw	zero,128(s3)
    80003a0a:	bf51                	j	8000399e <itrunc+0x3e>

0000000080003a0c <iput>:
{
    80003a0c:	1101                	addi	sp,sp,-32
    80003a0e:	ec06                	sd	ra,24(sp)
    80003a10:	e822                	sd	s0,16(sp)
    80003a12:	e426                	sd	s1,8(sp)
    80003a14:	e04a                	sd	s2,0(sp)
    80003a16:	1000                	addi	s0,sp,32
    80003a18:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003a1a:	0001c517          	auipc	a0,0x1c
    80003a1e:	b5e50513          	addi	a0,a0,-1186 # 8001f578 <itable>
    80003a22:	ffffd097          	auipc	ra,0xffffd
    80003a26:	1b4080e7          	jalr	436(ra) # 80000bd6 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003a2a:	4498                	lw	a4,8(s1)
    80003a2c:	4785                	li	a5,1
    80003a2e:	02f70363          	beq	a4,a5,80003a54 <iput+0x48>
  ip->ref--;
    80003a32:	449c                	lw	a5,8(s1)
    80003a34:	37fd                	addiw	a5,a5,-1
    80003a36:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003a38:	0001c517          	auipc	a0,0x1c
    80003a3c:	b4050513          	addi	a0,a0,-1216 # 8001f578 <itable>
    80003a40:	ffffd097          	auipc	ra,0xffffd
    80003a44:	24a080e7          	jalr	586(ra) # 80000c8a <release>
}
    80003a48:	60e2                	ld	ra,24(sp)
    80003a4a:	6442                	ld	s0,16(sp)
    80003a4c:	64a2                	ld	s1,8(sp)
    80003a4e:	6902                	ld	s2,0(sp)
    80003a50:	6105                	addi	sp,sp,32
    80003a52:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003a54:	40bc                	lw	a5,64(s1)
    80003a56:	dff1                	beqz	a5,80003a32 <iput+0x26>
    80003a58:	04a49783          	lh	a5,74(s1)
    80003a5c:	fbf9                	bnez	a5,80003a32 <iput+0x26>
    acquiresleep(&ip->lock);
    80003a5e:	01048913          	addi	s2,s1,16
    80003a62:	854a                	mv	a0,s2
    80003a64:	00001097          	auipc	ra,0x1
    80003a68:	aae080e7          	jalr	-1362(ra) # 80004512 <acquiresleep>
    release(&itable.lock);
    80003a6c:	0001c517          	auipc	a0,0x1c
    80003a70:	b0c50513          	addi	a0,a0,-1268 # 8001f578 <itable>
    80003a74:	ffffd097          	auipc	ra,0xffffd
    80003a78:	216080e7          	jalr	534(ra) # 80000c8a <release>
    itrunc(ip);
    80003a7c:	8526                	mv	a0,s1
    80003a7e:	00000097          	auipc	ra,0x0
    80003a82:	ee2080e7          	jalr	-286(ra) # 80003960 <itrunc>
    ip->type = 0;
    80003a86:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80003a8a:	8526                	mv	a0,s1
    80003a8c:	00000097          	auipc	ra,0x0
    80003a90:	cfa080e7          	jalr	-774(ra) # 80003786 <iupdate>
    ip->valid = 0;
    80003a94:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80003a98:	854a                	mv	a0,s2
    80003a9a:	00001097          	auipc	ra,0x1
    80003a9e:	ace080e7          	jalr	-1330(ra) # 80004568 <releasesleep>
    acquire(&itable.lock);
    80003aa2:	0001c517          	auipc	a0,0x1c
    80003aa6:	ad650513          	addi	a0,a0,-1322 # 8001f578 <itable>
    80003aaa:	ffffd097          	auipc	ra,0xffffd
    80003aae:	12c080e7          	jalr	300(ra) # 80000bd6 <acquire>
    80003ab2:	b741                	j	80003a32 <iput+0x26>

0000000080003ab4 <iunlockput>:
{
    80003ab4:	1101                	addi	sp,sp,-32
    80003ab6:	ec06                	sd	ra,24(sp)
    80003ab8:	e822                	sd	s0,16(sp)
    80003aba:	e426                	sd	s1,8(sp)
    80003abc:	1000                	addi	s0,sp,32
    80003abe:	84aa                	mv	s1,a0
  iunlock(ip);
    80003ac0:	00000097          	auipc	ra,0x0
    80003ac4:	e54080e7          	jalr	-428(ra) # 80003914 <iunlock>
  iput(ip);
    80003ac8:	8526                	mv	a0,s1
    80003aca:	00000097          	auipc	ra,0x0
    80003ace:	f42080e7          	jalr	-190(ra) # 80003a0c <iput>
}
    80003ad2:	60e2                	ld	ra,24(sp)
    80003ad4:	6442                	ld	s0,16(sp)
    80003ad6:	64a2                	ld	s1,8(sp)
    80003ad8:	6105                	addi	sp,sp,32
    80003ada:	8082                	ret

0000000080003adc <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003adc:	1141                	addi	sp,sp,-16
    80003ade:	e422                	sd	s0,8(sp)
    80003ae0:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003ae2:	411c                	lw	a5,0(a0)
    80003ae4:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003ae6:	415c                	lw	a5,4(a0)
    80003ae8:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003aea:	04451783          	lh	a5,68(a0)
    80003aee:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003af2:	04a51783          	lh	a5,74(a0)
    80003af6:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003afa:	04c56783          	lwu	a5,76(a0)
    80003afe:	e99c                	sd	a5,16(a1)
}
    80003b00:	6422                	ld	s0,8(sp)
    80003b02:	0141                	addi	sp,sp,16
    80003b04:	8082                	ret

0000000080003b06 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003b06:	457c                	lw	a5,76(a0)
    80003b08:	0ed7e963          	bltu	a5,a3,80003bfa <readi+0xf4>
{
    80003b0c:	7159                	addi	sp,sp,-112
    80003b0e:	f486                	sd	ra,104(sp)
    80003b10:	f0a2                	sd	s0,96(sp)
    80003b12:	eca6                	sd	s1,88(sp)
    80003b14:	e8ca                	sd	s2,80(sp)
    80003b16:	e4ce                	sd	s3,72(sp)
    80003b18:	e0d2                	sd	s4,64(sp)
    80003b1a:	fc56                	sd	s5,56(sp)
    80003b1c:	f85a                	sd	s6,48(sp)
    80003b1e:	f45e                	sd	s7,40(sp)
    80003b20:	f062                	sd	s8,32(sp)
    80003b22:	ec66                	sd	s9,24(sp)
    80003b24:	e86a                	sd	s10,16(sp)
    80003b26:	e46e                	sd	s11,8(sp)
    80003b28:	1880                	addi	s0,sp,112
    80003b2a:	8b2a                	mv	s6,a0
    80003b2c:	8bae                	mv	s7,a1
    80003b2e:	8a32                	mv	s4,a2
    80003b30:	84b6                	mv	s1,a3
    80003b32:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003b34:	9f35                	addw	a4,a4,a3
    return 0;
    80003b36:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80003b38:	0ad76063          	bltu	a4,a3,80003bd8 <readi+0xd2>
  if(off + n > ip->size)
    80003b3c:	00e7f463          	bgeu	a5,a4,80003b44 <readi+0x3e>
    n = ip->size - off;
    80003b40:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003b44:	0a0a8963          	beqz	s5,80003bf6 <readi+0xf0>
    80003b48:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003b4a:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003b4e:	5c7d                	li	s8,-1
    80003b50:	a82d                	j	80003b8a <readi+0x84>
    80003b52:	020d1d93          	slli	s11,s10,0x20
    80003b56:	020ddd93          	srli	s11,s11,0x20
    80003b5a:	05890613          	addi	a2,s2,88
    80003b5e:	86ee                	mv	a3,s11
    80003b60:	963a                	add	a2,a2,a4
    80003b62:	85d2                	mv	a1,s4
    80003b64:	855e                	mv	a0,s7
    80003b66:	fffff097          	auipc	ra,0xfffff
    80003b6a:	ace080e7          	jalr	-1330(ra) # 80002634 <either_copyout>
    80003b6e:	05850d63          	beq	a0,s8,80003bc8 <readi+0xc2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003b72:	854a                	mv	a0,s2
    80003b74:	fffff097          	auipc	ra,0xfffff
    80003b78:	5f6080e7          	jalr	1526(ra) # 8000316a <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003b7c:	013d09bb          	addw	s3,s10,s3
    80003b80:	009d04bb          	addw	s1,s10,s1
    80003b84:	9a6e                	add	s4,s4,s11
    80003b86:	0559f763          	bgeu	s3,s5,80003bd4 <readi+0xce>
    uint addr = bmap(ip, off/BSIZE);
    80003b8a:	00a4d59b          	srliw	a1,s1,0xa
    80003b8e:	855a                	mv	a0,s6
    80003b90:	00000097          	auipc	ra,0x0
    80003b94:	89e080e7          	jalr	-1890(ra) # 8000342e <bmap>
    80003b98:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003b9c:	cd85                	beqz	a1,80003bd4 <readi+0xce>
    bp = bread(ip->dev, addr);
    80003b9e:	000b2503          	lw	a0,0(s6)
    80003ba2:	fffff097          	auipc	ra,0xfffff
    80003ba6:	498080e7          	jalr	1176(ra) # 8000303a <bread>
    80003baa:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003bac:	3ff4f713          	andi	a4,s1,1023
    80003bb0:	40ec87bb          	subw	a5,s9,a4
    80003bb4:	413a86bb          	subw	a3,s5,s3
    80003bb8:	8d3e                	mv	s10,a5
    80003bba:	2781                	sext.w	a5,a5
    80003bbc:	0006861b          	sext.w	a2,a3
    80003bc0:	f8f679e3          	bgeu	a2,a5,80003b52 <readi+0x4c>
    80003bc4:	8d36                	mv	s10,a3
    80003bc6:	b771                	j	80003b52 <readi+0x4c>
      brelse(bp);
    80003bc8:	854a                	mv	a0,s2
    80003bca:	fffff097          	auipc	ra,0xfffff
    80003bce:	5a0080e7          	jalr	1440(ra) # 8000316a <brelse>
      tot = -1;
    80003bd2:	59fd                	li	s3,-1
  }
  return tot;
    80003bd4:	0009851b          	sext.w	a0,s3
}
    80003bd8:	70a6                	ld	ra,104(sp)
    80003bda:	7406                	ld	s0,96(sp)
    80003bdc:	64e6                	ld	s1,88(sp)
    80003bde:	6946                	ld	s2,80(sp)
    80003be0:	69a6                	ld	s3,72(sp)
    80003be2:	6a06                	ld	s4,64(sp)
    80003be4:	7ae2                	ld	s5,56(sp)
    80003be6:	7b42                	ld	s6,48(sp)
    80003be8:	7ba2                	ld	s7,40(sp)
    80003bea:	7c02                	ld	s8,32(sp)
    80003bec:	6ce2                	ld	s9,24(sp)
    80003bee:	6d42                	ld	s10,16(sp)
    80003bf0:	6da2                	ld	s11,8(sp)
    80003bf2:	6165                	addi	sp,sp,112
    80003bf4:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003bf6:	89d6                	mv	s3,s5
    80003bf8:	bff1                	j	80003bd4 <readi+0xce>
    return 0;
    80003bfa:	4501                	li	a0,0
}
    80003bfc:	8082                	ret

0000000080003bfe <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003bfe:	457c                	lw	a5,76(a0)
    80003c00:	10d7e863          	bltu	a5,a3,80003d10 <writei+0x112>
{
    80003c04:	7159                	addi	sp,sp,-112
    80003c06:	f486                	sd	ra,104(sp)
    80003c08:	f0a2                	sd	s0,96(sp)
    80003c0a:	eca6                	sd	s1,88(sp)
    80003c0c:	e8ca                	sd	s2,80(sp)
    80003c0e:	e4ce                	sd	s3,72(sp)
    80003c10:	e0d2                	sd	s4,64(sp)
    80003c12:	fc56                	sd	s5,56(sp)
    80003c14:	f85a                	sd	s6,48(sp)
    80003c16:	f45e                	sd	s7,40(sp)
    80003c18:	f062                	sd	s8,32(sp)
    80003c1a:	ec66                	sd	s9,24(sp)
    80003c1c:	e86a                	sd	s10,16(sp)
    80003c1e:	e46e                	sd	s11,8(sp)
    80003c20:	1880                	addi	s0,sp,112
    80003c22:	8aaa                	mv	s5,a0
    80003c24:	8bae                	mv	s7,a1
    80003c26:	8a32                	mv	s4,a2
    80003c28:	8936                	mv	s2,a3
    80003c2a:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003c2c:	00e687bb          	addw	a5,a3,a4
    80003c30:	0ed7e263          	bltu	a5,a3,80003d14 <writei+0x116>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80003c34:	00043737          	lui	a4,0x43
    80003c38:	0ef76063          	bltu	a4,a5,80003d18 <writei+0x11a>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003c3c:	0c0b0863          	beqz	s6,80003d0c <writei+0x10e>
    80003c40:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003c42:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003c46:	5c7d                	li	s8,-1
    80003c48:	a091                	j	80003c8c <writei+0x8e>
    80003c4a:	020d1d93          	slli	s11,s10,0x20
    80003c4e:	020ddd93          	srli	s11,s11,0x20
    80003c52:	05848513          	addi	a0,s1,88
    80003c56:	86ee                	mv	a3,s11
    80003c58:	8652                	mv	a2,s4
    80003c5a:	85de                	mv	a1,s7
    80003c5c:	953a                	add	a0,a0,a4
    80003c5e:	fffff097          	auipc	ra,0xfffff
    80003c62:	a2c080e7          	jalr	-1492(ra) # 8000268a <either_copyin>
    80003c66:	07850263          	beq	a0,s8,80003cca <writei+0xcc>
      brelse(bp);
      break;
    }
    log_write(bp);
    80003c6a:	8526                	mv	a0,s1
    80003c6c:	00000097          	auipc	ra,0x0
    80003c70:	788080e7          	jalr	1928(ra) # 800043f4 <log_write>
    brelse(bp);
    80003c74:	8526                	mv	a0,s1
    80003c76:	fffff097          	auipc	ra,0xfffff
    80003c7a:	4f4080e7          	jalr	1268(ra) # 8000316a <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003c7e:	013d09bb          	addw	s3,s10,s3
    80003c82:	012d093b          	addw	s2,s10,s2
    80003c86:	9a6e                	add	s4,s4,s11
    80003c88:	0569f663          	bgeu	s3,s6,80003cd4 <writei+0xd6>
    uint addr = bmap(ip, off/BSIZE);
    80003c8c:	00a9559b          	srliw	a1,s2,0xa
    80003c90:	8556                	mv	a0,s5
    80003c92:	fffff097          	auipc	ra,0xfffff
    80003c96:	79c080e7          	jalr	1948(ra) # 8000342e <bmap>
    80003c9a:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003c9e:	c99d                	beqz	a1,80003cd4 <writei+0xd6>
    bp = bread(ip->dev, addr);
    80003ca0:	000aa503          	lw	a0,0(s5)
    80003ca4:	fffff097          	auipc	ra,0xfffff
    80003ca8:	396080e7          	jalr	918(ra) # 8000303a <bread>
    80003cac:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003cae:	3ff97713          	andi	a4,s2,1023
    80003cb2:	40ec87bb          	subw	a5,s9,a4
    80003cb6:	413b06bb          	subw	a3,s6,s3
    80003cba:	8d3e                	mv	s10,a5
    80003cbc:	2781                	sext.w	a5,a5
    80003cbe:	0006861b          	sext.w	a2,a3
    80003cc2:	f8f674e3          	bgeu	a2,a5,80003c4a <writei+0x4c>
    80003cc6:	8d36                	mv	s10,a3
    80003cc8:	b749                	j	80003c4a <writei+0x4c>
      brelse(bp);
    80003cca:	8526                	mv	a0,s1
    80003ccc:	fffff097          	auipc	ra,0xfffff
    80003cd0:	49e080e7          	jalr	1182(ra) # 8000316a <brelse>
  }

  if(off > ip->size)
    80003cd4:	04caa783          	lw	a5,76(s5)
    80003cd8:	0127f463          	bgeu	a5,s2,80003ce0 <writei+0xe2>
    ip->size = off;
    80003cdc:	052aa623          	sw	s2,76(s5)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003ce0:	8556                	mv	a0,s5
    80003ce2:	00000097          	auipc	ra,0x0
    80003ce6:	aa4080e7          	jalr	-1372(ra) # 80003786 <iupdate>

  return tot;
    80003cea:	0009851b          	sext.w	a0,s3
}
    80003cee:	70a6                	ld	ra,104(sp)
    80003cf0:	7406                	ld	s0,96(sp)
    80003cf2:	64e6                	ld	s1,88(sp)
    80003cf4:	6946                	ld	s2,80(sp)
    80003cf6:	69a6                	ld	s3,72(sp)
    80003cf8:	6a06                	ld	s4,64(sp)
    80003cfa:	7ae2                	ld	s5,56(sp)
    80003cfc:	7b42                	ld	s6,48(sp)
    80003cfe:	7ba2                	ld	s7,40(sp)
    80003d00:	7c02                	ld	s8,32(sp)
    80003d02:	6ce2                	ld	s9,24(sp)
    80003d04:	6d42                	ld	s10,16(sp)
    80003d06:	6da2                	ld	s11,8(sp)
    80003d08:	6165                	addi	sp,sp,112
    80003d0a:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003d0c:	89da                	mv	s3,s6
    80003d0e:	bfc9                	j	80003ce0 <writei+0xe2>
    return -1;
    80003d10:	557d                	li	a0,-1
}
    80003d12:	8082                	ret
    return -1;
    80003d14:	557d                	li	a0,-1
    80003d16:	bfe1                	j	80003cee <writei+0xf0>
    return -1;
    80003d18:	557d                	li	a0,-1
    80003d1a:	bfd1                	j	80003cee <writei+0xf0>

0000000080003d1c <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003d1c:	1141                	addi	sp,sp,-16
    80003d1e:	e406                	sd	ra,8(sp)
    80003d20:	e022                	sd	s0,0(sp)
    80003d22:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003d24:	4639                	li	a2,14
    80003d26:	ffffd097          	auipc	ra,0xffffd
    80003d2a:	07c080e7          	jalr	124(ra) # 80000da2 <strncmp>
}
    80003d2e:	60a2                	ld	ra,8(sp)
    80003d30:	6402                	ld	s0,0(sp)
    80003d32:	0141                	addi	sp,sp,16
    80003d34:	8082                	ret

0000000080003d36 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003d36:	7139                	addi	sp,sp,-64
    80003d38:	fc06                	sd	ra,56(sp)
    80003d3a:	f822                	sd	s0,48(sp)
    80003d3c:	f426                	sd	s1,40(sp)
    80003d3e:	f04a                	sd	s2,32(sp)
    80003d40:	ec4e                	sd	s3,24(sp)
    80003d42:	e852                	sd	s4,16(sp)
    80003d44:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003d46:	04451703          	lh	a4,68(a0)
    80003d4a:	4785                	li	a5,1
    80003d4c:	00f71a63          	bne	a4,a5,80003d60 <dirlookup+0x2a>
    80003d50:	892a                	mv	s2,a0
    80003d52:	89ae                	mv	s3,a1
    80003d54:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003d56:	457c                	lw	a5,76(a0)
    80003d58:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003d5a:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003d5c:	e79d                	bnez	a5,80003d8a <dirlookup+0x54>
    80003d5e:	a8a5                	j	80003dd6 <dirlookup+0xa0>
    panic("dirlookup not DIR");
    80003d60:	00005517          	auipc	a0,0x5
    80003d64:	8e850513          	addi	a0,a0,-1816 # 80008648 <syscalls+0x1b0>
    80003d68:	ffffc097          	auipc	ra,0xffffc
    80003d6c:	7d8080e7          	jalr	2008(ra) # 80000540 <panic>
      panic("dirlookup read");
    80003d70:	00005517          	auipc	a0,0x5
    80003d74:	8f050513          	addi	a0,a0,-1808 # 80008660 <syscalls+0x1c8>
    80003d78:	ffffc097          	auipc	ra,0xffffc
    80003d7c:	7c8080e7          	jalr	1992(ra) # 80000540 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003d80:	24c1                	addiw	s1,s1,16
    80003d82:	04c92783          	lw	a5,76(s2)
    80003d86:	04f4f763          	bgeu	s1,a5,80003dd4 <dirlookup+0x9e>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003d8a:	4741                	li	a4,16
    80003d8c:	86a6                	mv	a3,s1
    80003d8e:	fc040613          	addi	a2,s0,-64
    80003d92:	4581                	li	a1,0
    80003d94:	854a                	mv	a0,s2
    80003d96:	00000097          	auipc	ra,0x0
    80003d9a:	d70080e7          	jalr	-656(ra) # 80003b06 <readi>
    80003d9e:	47c1                	li	a5,16
    80003da0:	fcf518e3          	bne	a0,a5,80003d70 <dirlookup+0x3a>
    if(de.inum == 0)
    80003da4:	fc045783          	lhu	a5,-64(s0)
    80003da8:	dfe1                	beqz	a5,80003d80 <dirlookup+0x4a>
    if(namecmp(name, de.name) == 0){
    80003daa:	fc240593          	addi	a1,s0,-62
    80003dae:	854e                	mv	a0,s3
    80003db0:	00000097          	auipc	ra,0x0
    80003db4:	f6c080e7          	jalr	-148(ra) # 80003d1c <namecmp>
    80003db8:	f561                	bnez	a0,80003d80 <dirlookup+0x4a>
      if(poff)
    80003dba:	000a0463          	beqz	s4,80003dc2 <dirlookup+0x8c>
        *poff = off;
    80003dbe:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003dc2:	fc045583          	lhu	a1,-64(s0)
    80003dc6:	00092503          	lw	a0,0(s2)
    80003dca:	fffff097          	auipc	ra,0xfffff
    80003dce:	74e080e7          	jalr	1870(ra) # 80003518 <iget>
    80003dd2:	a011                	j	80003dd6 <dirlookup+0xa0>
  return 0;
    80003dd4:	4501                	li	a0,0
}
    80003dd6:	70e2                	ld	ra,56(sp)
    80003dd8:	7442                	ld	s0,48(sp)
    80003dda:	74a2                	ld	s1,40(sp)
    80003ddc:	7902                	ld	s2,32(sp)
    80003dde:	69e2                	ld	s3,24(sp)
    80003de0:	6a42                	ld	s4,16(sp)
    80003de2:	6121                	addi	sp,sp,64
    80003de4:	8082                	ret

0000000080003de6 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003de6:	711d                	addi	sp,sp,-96
    80003de8:	ec86                	sd	ra,88(sp)
    80003dea:	e8a2                	sd	s0,80(sp)
    80003dec:	e4a6                	sd	s1,72(sp)
    80003dee:	e0ca                	sd	s2,64(sp)
    80003df0:	fc4e                	sd	s3,56(sp)
    80003df2:	f852                	sd	s4,48(sp)
    80003df4:	f456                	sd	s5,40(sp)
    80003df6:	f05a                	sd	s6,32(sp)
    80003df8:	ec5e                	sd	s7,24(sp)
    80003dfa:	e862                	sd	s8,16(sp)
    80003dfc:	e466                	sd	s9,8(sp)
    80003dfe:	e06a                	sd	s10,0(sp)
    80003e00:	1080                	addi	s0,sp,96
    80003e02:	84aa                	mv	s1,a0
    80003e04:	8b2e                	mv	s6,a1
    80003e06:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003e08:	00054703          	lbu	a4,0(a0)
    80003e0c:	02f00793          	li	a5,47
    80003e10:	02f70363          	beq	a4,a5,80003e36 <namex+0x50>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003e14:	ffffe097          	auipc	ra,0xffffe
    80003e18:	c82080e7          	jalr	-894(ra) # 80001a96 <myproc>
    80003e1c:	15053503          	ld	a0,336(a0)
    80003e20:	00000097          	auipc	ra,0x0
    80003e24:	9f4080e7          	jalr	-1548(ra) # 80003814 <idup>
    80003e28:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003e2a:	02f00913          	li	s2,47
  if(len >= DIRSIZ)
    80003e2e:	4cb5                	li	s9,13
  len = path - s;
    80003e30:	4b81                	li	s7,0

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003e32:	4c05                	li	s8,1
    80003e34:	a87d                	j	80003ef2 <namex+0x10c>
    ip = iget(ROOTDEV, ROOTINO);
    80003e36:	4585                	li	a1,1
    80003e38:	4505                	li	a0,1
    80003e3a:	fffff097          	auipc	ra,0xfffff
    80003e3e:	6de080e7          	jalr	1758(ra) # 80003518 <iget>
    80003e42:	8a2a                	mv	s4,a0
    80003e44:	b7dd                	j	80003e2a <namex+0x44>
      iunlockput(ip);
    80003e46:	8552                	mv	a0,s4
    80003e48:	00000097          	auipc	ra,0x0
    80003e4c:	c6c080e7          	jalr	-916(ra) # 80003ab4 <iunlockput>
      return 0;
    80003e50:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003e52:	8552                	mv	a0,s4
    80003e54:	60e6                	ld	ra,88(sp)
    80003e56:	6446                	ld	s0,80(sp)
    80003e58:	64a6                	ld	s1,72(sp)
    80003e5a:	6906                	ld	s2,64(sp)
    80003e5c:	79e2                	ld	s3,56(sp)
    80003e5e:	7a42                	ld	s4,48(sp)
    80003e60:	7aa2                	ld	s5,40(sp)
    80003e62:	7b02                	ld	s6,32(sp)
    80003e64:	6be2                	ld	s7,24(sp)
    80003e66:	6c42                	ld	s8,16(sp)
    80003e68:	6ca2                	ld	s9,8(sp)
    80003e6a:	6d02                	ld	s10,0(sp)
    80003e6c:	6125                	addi	sp,sp,96
    80003e6e:	8082                	ret
      iunlock(ip);
    80003e70:	8552                	mv	a0,s4
    80003e72:	00000097          	auipc	ra,0x0
    80003e76:	aa2080e7          	jalr	-1374(ra) # 80003914 <iunlock>
      return ip;
    80003e7a:	bfe1                	j	80003e52 <namex+0x6c>
      iunlockput(ip);
    80003e7c:	8552                	mv	a0,s4
    80003e7e:	00000097          	auipc	ra,0x0
    80003e82:	c36080e7          	jalr	-970(ra) # 80003ab4 <iunlockput>
      return 0;
    80003e86:	8a4e                	mv	s4,s3
    80003e88:	b7e9                	j	80003e52 <namex+0x6c>
  len = path - s;
    80003e8a:	40998633          	sub	a2,s3,s1
    80003e8e:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80003e92:	09acd863          	bge	s9,s10,80003f22 <namex+0x13c>
    memmove(name, s, DIRSIZ);
    80003e96:	4639                	li	a2,14
    80003e98:	85a6                	mv	a1,s1
    80003e9a:	8556                	mv	a0,s5
    80003e9c:	ffffd097          	auipc	ra,0xffffd
    80003ea0:	e92080e7          	jalr	-366(ra) # 80000d2e <memmove>
    80003ea4:	84ce                	mv	s1,s3
  while(*path == '/')
    80003ea6:	0004c783          	lbu	a5,0(s1)
    80003eaa:	01279763          	bne	a5,s2,80003eb8 <namex+0xd2>
    path++;
    80003eae:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003eb0:	0004c783          	lbu	a5,0(s1)
    80003eb4:	ff278de3          	beq	a5,s2,80003eae <namex+0xc8>
    ilock(ip);
    80003eb8:	8552                	mv	a0,s4
    80003eba:	00000097          	auipc	ra,0x0
    80003ebe:	998080e7          	jalr	-1640(ra) # 80003852 <ilock>
    if(ip->type != T_DIR){
    80003ec2:	044a1783          	lh	a5,68(s4)
    80003ec6:	f98790e3          	bne	a5,s8,80003e46 <namex+0x60>
    if(nameiparent && *path == '\0'){
    80003eca:	000b0563          	beqz	s6,80003ed4 <namex+0xee>
    80003ece:	0004c783          	lbu	a5,0(s1)
    80003ed2:	dfd9                	beqz	a5,80003e70 <namex+0x8a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003ed4:	865e                	mv	a2,s7
    80003ed6:	85d6                	mv	a1,s5
    80003ed8:	8552                	mv	a0,s4
    80003eda:	00000097          	auipc	ra,0x0
    80003ede:	e5c080e7          	jalr	-420(ra) # 80003d36 <dirlookup>
    80003ee2:	89aa                	mv	s3,a0
    80003ee4:	dd41                	beqz	a0,80003e7c <namex+0x96>
    iunlockput(ip);
    80003ee6:	8552                	mv	a0,s4
    80003ee8:	00000097          	auipc	ra,0x0
    80003eec:	bcc080e7          	jalr	-1076(ra) # 80003ab4 <iunlockput>
    ip = next;
    80003ef0:	8a4e                	mv	s4,s3
  while(*path == '/')
    80003ef2:	0004c783          	lbu	a5,0(s1)
    80003ef6:	01279763          	bne	a5,s2,80003f04 <namex+0x11e>
    path++;
    80003efa:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003efc:	0004c783          	lbu	a5,0(s1)
    80003f00:	ff278de3          	beq	a5,s2,80003efa <namex+0x114>
  if(*path == 0)
    80003f04:	cb9d                	beqz	a5,80003f3a <namex+0x154>
  while(*path != '/' && *path != 0)
    80003f06:	0004c783          	lbu	a5,0(s1)
    80003f0a:	89a6                	mv	s3,s1
  len = path - s;
    80003f0c:	8d5e                	mv	s10,s7
    80003f0e:	865e                	mv	a2,s7
  while(*path != '/' && *path != 0)
    80003f10:	01278963          	beq	a5,s2,80003f22 <namex+0x13c>
    80003f14:	dbbd                	beqz	a5,80003e8a <namex+0xa4>
    path++;
    80003f16:	0985                	addi	s3,s3,1
  while(*path != '/' && *path != 0)
    80003f18:	0009c783          	lbu	a5,0(s3)
    80003f1c:	ff279ce3          	bne	a5,s2,80003f14 <namex+0x12e>
    80003f20:	b7ad                	j	80003e8a <namex+0xa4>
    memmove(name, s, len);
    80003f22:	2601                	sext.w	a2,a2
    80003f24:	85a6                	mv	a1,s1
    80003f26:	8556                	mv	a0,s5
    80003f28:	ffffd097          	auipc	ra,0xffffd
    80003f2c:	e06080e7          	jalr	-506(ra) # 80000d2e <memmove>
    name[len] = 0;
    80003f30:	9d56                	add	s10,s10,s5
    80003f32:	000d0023          	sb	zero,0(s10)
    80003f36:	84ce                	mv	s1,s3
    80003f38:	b7bd                	j	80003ea6 <namex+0xc0>
  if(nameiparent){
    80003f3a:	f00b0ce3          	beqz	s6,80003e52 <namex+0x6c>
    iput(ip);
    80003f3e:	8552                	mv	a0,s4
    80003f40:	00000097          	auipc	ra,0x0
    80003f44:	acc080e7          	jalr	-1332(ra) # 80003a0c <iput>
    return 0;
    80003f48:	4a01                	li	s4,0
    80003f4a:	b721                	j	80003e52 <namex+0x6c>

0000000080003f4c <dirlink>:
{
    80003f4c:	7139                	addi	sp,sp,-64
    80003f4e:	fc06                	sd	ra,56(sp)
    80003f50:	f822                	sd	s0,48(sp)
    80003f52:	f426                	sd	s1,40(sp)
    80003f54:	f04a                	sd	s2,32(sp)
    80003f56:	ec4e                	sd	s3,24(sp)
    80003f58:	e852                	sd	s4,16(sp)
    80003f5a:	0080                	addi	s0,sp,64
    80003f5c:	892a                	mv	s2,a0
    80003f5e:	8a2e                	mv	s4,a1
    80003f60:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003f62:	4601                	li	a2,0
    80003f64:	00000097          	auipc	ra,0x0
    80003f68:	dd2080e7          	jalr	-558(ra) # 80003d36 <dirlookup>
    80003f6c:	e93d                	bnez	a0,80003fe2 <dirlink+0x96>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003f6e:	04c92483          	lw	s1,76(s2)
    80003f72:	c49d                	beqz	s1,80003fa0 <dirlink+0x54>
    80003f74:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003f76:	4741                	li	a4,16
    80003f78:	86a6                	mv	a3,s1
    80003f7a:	fc040613          	addi	a2,s0,-64
    80003f7e:	4581                	li	a1,0
    80003f80:	854a                	mv	a0,s2
    80003f82:	00000097          	auipc	ra,0x0
    80003f86:	b84080e7          	jalr	-1148(ra) # 80003b06 <readi>
    80003f8a:	47c1                	li	a5,16
    80003f8c:	06f51163          	bne	a0,a5,80003fee <dirlink+0xa2>
    if(de.inum == 0)
    80003f90:	fc045783          	lhu	a5,-64(s0)
    80003f94:	c791                	beqz	a5,80003fa0 <dirlink+0x54>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003f96:	24c1                	addiw	s1,s1,16
    80003f98:	04c92783          	lw	a5,76(s2)
    80003f9c:	fcf4ede3          	bltu	s1,a5,80003f76 <dirlink+0x2a>
  strncpy(de.name, name, DIRSIZ);
    80003fa0:	4639                	li	a2,14
    80003fa2:	85d2                	mv	a1,s4
    80003fa4:	fc240513          	addi	a0,s0,-62
    80003fa8:	ffffd097          	auipc	ra,0xffffd
    80003fac:	e36080e7          	jalr	-458(ra) # 80000dde <strncpy>
  de.inum = inum;
    80003fb0:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003fb4:	4741                	li	a4,16
    80003fb6:	86a6                	mv	a3,s1
    80003fb8:	fc040613          	addi	a2,s0,-64
    80003fbc:	4581                	li	a1,0
    80003fbe:	854a                	mv	a0,s2
    80003fc0:	00000097          	auipc	ra,0x0
    80003fc4:	c3e080e7          	jalr	-962(ra) # 80003bfe <writei>
    80003fc8:	1541                	addi	a0,a0,-16
    80003fca:	00a03533          	snez	a0,a0
    80003fce:	40a00533          	neg	a0,a0
}
    80003fd2:	70e2                	ld	ra,56(sp)
    80003fd4:	7442                	ld	s0,48(sp)
    80003fd6:	74a2                	ld	s1,40(sp)
    80003fd8:	7902                	ld	s2,32(sp)
    80003fda:	69e2                	ld	s3,24(sp)
    80003fdc:	6a42                	ld	s4,16(sp)
    80003fde:	6121                	addi	sp,sp,64
    80003fe0:	8082                	ret
    iput(ip);
    80003fe2:	00000097          	auipc	ra,0x0
    80003fe6:	a2a080e7          	jalr	-1494(ra) # 80003a0c <iput>
    return -1;
    80003fea:	557d                	li	a0,-1
    80003fec:	b7dd                	j	80003fd2 <dirlink+0x86>
      panic("dirlink read");
    80003fee:	00004517          	auipc	a0,0x4
    80003ff2:	68250513          	addi	a0,a0,1666 # 80008670 <syscalls+0x1d8>
    80003ff6:	ffffc097          	auipc	ra,0xffffc
    80003ffa:	54a080e7          	jalr	1354(ra) # 80000540 <panic>

0000000080003ffe <namei>:

struct inode*
namei(char *path)
{
    80003ffe:	1101                	addi	sp,sp,-32
    80004000:	ec06                	sd	ra,24(sp)
    80004002:	e822                	sd	s0,16(sp)
    80004004:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80004006:	fe040613          	addi	a2,s0,-32
    8000400a:	4581                	li	a1,0
    8000400c:	00000097          	auipc	ra,0x0
    80004010:	dda080e7          	jalr	-550(ra) # 80003de6 <namex>
}
    80004014:	60e2                	ld	ra,24(sp)
    80004016:	6442                	ld	s0,16(sp)
    80004018:	6105                	addi	sp,sp,32
    8000401a:	8082                	ret

000000008000401c <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    8000401c:	1141                	addi	sp,sp,-16
    8000401e:	e406                	sd	ra,8(sp)
    80004020:	e022                	sd	s0,0(sp)
    80004022:	0800                	addi	s0,sp,16
    80004024:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80004026:	4585                	li	a1,1
    80004028:	00000097          	auipc	ra,0x0
    8000402c:	dbe080e7          	jalr	-578(ra) # 80003de6 <namex>
}
    80004030:	60a2                	ld	ra,8(sp)
    80004032:	6402                	ld	s0,0(sp)
    80004034:	0141                	addi	sp,sp,16
    80004036:	8082                	ret

0000000080004038 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80004038:	1101                	addi	sp,sp,-32
    8000403a:	ec06                	sd	ra,24(sp)
    8000403c:	e822                	sd	s0,16(sp)
    8000403e:	e426                	sd	s1,8(sp)
    80004040:	e04a                	sd	s2,0(sp)
    80004042:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80004044:	0001d917          	auipc	s2,0x1d
    80004048:	fdc90913          	addi	s2,s2,-36 # 80021020 <log>
    8000404c:	01892583          	lw	a1,24(s2)
    80004050:	02892503          	lw	a0,40(s2)
    80004054:	fffff097          	auipc	ra,0xfffff
    80004058:	fe6080e7          	jalr	-26(ra) # 8000303a <bread>
    8000405c:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    8000405e:	02c92683          	lw	a3,44(s2)
    80004062:	cd34                	sw	a3,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80004064:	02d05863          	blez	a3,80004094 <write_head+0x5c>
    80004068:	0001d797          	auipc	a5,0x1d
    8000406c:	fe878793          	addi	a5,a5,-24 # 80021050 <log+0x30>
    80004070:	05c50713          	addi	a4,a0,92
    80004074:	36fd                	addiw	a3,a3,-1
    80004076:	02069613          	slli	a2,a3,0x20
    8000407a:	01e65693          	srli	a3,a2,0x1e
    8000407e:	0001d617          	auipc	a2,0x1d
    80004082:	fd660613          	addi	a2,a2,-42 # 80021054 <log+0x34>
    80004086:	96b2                	add	a3,a3,a2
    hb->block[i] = log.lh.block[i];
    80004088:	4390                	lw	a2,0(a5)
    8000408a:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    8000408c:	0791                	addi	a5,a5,4
    8000408e:	0711                	addi	a4,a4,4 # 43004 <_entry-0x7ffbcffc>
    80004090:	fed79ce3          	bne	a5,a3,80004088 <write_head+0x50>
  }
  bwrite(buf);
    80004094:	8526                	mv	a0,s1
    80004096:	fffff097          	auipc	ra,0xfffff
    8000409a:	096080e7          	jalr	150(ra) # 8000312c <bwrite>
  brelse(buf);
    8000409e:	8526                	mv	a0,s1
    800040a0:	fffff097          	auipc	ra,0xfffff
    800040a4:	0ca080e7          	jalr	202(ra) # 8000316a <brelse>
}
    800040a8:	60e2                	ld	ra,24(sp)
    800040aa:	6442                	ld	s0,16(sp)
    800040ac:	64a2                	ld	s1,8(sp)
    800040ae:	6902                	ld	s2,0(sp)
    800040b0:	6105                	addi	sp,sp,32
    800040b2:	8082                	ret

00000000800040b4 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    800040b4:	0001d797          	auipc	a5,0x1d
    800040b8:	f987a783          	lw	a5,-104(a5) # 8002104c <log+0x2c>
    800040bc:	0af05d63          	blez	a5,80004176 <install_trans+0xc2>
{
    800040c0:	7139                	addi	sp,sp,-64
    800040c2:	fc06                	sd	ra,56(sp)
    800040c4:	f822                	sd	s0,48(sp)
    800040c6:	f426                	sd	s1,40(sp)
    800040c8:	f04a                	sd	s2,32(sp)
    800040ca:	ec4e                	sd	s3,24(sp)
    800040cc:	e852                	sd	s4,16(sp)
    800040ce:	e456                	sd	s5,8(sp)
    800040d0:	e05a                	sd	s6,0(sp)
    800040d2:	0080                	addi	s0,sp,64
    800040d4:	8b2a                	mv	s6,a0
    800040d6:	0001da97          	auipc	s5,0x1d
    800040da:	f7aa8a93          	addi	s5,s5,-134 # 80021050 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    800040de:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    800040e0:	0001d997          	auipc	s3,0x1d
    800040e4:	f4098993          	addi	s3,s3,-192 # 80021020 <log>
    800040e8:	a00d                	j	8000410a <install_trans+0x56>
    brelse(lbuf);
    800040ea:	854a                	mv	a0,s2
    800040ec:	fffff097          	auipc	ra,0xfffff
    800040f0:	07e080e7          	jalr	126(ra) # 8000316a <brelse>
    brelse(dbuf);
    800040f4:	8526                	mv	a0,s1
    800040f6:	fffff097          	auipc	ra,0xfffff
    800040fa:	074080e7          	jalr	116(ra) # 8000316a <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800040fe:	2a05                	addiw	s4,s4,1
    80004100:	0a91                	addi	s5,s5,4
    80004102:	02c9a783          	lw	a5,44(s3)
    80004106:	04fa5e63          	bge	s4,a5,80004162 <install_trans+0xae>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    8000410a:	0189a583          	lw	a1,24(s3)
    8000410e:	014585bb          	addw	a1,a1,s4
    80004112:	2585                	addiw	a1,a1,1
    80004114:	0289a503          	lw	a0,40(s3)
    80004118:	fffff097          	auipc	ra,0xfffff
    8000411c:	f22080e7          	jalr	-222(ra) # 8000303a <bread>
    80004120:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80004122:	000aa583          	lw	a1,0(s5)
    80004126:	0289a503          	lw	a0,40(s3)
    8000412a:	fffff097          	auipc	ra,0xfffff
    8000412e:	f10080e7          	jalr	-240(ra) # 8000303a <bread>
    80004132:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80004134:	40000613          	li	a2,1024
    80004138:	05890593          	addi	a1,s2,88
    8000413c:	05850513          	addi	a0,a0,88
    80004140:	ffffd097          	auipc	ra,0xffffd
    80004144:	bee080e7          	jalr	-1042(ra) # 80000d2e <memmove>
    bwrite(dbuf);  // write dst to disk
    80004148:	8526                	mv	a0,s1
    8000414a:	fffff097          	auipc	ra,0xfffff
    8000414e:	fe2080e7          	jalr	-30(ra) # 8000312c <bwrite>
    if(recovering == 0)
    80004152:	f80b1ce3          	bnez	s6,800040ea <install_trans+0x36>
      bunpin(dbuf);
    80004156:	8526                	mv	a0,s1
    80004158:	fffff097          	auipc	ra,0xfffff
    8000415c:	0ec080e7          	jalr	236(ra) # 80003244 <bunpin>
    80004160:	b769                	j	800040ea <install_trans+0x36>
}
    80004162:	70e2                	ld	ra,56(sp)
    80004164:	7442                	ld	s0,48(sp)
    80004166:	74a2                	ld	s1,40(sp)
    80004168:	7902                	ld	s2,32(sp)
    8000416a:	69e2                	ld	s3,24(sp)
    8000416c:	6a42                	ld	s4,16(sp)
    8000416e:	6aa2                	ld	s5,8(sp)
    80004170:	6b02                	ld	s6,0(sp)
    80004172:	6121                	addi	sp,sp,64
    80004174:	8082                	ret
    80004176:	8082                	ret

0000000080004178 <initlog>:
{
    80004178:	7179                	addi	sp,sp,-48
    8000417a:	f406                	sd	ra,40(sp)
    8000417c:	f022                	sd	s0,32(sp)
    8000417e:	ec26                	sd	s1,24(sp)
    80004180:	e84a                	sd	s2,16(sp)
    80004182:	e44e                	sd	s3,8(sp)
    80004184:	1800                	addi	s0,sp,48
    80004186:	892a                	mv	s2,a0
    80004188:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    8000418a:	0001d497          	auipc	s1,0x1d
    8000418e:	e9648493          	addi	s1,s1,-362 # 80021020 <log>
    80004192:	00004597          	auipc	a1,0x4
    80004196:	4ee58593          	addi	a1,a1,1262 # 80008680 <syscalls+0x1e8>
    8000419a:	8526                	mv	a0,s1
    8000419c:	ffffd097          	auipc	ra,0xffffd
    800041a0:	9aa080e7          	jalr	-1622(ra) # 80000b46 <initlock>
  log.start = sb->logstart;
    800041a4:	0149a583          	lw	a1,20(s3)
    800041a8:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    800041aa:	0109a783          	lw	a5,16(s3)
    800041ae:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    800041b0:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    800041b4:	854a                	mv	a0,s2
    800041b6:	fffff097          	auipc	ra,0xfffff
    800041ba:	e84080e7          	jalr	-380(ra) # 8000303a <bread>
  log.lh.n = lh->n;
    800041be:	4d34                	lw	a3,88(a0)
    800041c0:	d4d4                	sw	a3,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    800041c2:	02d05663          	blez	a3,800041ee <initlog+0x76>
    800041c6:	05c50793          	addi	a5,a0,92
    800041ca:	0001d717          	auipc	a4,0x1d
    800041ce:	e8670713          	addi	a4,a4,-378 # 80021050 <log+0x30>
    800041d2:	36fd                	addiw	a3,a3,-1
    800041d4:	02069613          	slli	a2,a3,0x20
    800041d8:	01e65693          	srli	a3,a2,0x1e
    800041dc:	06050613          	addi	a2,a0,96
    800041e0:	96b2                	add	a3,a3,a2
    log.lh.block[i] = lh->block[i];
    800041e2:	4390                	lw	a2,0(a5)
    800041e4:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    800041e6:	0791                	addi	a5,a5,4
    800041e8:	0711                	addi	a4,a4,4
    800041ea:	fed79ce3          	bne	a5,a3,800041e2 <initlog+0x6a>
  brelse(buf);
    800041ee:	fffff097          	auipc	ra,0xfffff
    800041f2:	f7c080e7          	jalr	-132(ra) # 8000316a <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    800041f6:	4505                	li	a0,1
    800041f8:	00000097          	auipc	ra,0x0
    800041fc:	ebc080e7          	jalr	-324(ra) # 800040b4 <install_trans>
  log.lh.n = 0;
    80004200:	0001d797          	auipc	a5,0x1d
    80004204:	e407a623          	sw	zero,-436(a5) # 8002104c <log+0x2c>
  write_head(); // clear the log
    80004208:	00000097          	auipc	ra,0x0
    8000420c:	e30080e7          	jalr	-464(ra) # 80004038 <write_head>
}
    80004210:	70a2                	ld	ra,40(sp)
    80004212:	7402                	ld	s0,32(sp)
    80004214:	64e2                	ld	s1,24(sp)
    80004216:	6942                	ld	s2,16(sp)
    80004218:	69a2                	ld	s3,8(sp)
    8000421a:	6145                	addi	sp,sp,48
    8000421c:	8082                	ret

000000008000421e <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    8000421e:	1101                	addi	sp,sp,-32
    80004220:	ec06                	sd	ra,24(sp)
    80004222:	e822                	sd	s0,16(sp)
    80004224:	e426                	sd	s1,8(sp)
    80004226:	e04a                	sd	s2,0(sp)
    80004228:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    8000422a:	0001d517          	auipc	a0,0x1d
    8000422e:	df650513          	addi	a0,a0,-522 # 80021020 <log>
    80004232:	ffffd097          	auipc	ra,0xffffd
    80004236:	9a4080e7          	jalr	-1628(ra) # 80000bd6 <acquire>
  while(1){
    if(log.committing){
    8000423a:	0001d497          	auipc	s1,0x1d
    8000423e:	de648493          	addi	s1,s1,-538 # 80021020 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80004242:	4979                	li	s2,30
    80004244:	a039                	j	80004252 <begin_op+0x34>
      sleep(&log, &log.lock);
    80004246:	85a6                	mv	a1,s1
    80004248:	8526                	mv	a0,s1
    8000424a:	ffffe097          	auipc	ra,0xffffe
    8000424e:	fe2080e7          	jalr	-30(ra) # 8000222c <sleep>
    if(log.committing){
    80004252:	50dc                	lw	a5,36(s1)
    80004254:	fbed                	bnez	a5,80004246 <begin_op+0x28>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80004256:	5098                	lw	a4,32(s1)
    80004258:	2705                	addiw	a4,a4,1
    8000425a:	0007069b          	sext.w	a3,a4
    8000425e:	0027179b          	slliw	a5,a4,0x2
    80004262:	9fb9                	addw	a5,a5,a4
    80004264:	0017979b          	slliw	a5,a5,0x1
    80004268:	54d8                	lw	a4,44(s1)
    8000426a:	9fb9                	addw	a5,a5,a4
    8000426c:	00f95963          	bge	s2,a5,8000427e <begin_op+0x60>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80004270:	85a6                	mv	a1,s1
    80004272:	8526                	mv	a0,s1
    80004274:	ffffe097          	auipc	ra,0xffffe
    80004278:	fb8080e7          	jalr	-72(ra) # 8000222c <sleep>
    8000427c:	bfd9                	j	80004252 <begin_op+0x34>
    } else {
      log.outstanding += 1;
    8000427e:	0001d517          	auipc	a0,0x1d
    80004282:	da250513          	addi	a0,a0,-606 # 80021020 <log>
    80004286:	d114                	sw	a3,32(a0)
      release(&log.lock);
    80004288:	ffffd097          	auipc	ra,0xffffd
    8000428c:	a02080e7          	jalr	-1534(ra) # 80000c8a <release>
      break;
    }
  }
}
    80004290:	60e2                	ld	ra,24(sp)
    80004292:	6442                	ld	s0,16(sp)
    80004294:	64a2                	ld	s1,8(sp)
    80004296:	6902                	ld	s2,0(sp)
    80004298:	6105                	addi	sp,sp,32
    8000429a:	8082                	ret

000000008000429c <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    8000429c:	7139                	addi	sp,sp,-64
    8000429e:	fc06                	sd	ra,56(sp)
    800042a0:	f822                	sd	s0,48(sp)
    800042a2:	f426                	sd	s1,40(sp)
    800042a4:	f04a                	sd	s2,32(sp)
    800042a6:	ec4e                	sd	s3,24(sp)
    800042a8:	e852                	sd	s4,16(sp)
    800042aa:	e456                	sd	s5,8(sp)
    800042ac:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    800042ae:	0001d497          	auipc	s1,0x1d
    800042b2:	d7248493          	addi	s1,s1,-654 # 80021020 <log>
    800042b6:	8526                	mv	a0,s1
    800042b8:	ffffd097          	auipc	ra,0xffffd
    800042bc:	91e080e7          	jalr	-1762(ra) # 80000bd6 <acquire>
  log.outstanding -= 1;
    800042c0:	509c                	lw	a5,32(s1)
    800042c2:	37fd                	addiw	a5,a5,-1
    800042c4:	0007891b          	sext.w	s2,a5
    800042c8:	d09c                	sw	a5,32(s1)
  if(log.committing)
    800042ca:	50dc                	lw	a5,36(s1)
    800042cc:	e7b9                	bnez	a5,8000431a <end_op+0x7e>
    panic("log.committing");
  if(log.outstanding == 0){
    800042ce:	04091e63          	bnez	s2,8000432a <end_op+0x8e>
    do_commit = 1;
    log.committing = 1;
    800042d2:	0001d497          	auipc	s1,0x1d
    800042d6:	d4e48493          	addi	s1,s1,-690 # 80021020 <log>
    800042da:	4785                	li	a5,1
    800042dc:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    800042de:	8526                	mv	a0,s1
    800042e0:	ffffd097          	auipc	ra,0xffffd
    800042e4:	9aa080e7          	jalr	-1622(ra) # 80000c8a <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    800042e8:	54dc                	lw	a5,44(s1)
    800042ea:	06f04763          	bgtz	a5,80004358 <end_op+0xbc>
    acquire(&log.lock);
    800042ee:	0001d497          	auipc	s1,0x1d
    800042f2:	d3248493          	addi	s1,s1,-718 # 80021020 <log>
    800042f6:	8526                	mv	a0,s1
    800042f8:	ffffd097          	auipc	ra,0xffffd
    800042fc:	8de080e7          	jalr	-1826(ra) # 80000bd6 <acquire>
    log.committing = 0;
    80004300:	0204a223          	sw	zero,36(s1)
    wakeup(&log);
    80004304:	8526                	mv	a0,s1
    80004306:	ffffe097          	auipc	ra,0xffffe
    8000430a:	f8a080e7          	jalr	-118(ra) # 80002290 <wakeup>
    release(&log.lock);
    8000430e:	8526                	mv	a0,s1
    80004310:	ffffd097          	auipc	ra,0xffffd
    80004314:	97a080e7          	jalr	-1670(ra) # 80000c8a <release>
}
    80004318:	a03d                	j	80004346 <end_op+0xaa>
    panic("log.committing");
    8000431a:	00004517          	auipc	a0,0x4
    8000431e:	36e50513          	addi	a0,a0,878 # 80008688 <syscalls+0x1f0>
    80004322:	ffffc097          	auipc	ra,0xffffc
    80004326:	21e080e7          	jalr	542(ra) # 80000540 <panic>
    wakeup(&log);
    8000432a:	0001d497          	auipc	s1,0x1d
    8000432e:	cf648493          	addi	s1,s1,-778 # 80021020 <log>
    80004332:	8526                	mv	a0,s1
    80004334:	ffffe097          	auipc	ra,0xffffe
    80004338:	f5c080e7          	jalr	-164(ra) # 80002290 <wakeup>
  release(&log.lock);
    8000433c:	8526                	mv	a0,s1
    8000433e:	ffffd097          	auipc	ra,0xffffd
    80004342:	94c080e7          	jalr	-1716(ra) # 80000c8a <release>
}
    80004346:	70e2                	ld	ra,56(sp)
    80004348:	7442                	ld	s0,48(sp)
    8000434a:	74a2                	ld	s1,40(sp)
    8000434c:	7902                	ld	s2,32(sp)
    8000434e:	69e2                	ld	s3,24(sp)
    80004350:	6a42                	ld	s4,16(sp)
    80004352:	6aa2                	ld	s5,8(sp)
    80004354:	6121                	addi	sp,sp,64
    80004356:	8082                	ret
  for (tail = 0; tail < log.lh.n; tail++) {
    80004358:	0001da97          	auipc	s5,0x1d
    8000435c:	cf8a8a93          	addi	s5,s5,-776 # 80021050 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80004360:	0001da17          	auipc	s4,0x1d
    80004364:	cc0a0a13          	addi	s4,s4,-832 # 80021020 <log>
    80004368:	018a2583          	lw	a1,24(s4)
    8000436c:	012585bb          	addw	a1,a1,s2
    80004370:	2585                	addiw	a1,a1,1
    80004372:	028a2503          	lw	a0,40(s4)
    80004376:	fffff097          	auipc	ra,0xfffff
    8000437a:	cc4080e7          	jalr	-828(ra) # 8000303a <bread>
    8000437e:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80004380:	000aa583          	lw	a1,0(s5)
    80004384:	028a2503          	lw	a0,40(s4)
    80004388:	fffff097          	auipc	ra,0xfffff
    8000438c:	cb2080e7          	jalr	-846(ra) # 8000303a <bread>
    80004390:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80004392:	40000613          	li	a2,1024
    80004396:	05850593          	addi	a1,a0,88
    8000439a:	05848513          	addi	a0,s1,88
    8000439e:	ffffd097          	auipc	ra,0xffffd
    800043a2:	990080e7          	jalr	-1648(ra) # 80000d2e <memmove>
    bwrite(to);  // write the log
    800043a6:	8526                	mv	a0,s1
    800043a8:	fffff097          	auipc	ra,0xfffff
    800043ac:	d84080e7          	jalr	-636(ra) # 8000312c <bwrite>
    brelse(from);
    800043b0:	854e                	mv	a0,s3
    800043b2:	fffff097          	auipc	ra,0xfffff
    800043b6:	db8080e7          	jalr	-584(ra) # 8000316a <brelse>
    brelse(to);
    800043ba:	8526                	mv	a0,s1
    800043bc:	fffff097          	auipc	ra,0xfffff
    800043c0:	dae080e7          	jalr	-594(ra) # 8000316a <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800043c4:	2905                	addiw	s2,s2,1
    800043c6:	0a91                	addi	s5,s5,4
    800043c8:	02ca2783          	lw	a5,44(s4)
    800043cc:	f8f94ee3          	blt	s2,a5,80004368 <end_op+0xcc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    800043d0:	00000097          	auipc	ra,0x0
    800043d4:	c68080e7          	jalr	-920(ra) # 80004038 <write_head>
    install_trans(0); // Now install writes to home locations
    800043d8:	4501                	li	a0,0
    800043da:	00000097          	auipc	ra,0x0
    800043de:	cda080e7          	jalr	-806(ra) # 800040b4 <install_trans>
    log.lh.n = 0;
    800043e2:	0001d797          	auipc	a5,0x1d
    800043e6:	c607a523          	sw	zero,-918(a5) # 8002104c <log+0x2c>
    write_head();    // Erase the transaction from the log
    800043ea:	00000097          	auipc	ra,0x0
    800043ee:	c4e080e7          	jalr	-946(ra) # 80004038 <write_head>
    800043f2:	bdf5                	j	800042ee <end_op+0x52>

00000000800043f4 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    800043f4:	1101                	addi	sp,sp,-32
    800043f6:	ec06                	sd	ra,24(sp)
    800043f8:	e822                	sd	s0,16(sp)
    800043fa:	e426                	sd	s1,8(sp)
    800043fc:	e04a                	sd	s2,0(sp)
    800043fe:	1000                	addi	s0,sp,32
    80004400:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80004402:	0001d917          	auipc	s2,0x1d
    80004406:	c1e90913          	addi	s2,s2,-994 # 80021020 <log>
    8000440a:	854a                	mv	a0,s2
    8000440c:	ffffc097          	auipc	ra,0xffffc
    80004410:	7ca080e7          	jalr	1994(ra) # 80000bd6 <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    80004414:	02c92603          	lw	a2,44(s2)
    80004418:	47f5                	li	a5,29
    8000441a:	06c7c563          	blt	a5,a2,80004484 <log_write+0x90>
    8000441e:	0001d797          	auipc	a5,0x1d
    80004422:	c1e7a783          	lw	a5,-994(a5) # 8002103c <log+0x1c>
    80004426:	37fd                	addiw	a5,a5,-1
    80004428:	04f65e63          	bge	a2,a5,80004484 <log_write+0x90>
    panic("too big a transaction");
  if (log.outstanding < 1)
    8000442c:	0001d797          	auipc	a5,0x1d
    80004430:	c147a783          	lw	a5,-1004(a5) # 80021040 <log+0x20>
    80004434:	06f05063          	blez	a5,80004494 <log_write+0xa0>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80004438:	4781                	li	a5,0
    8000443a:	06c05563          	blez	a2,800044a4 <log_write+0xb0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000443e:	44cc                	lw	a1,12(s1)
    80004440:	0001d717          	auipc	a4,0x1d
    80004444:	c1070713          	addi	a4,a4,-1008 # 80021050 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80004448:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000444a:	4314                	lw	a3,0(a4)
    8000444c:	04b68c63          	beq	a3,a1,800044a4 <log_write+0xb0>
  for (i = 0; i < log.lh.n; i++) {
    80004450:	2785                	addiw	a5,a5,1
    80004452:	0711                	addi	a4,a4,4
    80004454:	fef61be3          	bne	a2,a5,8000444a <log_write+0x56>
      break;
  }
  log.lh.block[i] = b->blockno;
    80004458:	0621                	addi	a2,a2,8
    8000445a:	060a                	slli	a2,a2,0x2
    8000445c:	0001d797          	auipc	a5,0x1d
    80004460:	bc478793          	addi	a5,a5,-1084 # 80021020 <log>
    80004464:	97b2                	add	a5,a5,a2
    80004466:	44d8                	lw	a4,12(s1)
    80004468:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    8000446a:	8526                	mv	a0,s1
    8000446c:	fffff097          	auipc	ra,0xfffff
    80004470:	d9c080e7          	jalr	-612(ra) # 80003208 <bpin>
    log.lh.n++;
    80004474:	0001d717          	auipc	a4,0x1d
    80004478:	bac70713          	addi	a4,a4,-1108 # 80021020 <log>
    8000447c:	575c                	lw	a5,44(a4)
    8000447e:	2785                	addiw	a5,a5,1
    80004480:	d75c                	sw	a5,44(a4)
    80004482:	a82d                	j	800044bc <log_write+0xc8>
    panic("too big a transaction");
    80004484:	00004517          	auipc	a0,0x4
    80004488:	21450513          	addi	a0,a0,532 # 80008698 <syscalls+0x200>
    8000448c:	ffffc097          	auipc	ra,0xffffc
    80004490:	0b4080e7          	jalr	180(ra) # 80000540 <panic>
    panic("log_write outside of trans");
    80004494:	00004517          	auipc	a0,0x4
    80004498:	21c50513          	addi	a0,a0,540 # 800086b0 <syscalls+0x218>
    8000449c:	ffffc097          	auipc	ra,0xffffc
    800044a0:	0a4080e7          	jalr	164(ra) # 80000540 <panic>
  log.lh.block[i] = b->blockno;
    800044a4:	00878693          	addi	a3,a5,8
    800044a8:	068a                	slli	a3,a3,0x2
    800044aa:	0001d717          	auipc	a4,0x1d
    800044ae:	b7670713          	addi	a4,a4,-1162 # 80021020 <log>
    800044b2:	9736                	add	a4,a4,a3
    800044b4:	44d4                	lw	a3,12(s1)
    800044b6:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    800044b8:	faf609e3          	beq	a2,a5,8000446a <log_write+0x76>
  }
  release(&log.lock);
    800044bc:	0001d517          	auipc	a0,0x1d
    800044c0:	b6450513          	addi	a0,a0,-1180 # 80021020 <log>
    800044c4:	ffffc097          	auipc	ra,0xffffc
    800044c8:	7c6080e7          	jalr	1990(ra) # 80000c8a <release>
}
    800044cc:	60e2                	ld	ra,24(sp)
    800044ce:	6442                	ld	s0,16(sp)
    800044d0:	64a2                	ld	s1,8(sp)
    800044d2:	6902                	ld	s2,0(sp)
    800044d4:	6105                	addi	sp,sp,32
    800044d6:	8082                	ret

00000000800044d8 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800044d8:	1101                	addi	sp,sp,-32
    800044da:	ec06                	sd	ra,24(sp)
    800044dc:	e822                	sd	s0,16(sp)
    800044de:	e426                	sd	s1,8(sp)
    800044e0:	e04a                	sd	s2,0(sp)
    800044e2:	1000                	addi	s0,sp,32
    800044e4:	84aa                	mv	s1,a0
    800044e6:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800044e8:	00004597          	auipc	a1,0x4
    800044ec:	1e858593          	addi	a1,a1,488 # 800086d0 <syscalls+0x238>
    800044f0:	0521                	addi	a0,a0,8
    800044f2:	ffffc097          	auipc	ra,0xffffc
    800044f6:	654080e7          	jalr	1620(ra) # 80000b46 <initlock>
  lk->name = name;
    800044fa:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    800044fe:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004502:	0204a423          	sw	zero,40(s1)
}
    80004506:	60e2                	ld	ra,24(sp)
    80004508:	6442                	ld	s0,16(sp)
    8000450a:	64a2                	ld	s1,8(sp)
    8000450c:	6902                	ld	s2,0(sp)
    8000450e:	6105                	addi	sp,sp,32
    80004510:	8082                	ret

0000000080004512 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80004512:	1101                	addi	sp,sp,-32
    80004514:	ec06                	sd	ra,24(sp)
    80004516:	e822                	sd	s0,16(sp)
    80004518:	e426                	sd	s1,8(sp)
    8000451a:	e04a                	sd	s2,0(sp)
    8000451c:	1000                	addi	s0,sp,32
    8000451e:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004520:	00850913          	addi	s2,a0,8
    80004524:	854a                	mv	a0,s2
    80004526:	ffffc097          	auipc	ra,0xffffc
    8000452a:	6b0080e7          	jalr	1712(ra) # 80000bd6 <acquire>
  while (lk->locked) {
    8000452e:	409c                	lw	a5,0(s1)
    80004530:	cb89                	beqz	a5,80004542 <acquiresleep+0x30>
    sleep(lk, &lk->lk);
    80004532:	85ca                	mv	a1,s2
    80004534:	8526                	mv	a0,s1
    80004536:	ffffe097          	auipc	ra,0xffffe
    8000453a:	cf6080e7          	jalr	-778(ra) # 8000222c <sleep>
  while (lk->locked) {
    8000453e:	409c                	lw	a5,0(s1)
    80004540:	fbed                	bnez	a5,80004532 <acquiresleep+0x20>
  }
  lk->locked = 1;
    80004542:	4785                	li	a5,1
    80004544:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80004546:	ffffd097          	auipc	ra,0xffffd
    8000454a:	550080e7          	jalr	1360(ra) # 80001a96 <myproc>
    8000454e:	591c                	lw	a5,48(a0)
    80004550:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80004552:	854a                	mv	a0,s2
    80004554:	ffffc097          	auipc	ra,0xffffc
    80004558:	736080e7          	jalr	1846(ra) # 80000c8a <release>
}
    8000455c:	60e2                	ld	ra,24(sp)
    8000455e:	6442                	ld	s0,16(sp)
    80004560:	64a2                	ld	s1,8(sp)
    80004562:	6902                	ld	s2,0(sp)
    80004564:	6105                	addi	sp,sp,32
    80004566:	8082                	ret

0000000080004568 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80004568:	1101                	addi	sp,sp,-32
    8000456a:	ec06                	sd	ra,24(sp)
    8000456c:	e822                	sd	s0,16(sp)
    8000456e:	e426                	sd	s1,8(sp)
    80004570:	e04a                	sd	s2,0(sp)
    80004572:	1000                	addi	s0,sp,32
    80004574:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004576:	00850913          	addi	s2,a0,8
    8000457a:	854a                	mv	a0,s2
    8000457c:	ffffc097          	auipc	ra,0xffffc
    80004580:	65a080e7          	jalr	1626(ra) # 80000bd6 <acquire>
  lk->locked = 0;
    80004584:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004588:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    8000458c:	8526                	mv	a0,s1
    8000458e:	ffffe097          	auipc	ra,0xffffe
    80004592:	d02080e7          	jalr	-766(ra) # 80002290 <wakeup>
  release(&lk->lk);
    80004596:	854a                	mv	a0,s2
    80004598:	ffffc097          	auipc	ra,0xffffc
    8000459c:	6f2080e7          	jalr	1778(ra) # 80000c8a <release>
}
    800045a0:	60e2                	ld	ra,24(sp)
    800045a2:	6442                	ld	s0,16(sp)
    800045a4:	64a2                	ld	s1,8(sp)
    800045a6:	6902                	ld	s2,0(sp)
    800045a8:	6105                	addi	sp,sp,32
    800045aa:	8082                	ret

00000000800045ac <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    800045ac:	7179                	addi	sp,sp,-48
    800045ae:	f406                	sd	ra,40(sp)
    800045b0:	f022                	sd	s0,32(sp)
    800045b2:	ec26                	sd	s1,24(sp)
    800045b4:	e84a                	sd	s2,16(sp)
    800045b6:	e44e                	sd	s3,8(sp)
    800045b8:	1800                	addi	s0,sp,48
    800045ba:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    800045bc:	00850913          	addi	s2,a0,8
    800045c0:	854a                	mv	a0,s2
    800045c2:	ffffc097          	auipc	ra,0xffffc
    800045c6:	614080e7          	jalr	1556(ra) # 80000bd6 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800045ca:	409c                	lw	a5,0(s1)
    800045cc:	ef99                	bnez	a5,800045ea <holdingsleep+0x3e>
    800045ce:	4481                	li	s1,0
  release(&lk->lk);
    800045d0:	854a                	mv	a0,s2
    800045d2:	ffffc097          	auipc	ra,0xffffc
    800045d6:	6b8080e7          	jalr	1720(ra) # 80000c8a <release>
  return r;
}
    800045da:	8526                	mv	a0,s1
    800045dc:	70a2                	ld	ra,40(sp)
    800045de:	7402                	ld	s0,32(sp)
    800045e0:	64e2                	ld	s1,24(sp)
    800045e2:	6942                	ld	s2,16(sp)
    800045e4:	69a2                	ld	s3,8(sp)
    800045e6:	6145                	addi	sp,sp,48
    800045e8:	8082                	ret
  r = lk->locked && (lk->pid == myproc()->pid);
    800045ea:	0284a983          	lw	s3,40(s1)
    800045ee:	ffffd097          	auipc	ra,0xffffd
    800045f2:	4a8080e7          	jalr	1192(ra) # 80001a96 <myproc>
    800045f6:	5904                	lw	s1,48(a0)
    800045f8:	413484b3          	sub	s1,s1,s3
    800045fc:	0014b493          	seqz	s1,s1
    80004600:	bfc1                	j	800045d0 <holdingsleep+0x24>

0000000080004602 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80004602:	1141                	addi	sp,sp,-16
    80004604:	e406                	sd	ra,8(sp)
    80004606:	e022                	sd	s0,0(sp)
    80004608:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    8000460a:	00004597          	auipc	a1,0x4
    8000460e:	0d658593          	addi	a1,a1,214 # 800086e0 <syscalls+0x248>
    80004612:	0001d517          	auipc	a0,0x1d
    80004616:	b5650513          	addi	a0,a0,-1194 # 80021168 <ftable>
    8000461a:	ffffc097          	auipc	ra,0xffffc
    8000461e:	52c080e7          	jalr	1324(ra) # 80000b46 <initlock>
}
    80004622:	60a2                	ld	ra,8(sp)
    80004624:	6402                	ld	s0,0(sp)
    80004626:	0141                	addi	sp,sp,16
    80004628:	8082                	ret

000000008000462a <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    8000462a:	1101                	addi	sp,sp,-32
    8000462c:	ec06                	sd	ra,24(sp)
    8000462e:	e822                	sd	s0,16(sp)
    80004630:	e426                	sd	s1,8(sp)
    80004632:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004634:	0001d517          	auipc	a0,0x1d
    80004638:	b3450513          	addi	a0,a0,-1228 # 80021168 <ftable>
    8000463c:	ffffc097          	auipc	ra,0xffffc
    80004640:	59a080e7          	jalr	1434(ra) # 80000bd6 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004644:	0001d497          	auipc	s1,0x1d
    80004648:	b3c48493          	addi	s1,s1,-1220 # 80021180 <ftable+0x18>
    8000464c:	0001e717          	auipc	a4,0x1e
    80004650:	ad470713          	addi	a4,a4,-1324 # 80022120 <disk>
    if(f->ref == 0){
    80004654:	40dc                	lw	a5,4(s1)
    80004656:	cf99                	beqz	a5,80004674 <filealloc+0x4a>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004658:	02848493          	addi	s1,s1,40
    8000465c:	fee49ce3          	bne	s1,a4,80004654 <filealloc+0x2a>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80004660:	0001d517          	auipc	a0,0x1d
    80004664:	b0850513          	addi	a0,a0,-1272 # 80021168 <ftable>
    80004668:	ffffc097          	auipc	ra,0xffffc
    8000466c:	622080e7          	jalr	1570(ra) # 80000c8a <release>
  return 0;
    80004670:	4481                	li	s1,0
    80004672:	a819                	j	80004688 <filealloc+0x5e>
      f->ref = 1;
    80004674:	4785                	li	a5,1
    80004676:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80004678:	0001d517          	auipc	a0,0x1d
    8000467c:	af050513          	addi	a0,a0,-1296 # 80021168 <ftable>
    80004680:	ffffc097          	auipc	ra,0xffffc
    80004684:	60a080e7          	jalr	1546(ra) # 80000c8a <release>
}
    80004688:	8526                	mv	a0,s1
    8000468a:	60e2                	ld	ra,24(sp)
    8000468c:	6442                	ld	s0,16(sp)
    8000468e:	64a2                	ld	s1,8(sp)
    80004690:	6105                	addi	sp,sp,32
    80004692:	8082                	ret

0000000080004694 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80004694:	1101                	addi	sp,sp,-32
    80004696:	ec06                	sd	ra,24(sp)
    80004698:	e822                	sd	s0,16(sp)
    8000469a:	e426                	sd	s1,8(sp)
    8000469c:	1000                	addi	s0,sp,32
    8000469e:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800046a0:	0001d517          	auipc	a0,0x1d
    800046a4:	ac850513          	addi	a0,a0,-1336 # 80021168 <ftable>
    800046a8:	ffffc097          	auipc	ra,0xffffc
    800046ac:	52e080e7          	jalr	1326(ra) # 80000bd6 <acquire>
  if(f->ref < 1)
    800046b0:	40dc                	lw	a5,4(s1)
    800046b2:	02f05263          	blez	a5,800046d6 <filedup+0x42>
    panic("filedup");
  f->ref++;
    800046b6:	2785                	addiw	a5,a5,1
    800046b8:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    800046ba:	0001d517          	auipc	a0,0x1d
    800046be:	aae50513          	addi	a0,a0,-1362 # 80021168 <ftable>
    800046c2:	ffffc097          	auipc	ra,0xffffc
    800046c6:	5c8080e7          	jalr	1480(ra) # 80000c8a <release>
  return f;
}
    800046ca:	8526                	mv	a0,s1
    800046cc:	60e2                	ld	ra,24(sp)
    800046ce:	6442                	ld	s0,16(sp)
    800046d0:	64a2                	ld	s1,8(sp)
    800046d2:	6105                	addi	sp,sp,32
    800046d4:	8082                	ret
    panic("filedup");
    800046d6:	00004517          	auipc	a0,0x4
    800046da:	01250513          	addi	a0,a0,18 # 800086e8 <syscalls+0x250>
    800046de:	ffffc097          	auipc	ra,0xffffc
    800046e2:	e62080e7          	jalr	-414(ra) # 80000540 <panic>

00000000800046e6 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800046e6:	7139                	addi	sp,sp,-64
    800046e8:	fc06                	sd	ra,56(sp)
    800046ea:	f822                	sd	s0,48(sp)
    800046ec:	f426                	sd	s1,40(sp)
    800046ee:	f04a                	sd	s2,32(sp)
    800046f0:	ec4e                	sd	s3,24(sp)
    800046f2:	e852                	sd	s4,16(sp)
    800046f4:	e456                	sd	s5,8(sp)
    800046f6:	0080                	addi	s0,sp,64
    800046f8:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800046fa:	0001d517          	auipc	a0,0x1d
    800046fe:	a6e50513          	addi	a0,a0,-1426 # 80021168 <ftable>
    80004702:	ffffc097          	auipc	ra,0xffffc
    80004706:	4d4080e7          	jalr	1236(ra) # 80000bd6 <acquire>
  if(f->ref < 1)
    8000470a:	40dc                	lw	a5,4(s1)
    8000470c:	06f05163          	blez	a5,8000476e <fileclose+0x88>
    panic("fileclose");
  if(--f->ref > 0){
    80004710:	37fd                	addiw	a5,a5,-1
    80004712:	0007871b          	sext.w	a4,a5
    80004716:	c0dc                	sw	a5,4(s1)
    80004718:	06e04363          	bgtz	a4,8000477e <fileclose+0x98>
    release(&ftable.lock);
    return;
  }
  ff = *f;
    8000471c:	0004a903          	lw	s2,0(s1)
    80004720:	0094ca83          	lbu	s5,9(s1)
    80004724:	0104ba03          	ld	s4,16(s1)
    80004728:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    8000472c:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80004730:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004734:	0001d517          	auipc	a0,0x1d
    80004738:	a3450513          	addi	a0,a0,-1484 # 80021168 <ftable>
    8000473c:	ffffc097          	auipc	ra,0xffffc
    80004740:	54e080e7          	jalr	1358(ra) # 80000c8a <release>

  if(ff.type == FD_PIPE){
    80004744:	4785                	li	a5,1
    80004746:	04f90d63          	beq	s2,a5,800047a0 <fileclose+0xba>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    8000474a:	3979                	addiw	s2,s2,-2
    8000474c:	4785                	li	a5,1
    8000474e:	0527e063          	bltu	a5,s2,8000478e <fileclose+0xa8>
    begin_op();
    80004752:	00000097          	auipc	ra,0x0
    80004756:	acc080e7          	jalr	-1332(ra) # 8000421e <begin_op>
    iput(ff.ip);
    8000475a:	854e                	mv	a0,s3
    8000475c:	fffff097          	auipc	ra,0xfffff
    80004760:	2b0080e7          	jalr	688(ra) # 80003a0c <iput>
    end_op();
    80004764:	00000097          	auipc	ra,0x0
    80004768:	b38080e7          	jalr	-1224(ra) # 8000429c <end_op>
    8000476c:	a00d                	j	8000478e <fileclose+0xa8>
    panic("fileclose");
    8000476e:	00004517          	auipc	a0,0x4
    80004772:	f8250513          	addi	a0,a0,-126 # 800086f0 <syscalls+0x258>
    80004776:	ffffc097          	auipc	ra,0xffffc
    8000477a:	dca080e7          	jalr	-566(ra) # 80000540 <panic>
    release(&ftable.lock);
    8000477e:	0001d517          	auipc	a0,0x1d
    80004782:	9ea50513          	addi	a0,a0,-1558 # 80021168 <ftable>
    80004786:	ffffc097          	auipc	ra,0xffffc
    8000478a:	504080e7          	jalr	1284(ra) # 80000c8a <release>
  }
}
    8000478e:	70e2                	ld	ra,56(sp)
    80004790:	7442                	ld	s0,48(sp)
    80004792:	74a2                	ld	s1,40(sp)
    80004794:	7902                	ld	s2,32(sp)
    80004796:	69e2                	ld	s3,24(sp)
    80004798:	6a42                	ld	s4,16(sp)
    8000479a:	6aa2                	ld	s5,8(sp)
    8000479c:	6121                	addi	sp,sp,64
    8000479e:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800047a0:	85d6                	mv	a1,s5
    800047a2:	8552                	mv	a0,s4
    800047a4:	00000097          	auipc	ra,0x0
    800047a8:	34c080e7          	jalr	844(ra) # 80004af0 <pipeclose>
    800047ac:	b7cd                	j	8000478e <fileclose+0xa8>

00000000800047ae <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800047ae:	715d                	addi	sp,sp,-80
    800047b0:	e486                	sd	ra,72(sp)
    800047b2:	e0a2                	sd	s0,64(sp)
    800047b4:	fc26                	sd	s1,56(sp)
    800047b6:	f84a                	sd	s2,48(sp)
    800047b8:	f44e                	sd	s3,40(sp)
    800047ba:	0880                	addi	s0,sp,80
    800047bc:	84aa                	mv	s1,a0
    800047be:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    800047c0:	ffffd097          	auipc	ra,0xffffd
    800047c4:	2d6080e7          	jalr	726(ra) # 80001a96 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    800047c8:	409c                	lw	a5,0(s1)
    800047ca:	37f9                	addiw	a5,a5,-2
    800047cc:	4705                	li	a4,1
    800047ce:	04f76763          	bltu	a4,a5,8000481c <filestat+0x6e>
    800047d2:	892a                	mv	s2,a0
    ilock(f->ip);
    800047d4:	6c88                	ld	a0,24(s1)
    800047d6:	fffff097          	auipc	ra,0xfffff
    800047da:	07c080e7          	jalr	124(ra) # 80003852 <ilock>
    stati(f->ip, &st);
    800047de:	fb840593          	addi	a1,s0,-72
    800047e2:	6c88                	ld	a0,24(s1)
    800047e4:	fffff097          	auipc	ra,0xfffff
    800047e8:	2f8080e7          	jalr	760(ra) # 80003adc <stati>
    iunlock(f->ip);
    800047ec:	6c88                	ld	a0,24(s1)
    800047ee:	fffff097          	auipc	ra,0xfffff
    800047f2:	126080e7          	jalr	294(ra) # 80003914 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800047f6:	46e1                	li	a3,24
    800047f8:	fb840613          	addi	a2,s0,-72
    800047fc:	85ce                	mv	a1,s3
    800047fe:	05093503          	ld	a0,80(s2)
    80004802:	ffffd097          	auipc	ra,0xffffd
    80004806:	f54080e7          	jalr	-172(ra) # 80001756 <copyout>
    8000480a:	41f5551b          	sraiw	a0,a0,0x1f
      return -1;
    return 0;
  }
  return -1;
}
    8000480e:	60a6                	ld	ra,72(sp)
    80004810:	6406                	ld	s0,64(sp)
    80004812:	74e2                	ld	s1,56(sp)
    80004814:	7942                	ld	s2,48(sp)
    80004816:	79a2                	ld	s3,40(sp)
    80004818:	6161                	addi	sp,sp,80
    8000481a:	8082                	ret
  return -1;
    8000481c:	557d                	li	a0,-1
    8000481e:	bfc5                	j	8000480e <filestat+0x60>

0000000080004820 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80004820:	7179                	addi	sp,sp,-48
    80004822:	f406                	sd	ra,40(sp)
    80004824:	f022                	sd	s0,32(sp)
    80004826:	ec26                	sd	s1,24(sp)
    80004828:	e84a                	sd	s2,16(sp)
    8000482a:	e44e                	sd	s3,8(sp)
    8000482c:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    8000482e:	00854783          	lbu	a5,8(a0)
    80004832:	c3d5                	beqz	a5,800048d6 <fileread+0xb6>
    80004834:	84aa                	mv	s1,a0
    80004836:	89ae                	mv	s3,a1
    80004838:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    8000483a:	411c                	lw	a5,0(a0)
    8000483c:	4705                	li	a4,1
    8000483e:	04e78963          	beq	a5,a4,80004890 <fileread+0x70>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004842:	470d                	li	a4,3
    80004844:	04e78d63          	beq	a5,a4,8000489e <fileread+0x7e>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80004848:	4709                	li	a4,2
    8000484a:	06e79e63          	bne	a5,a4,800048c6 <fileread+0xa6>
    ilock(f->ip);
    8000484e:	6d08                	ld	a0,24(a0)
    80004850:	fffff097          	auipc	ra,0xfffff
    80004854:	002080e7          	jalr	2(ra) # 80003852 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004858:	874a                	mv	a4,s2
    8000485a:	5094                	lw	a3,32(s1)
    8000485c:	864e                	mv	a2,s3
    8000485e:	4585                	li	a1,1
    80004860:	6c88                	ld	a0,24(s1)
    80004862:	fffff097          	auipc	ra,0xfffff
    80004866:	2a4080e7          	jalr	676(ra) # 80003b06 <readi>
    8000486a:	892a                	mv	s2,a0
    8000486c:	00a05563          	blez	a0,80004876 <fileread+0x56>
      f->off += r;
    80004870:	509c                	lw	a5,32(s1)
    80004872:	9fa9                	addw	a5,a5,a0
    80004874:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004876:	6c88                	ld	a0,24(s1)
    80004878:	fffff097          	auipc	ra,0xfffff
    8000487c:	09c080e7          	jalr	156(ra) # 80003914 <iunlock>
  } else {
    panic("fileread");
  }

  return r;
}
    80004880:	854a                	mv	a0,s2
    80004882:	70a2                	ld	ra,40(sp)
    80004884:	7402                	ld	s0,32(sp)
    80004886:	64e2                	ld	s1,24(sp)
    80004888:	6942                	ld	s2,16(sp)
    8000488a:	69a2                	ld	s3,8(sp)
    8000488c:	6145                	addi	sp,sp,48
    8000488e:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004890:	6908                	ld	a0,16(a0)
    80004892:	00000097          	auipc	ra,0x0
    80004896:	3c6080e7          	jalr	966(ra) # 80004c58 <piperead>
    8000489a:	892a                	mv	s2,a0
    8000489c:	b7d5                	j	80004880 <fileread+0x60>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    8000489e:	02451783          	lh	a5,36(a0)
    800048a2:	03079693          	slli	a3,a5,0x30
    800048a6:	92c1                	srli	a3,a3,0x30
    800048a8:	4725                	li	a4,9
    800048aa:	02d76863          	bltu	a4,a3,800048da <fileread+0xba>
    800048ae:	0792                	slli	a5,a5,0x4
    800048b0:	0001d717          	auipc	a4,0x1d
    800048b4:	81870713          	addi	a4,a4,-2024 # 800210c8 <devsw>
    800048b8:	97ba                	add	a5,a5,a4
    800048ba:	639c                	ld	a5,0(a5)
    800048bc:	c38d                	beqz	a5,800048de <fileread+0xbe>
    r = devsw[f->major].read(1, addr, n);
    800048be:	4505                	li	a0,1
    800048c0:	9782                	jalr	a5
    800048c2:	892a                	mv	s2,a0
    800048c4:	bf75                	j	80004880 <fileread+0x60>
    panic("fileread");
    800048c6:	00004517          	auipc	a0,0x4
    800048ca:	e3a50513          	addi	a0,a0,-454 # 80008700 <syscalls+0x268>
    800048ce:	ffffc097          	auipc	ra,0xffffc
    800048d2:	c72080e7          	jalr	-910(ra) # 80000540 <panic>
    return -1;
    800048d6:	597d                	li	s2,-1
    800048d8:	b765                	j	80004880 <fileread+0x60>
      return -1;
    800048da:	597d                	li	s2,-1
    800048dc:	b755                	j	80004880 <fileread+0x60>
    800048de:	597d                	li	s2,-1
    800048e0:	b745                	j	80004880 <fileread+0x60>

00000000800048e2 <filewrite>:

// Write to file f.
// addr is a user virtual address.
int
filewrite(struct file *f, uint64 addr, int n)
{
    800048e2:	715d                	addi	sp,sp,-80
    800048e4:	e486                	sd	ra,72(sp)
    800048e6:	e0a2                	sd	s0,64(sp)
    800048e8:	fc26                	sd	s1,56(sp)
    800048ea:	f84a                	sd	s2,48(sp)
    800048ec:	f44e                	sd	s3,40(sp)
    800048ee:	f052                	sd	s4,32(sp)
    800048f0:	ec56                	sd	s5,24(sp)
    800048f2:	e85a                	sd	s6,16(sp)
    800048f4:	e45e                	sd	s7,8(sp)
    800048f6:	e062                	sd	s8,0(sp)
    800048f8:	0880                	addi	s0,sp,80
  int r, ret = 0;

  if(f->writable == 0)
    800048fa:	00954783          	lbu	a5,9(a0)
    800048fe:	10078663          	beqz	a5,80004a0a <filewrite+0x128>
    80004902:	892a                	mv	s2,a0
    80004904:	8b2e                	mv	s6,a1
    80004906:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    80004908:	411c                	lw	a5,0(a0)
    8000490a:	4705                	li	a4,1
    8000490c:	02e78263          	beq	a5,a4,80004930 <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004910:	470d                	li	a4,3
    80004912:	02e78663          	beq	a5,a4,8000493e <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    80004916:	4709                	li	a4,2
    80004918:	0ee79163          	bne	a5,a4,800049fa <filewrite+0x118>
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    8000491c:	0ac05d63          	blez	a2,800049d6 <filewrite+0xf4>
    int i = 0;
    80004920:	4981                	li	s3,0
    80004922:	6b85                	lui	s7,0x1
    80004924:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80004928:	6c05                	lui	s8,0x1
    8000492a:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    8000492e:	a861                	j	800049c6 <filewrite+0xe4>
    ret = pipewrite(f->pipe, addr, n);
    80004930:	6908                	ld	a0,16(a0)
    80004932:	00000097          	auipc	ra,0x0
    80004936:	22e080e7          	jalr	558(ra) # 80004b60 <pipewrite>
    8000493a:	8a2a                	mv	s4,a0
    8000493c:	a045                	j	800049dc <filewrite+0xfa>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    8000493e:	02451783          	lh	a5,36(a0)
    80004942:	03079693          	slli	a3,a5,0x30
    80004946:	92c1                	srli	a3,a3,0x30
    80004948:	4725                	li	a4,9
    8000494a:	0cd76263          	bltu	a4,a3,80004a0e <filewrite+0x12c>
    8000494e:	0792                	slli	a5,a5,0x4
    80004950:	0001c717          	auipc	a4,0x1c
    80004954:	77870713          	addi	a4,a4,1912 # 800210c8 <devsw>
    80004958:	97ba                	add	a5,a5,a4
    8000495a:	679c                	ld	a5,8(a5)
    8000495c:	cbdd                	beqz	a5,80004a12 <filewrite+0x130>
    ret = devsw[f->major].write(1, addr, n);
    8000495e:	4505                	li	a0,1
    80004960:	9782                	jalr	a5
    80004962:	8a2a                	mv	s4,a0
    80004964:	a8a5                	j	800049dc <filewrite+0xfa>
    80004966:	00048a9b          	sext.w	s5,s1
      int n1 = n - i;
      if(n1 > max)
        n1 = max;

      begin_op();
    8000496a:	00000097          	auipc	ra,0x0
    8000496e:	8b4080e7          	jalr	-1868(ra) # 8000421e <begin_op>
      ilock(f->ip);
    80004972:	01893503          	ld	a0,24(s2)
    80004976:	fffff097          	auipc	ra,0xfffff
    8000497a:	edc080e7          	jalr	-292(ra) # 80003852 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    8000497e:	8756                	mv	a4,s5
    80004980:	02092683          	lw	a3,32(s2)
    80004984:	01698633          	add	a2,s3,s6
    80004988:	4585                	li	a1,1
    8000498a:	01893503          	ld	a0,24(s2)
    8000498e:	fffff097          	auipc	ra,0xfffff
    80004992:	270080e7          	jalr	624(ra) # 80003bfe <writei>
    80004996:	84aa                	mv	s1,a0
    80004998:	00a05763          	blez	a0,800049a6 <filewrite+0xc4>
        f->off += r;
    8000499c:	02092783          	lw	a5,32(s2)
    800049a0:	9fa9                	addw	a5,a5,a0
    800049a2:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    800049a6:	01893503          	ld	a0,24(s2)
    800049aa:	fffff097          	auipc	ra,0xfffff
    800049ae:	f6a080e7          	jalr	-150(ra) # 80003914 <iunlock>
      end_op();
    800049b2:	00000097          	auipc	ra,0x0
    800049b6:	8ea080e7          	jalr	-1814(ra) # 8000429c <end_op>

      if(r != n1){
    800049ba:	009a9f63          	bne	s5,s1,800049d8 <filewrite+0xf6>
        // error from writei
        break;
      }
      i += r;
    800049be:	013489bb          	addw	s3,s1,s3
    while(i < n){
    800049c2:	0149db63          	bge	s3,s4,800049d8 <filewrite+0xf6>
      int n1 = n - i;
    800049c6:	413a04bb          	subw	s1,s4,s3
    800049ca:	0004879b          	sext.w	a5,s1
    800049ce:	f8fbdce3          	bge	s7,a5,80004966 <filewrite+0x84>
    800049d2:	84e2                	mv	s1,s8
    800049d4:	bf49                	j	80004966 <filewrite+0x84>
    int i = 0;
    800049d6:	4981                	li	s3,0
    }
    ret = (i == n ? n : -1);
    800049d8:	013a1f63          	bne	s4,s3,800049f6 <filewrite+0x114>
  } else {
    panic("filewrite");
  }

  return ret;
}
    800049dc:	8552                	mv	a0,s4
    800049de:	60a6                	ld	ra,72(sp)
    800049e0:	6406                	ld	s0,64(sp)
    800049e2:	74e2                	ld	s1,56(sp)
    800049e4:	7942                	ld	s2,48(sp)
    800049e6:	79a2                	ld	s3,40(sp)
    800049e8:	7a02                	ld	s4,32(sp)
    800049ea:	6ae2                	ld	s5,24(sp)
    800049ec:	6b42                	ld	s6,16(sp)
    800049ee:	6ba2                	ld	s7,8(sp)
    800049f0:	6c02                	ld	s8,0(sp)
    800049f2:	6161                	addi	sp,sp,80
    800049f4:	8082                	ret
    ret = (i == n ? n : -1);
    800049f6:	5a7d                	li	s4,-1
    800049f8:	b7d5                	j	800049dc <filewrite+0xfa>
    panic("filewrite");
    800049fa:	00004517          	auipc	a0,0x4
    800049fe:	d1650513          	addi	a0,a0,-746 # 80008710 <syscalls+0x278>
    80004a02:	ffffc097          	auipc	ra,0xffffc
    80004a06:	b3e080e7          	jalr	-1218(ra) # 80000540 <panic>
    return -1;
    80004a0a:	5a7d                	li	s4,-1
    80004a0c:	bfc1                	j	800049dc <filewrite+0xfa>
      return -1;
    80004a0e:	5a7d                	li	s4,-1
    80004a10:	b7f1                	j	800049dc <filewrite+0xfa>
    80004a12:	5a7d                	li	s4,-1
    80004a14:	b7e1                	j	800049dc <filewrite+0xfa>

0000000080004a16 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004a16:	7179                	addi	sp,sp,-48
    80004a18:	f406                	sd	ra,40(sp)
    80004a1a:	f022                	sd	s0,32(sp)
    80004a1c:	ec26                	sd	s1,24(sp)
    80004a1e:	e84a                	sd	s2,16(sp)
    80004a20:	e44e                	sd	s3,8(sp)
    80004a22:	e052                	sd	s4,0(sp)
    80004a24:	1800                	addi	s0,sp,48
    80004a26:	84aa                	mv	s1,a0
    80004a28:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004a2a:	0005b023          	sd	zero,0(a1)
    80004a2e:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80004a32:	00000097          	auipc	ra,0x0
    80004a36:	bf8080e7          	jalr	-1032(ra) # 8000462a <filealloc>
    80004a3a:	e088                	sd	a0,0(s1)
    80004a3c:	c551                	beqz	a0,80004ac8 <pipealloc+0xb2>
    80004a3e:	00000097          	auipc	ra,0x0
    80004a42:	bec080e7          	jalr	-1044(ra) # 8000462a <filealloc>
    80004a46:	00aa3023          	sd	a0,0(s4)
    80004a4a:	c92d                	beqz	a0,80004abc <pipealloc+0xa6>
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80004a4c:	ffffc097          	auipc	ra,0xffffc
    80004a50:	09a080e7          	jalr	154(ra) # 80000ae6 <kalloc>
    80004a54:	892a                	mv	s2,a0
    80004a56:	c125                	beqz	a0,80004ab6 <pipealloc+0xa0>
    goto bad;
  pi->readopen = 1;
    80004a58:	4985                	li	s3,1
    80004a5a:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004a5e:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004a62:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004a66:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004a6a:	00004597          	auipc	a1,0x4
    80004a6e:	cb658593          	addi	a1,a1,-842 # 80008720 <syscalls+0x288>
    80004a72:	ffffc097          	auipc	ra,0xffffc
    80004a76:	0d4080e7          	jalr	212(ra) # 80000b46 <initlock>
  (*f0)->type = FD_PIPE;
    80004a7a:	609c                	ld	a5,0(s1)
    80004a7c:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004a80:	609c                	ld	a5,0(s1)
    80004a82:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004a86:	609c                	ld	a5,0(s1)
    80004a88:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004a8c:	609c                	ld	a5,0(s1)
    80004a8e:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004a92:	000a3783          	ld	a5,0(s4)
    80004a96:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004a9a:	000a3783          	ld	a5,0(s4)
    80004a9e:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004aa2:	000a3783          	ld	a5,0(s4)
    80004aa6:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004aaa:	000a3783          	ld	a5,0(s4)
    80004aae:	0127b823          	sd	s2,16(a5)
  return 0;
    80004ab2:	4501                	li	a0,0
    80004ab4:	a025                	j	80004adc <pipealloc+0xc6>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80004ab6:	6088                	ld	a0,0(s1)
    80004ab8:	e501                	bnez	a0,80004ac0 <pipealloc+0xaa>
    80004aba:	a039                	j	80004ac8 <pipealloc+0xb2>
    80004abc:	6088                	ld	a0,0(s1)
    80004abe:	c51d                	beqz	a0,80004aec <pipealloc+0xd6>
    fileclose(*f0);
    80004ac0:	00000097          	auipc	ra,0x0
    80004ac4:	c26080e7          	jalr	-986(ra) # 800046e6 <fileclose>
  if(*f1)
    80004ac8:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004acc:	557d                	li	a0,-1
  if(*f1)
    80004ace:	c799                	beqz	a5,80004adc <pipealloc+0xc6>
    fileclose(*f1);
    80004ad0:	853e                	mv	a0,a5
    80004ad2:	00000097          	auipc	ra,0x0
    80004ad6:	c14080e7          	jalr	-1004(ra) # 800046e6 <fileclose>
  return -1;
    80004ada:	557d                	li	a0,-1
}
    80004adc:	70a2                	ld	ra,40(sp)
    80004ade:	7402                	ld	s0,32(sp)
    80004ae0:	64e2                	ld	s1,24(sp)
    80004ae2:	6942                	ld	s2,16(sp)
    80004ae4:	69a2                	ld	s3,8(sp)
    80004ae6:	6a02                	ld	s4,0(sp)
    80004ae8:	6145                	addi	sp,sp,48
    80004aea:	8082                	ret
  return -1;
    80004aec:	557d                	li	a0,-1
    80004aee:	b7fd                	j	80004adc <pipealloc+0xc6>

0000000080004af0 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004af0:	1101                	addi	sp,sp,-32
    80004af2:	ec06                	sd	ra,24(sp)
    80004af4:	e822                	sd	s0,16(sp)
    80004af6:	e426                	sd	s1,8(sp)
    80004af8:	e04a                	sd	s2,0(sp)
    80004afa:	1000                	addi	s0,sp,32
    80004afc:	84aa                	mv	s1,a0
    80004afe:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004b00:	ffffc097          	auipc	ra,0xffffc
    80004b04:	0d6080e7          	jalr	214(ra) # 80000bd6 <acquire>
  if(writable){
    80004b08:	02090d63          	beqz	s2,80004b42 <pipeclose+0x52>
    pi->writeopen = 0;
    80004b0c:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004b10:	21848513          	addi	a0,s1,536
    80004b14:	ffffd097          	auipc	ra,0xffffd
    80004b18:	77c080e7          	jalr	1916(ra) # 80002290 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80004b1c:	2204b783          	ld	a5,544(s1)
    80004b20:	eb95                	bnez	a5,80004b54 <pipeclose+0x64>
    release(&pi->lock);
    80004b22:	8526                	mv	a0,s1
    80004b24:	ffffc097          	auipc	ra,0xffffc
    80004b28:	166080e7          	jalr	358(ra) # 80000c8a <release>
    kfree((char*)pi);
    80004b2c:	8526                	mv	a0,s1
    80004b2e:	ffffc097          	auipc	ra,0xffffc
    80004b32:	eba080e7          	jalr	-326(ra) # 800009e8 <kfree>
  } else
    release(&pi->lock);
}
    80004b36:	60e2                	ld	ra,24(sp)
    80004b38:	6442                	ld	s0,16(sp)
    80004b3a:	64a2                	ld	s1,8(sp)
    80004b3c:	6902                	ld	s2,0(sp)
    80004b3e:	6105                	addi	sp,sp,32
    80004b40:	8082                	ret
    pi->readopen = 0;
    80004b42:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004b46:	21c48513          	addi	a0,s1,540
    80004b4a:	ffffd097          	auipc	ra,0xffffd
    80004b4e:	746080e7          	jalr	1862(ra) # 80002290 <wakeup>
    80004b52:	b7e9                	j	80004b1c <pipeclose+0x2c>
    release(&pi->lock);
    80004b54:	8526                	mv	a0,s1
    80004b56:	ffffc097          	auipc	ra,0xffffc
    80004b5a:	134080e7          	jalr	308(ra) # 80000c8a <release>
}
    80004b5e:	bfe1                	j	80004b36 <pipeclose+0x46>

0000000080004b60 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004b60:	711d                	addi	sp,sp,-96
    80004b62:	ec86                	sd	ra,88(sp)
    80004b64:	e8a2                	sd	s0,80(sp)
    80004b66:	e4a6                	sd	s1,72(sp)
    80004b68:	e0ca                	sd	s2,64(sp)
    80004b6a:	fc4e                	sd	s3,56(sp)
    80004b6c:	f852                	sd	s4,48(sp)
    80004b6e:	f456                	sd	s5,40(sp)
    80004b70:	f05a                	sd	s6,32(sp)
    80004b72:	ec5e                	sd	s7,24(sp)
    80004b74:	e862                	sd	s8,16(sp)
    80004b76:	1080                	addi	s0,sp,96
    80004b78:	84aa                	mv	s1,a0
    80004b7a:	8aae                	mv	s5,a1
    80004b7c:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004b7e:	ffffd097          	auipc	ra,0xffffd
    80004b82:	f18080e7          	jalr	-232(ra) # 80001a96 <myproc>
    80004b86:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004b88:	8526                	mv	a0,s1
    80004b8a:	ffffc097          	auipc	ra,0xffffc
    80004b8e:	04c080e7          	jalr	76(ra) # 80000bd6 <acquire>
  while(i < n){
    80004b92:	0b405663          	blez	s4,80004c3e <pipewrite+0xde>
  int i = 0;
    80004b96:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004b98:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004b9a:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004b9e:	21c48b93          	addi	s7,s1,540
    80004ba2:	a089                	j	80004be4 <pipewrite+0x84>
      release(&pi->lock);
    80004ba4:	8526                	mv	a0,s1
    80004ba6:	ffffc097          	auipc	ra,0xffffc
    80004baa:	0e4080e7          	jalr	228(ra) # 80000c8a <release>
      return -1;
    80004bae:	597d                	li	s2,-1
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004bb0:	854a                	mv	a0,s2
    80004bb2:	60e6                	ld	ra,88(sp)
    80004bb4:	6446                	ld	s0,80(sp)
    80004bb6:	64a6                	ld	s1,72(sp)
    80004bb8:	6906                	ld	s2,64(sp)
    80004bba:	79e2                	ld	s3,56(sp)
    80004bbc:	7a42                	ld	s4,48(sp)
    80004bbe:	7aa2                	ld	s5,40(sp)
    80004bc0:	7b02                	ld	s6,32(sp)
    80004bc2:	6be2                	ld	s7,24(sp)
    80004bc4:	6c42                	ld	s8,16(sp)
    80004bc6:	6125                	addi	sp,sp,96
    80004bc8:	8082                	ret
      wakeup(&pi->nread);
    80004bca:	8562                	mv	a0,s8
    80004bcc:	ffffd097          	auipc	ra,0xffffd
    80004bd0:	6c4080e7          	jalr	1732(ra) # 80002290 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004bd4:	85a6                	mv	a1,s1
    80004bd6:	855e                	mv	a0,s7
    80004bd8:	ffffd097          	auipc	ra,0xffffd
    80004bdc:	654080e7          	jalr	1620(ra) # 8000222c <sleep>
  while(i < n){
    80004be0:	07495063          	bge	s2,s4,80004c40 <pipewrite+0xe0>
    if(pi->readopen == 0 || killed(pr)){
    80004be4:	2204a783          	lw	a5,544(s1)
    80004be8:	dfd5                	beqz	a5,80004ba4 <pipewrite+0x44>
    80004bea:	854e                	mv	a0,s3
    80004bec:	ffffe097          	auipc	ra,0xffffe
    80004bf0:	8e8080e7          	jalr	-1816(ra) # 800024d4 <killed>
    80004bf4:	f945                	bnez	a0,80004ba4 <pipewrite+0x44>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80004bf6:	2184a783          	lw	a5,536(s1)
    80004bfa:	21c4a703          	lw	a4,540(s1)
    80004bfe:	2007879b          	addiw	a5,a5,512
    80004c02:	fcf704e3          	beq	a4,a5,80004bca <pipewrite+0x6a>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004c06:	4685                	li	a3,1
    80004c08:	01590633          	add	a2,s2,s5
    80004c0c:	faf40593          	addi	a1,s0,-81
    80004c10:	0509b503          	ld	a0,80(s3)
    80004c14:	ffffd097          	auipc	ra,0xffffd
    80004c18:	bce080e7          	jalr	-1074(ra) # 800017e2 <copyin>
    80004c1c:	03650263          	beq	a0,s6,80004c40 <pipewrite+0xe0>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004c20:	21c4a783          	lw	a5,540(s1)
    80004c24:	0017871b          	addiw	a4,a5,1
    80004c28:	20e4ae23          	sw	a4,540(s1)
    80004c2c:	1ff7f793          	andi	a5,a5,511
    80004c30:	97a6                	add	a5,a5,s1
    80004c32:	faf44703          	lbu	a4,-81(s0)
    80004c36:	00e78c23          	sb	a4,24(a5)
      i++;
    80004c3a:	2905                	addiw	s2,s2,1
    80004c3c:	b755                	j	80004be0 <pipewrite+0x80>
  int i = 0;
    80004c3e:	4901                	li	s2,0
  wakeup(&pi->nread);
    80004c40:	21848513          	addi	a0,s1,536
    80004c44:	ffffd097          	auipc	ra,0xffffd
    80004c48:	64c080e7          	jalr	1612(ra) # 80002290 <wakeup>
  release(&pi->lock);
    80004c4c:	8526                	mv	a0,s1
    80004c4e:	ffffc097          	auipc	ra,0xffffc
    80004c52:	03c080e7          	jalr	60(ra) # 80000c8a <release>
  return i;
    80004c56:	bfa9                	j	80004bb0 <pipewrite+0x50>

0000000080004c58 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004c58:	715d                	addi	sp,sp,-80
    80004c5a:	e486                	sd	ra,72(sp)
    80004c5c:	e0a2                	sd	s0,64(sp)
    80004c5e:	fc26                	sd	s1,56(sp)
    80004c60:	f84a                	sd	s2,48(sp)
    80004c62:	f44e                	sd	s3,40(sp)
    80004c64:	f052                	sd	s4,32(sp)
    80004c66:	ec56                	sd	s5,24(sp)
    80004c68:	e85a                	sd	s6,16(sp)
    80004c6a:	0880                	addi	s0,sp,80
    80004c6c:	84aa                	mv	s1,a0
    80004c6e:	892e                	mv	s2,a1
    80004c70:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004c72:	ffffd097          	auipc	ra,0xffffd
    80004c76:	e24080e7          	jalr	-476(ra) # 80001a96 <myproc>
    80004c7a:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80004c7c:	8526                	mv	a0,s1
    80004c7e:	ffffc097          	auipc	ra,0xffffc
    80004c82:	f58080e7          	jalr	-168(ra) # 80000bd6 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004c86:	2184a703          	lw	a4,536(s1)
    80004c8a:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004c8e:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004c92:	02f71763          	bne	a4,a5,80004cc0 <piperead+0x68>
    80004c96:	2244a783          	lw	a5,548(s1)
    80004c9a:	c39d                	beqz	a5,80004cc0 <piperead+0x68>
    if(killed(pr)){
    80004c9c:	8552                	mv	a0,s4
    80004c9e:	ffffe097          	auipc	ra,0xffffe
    80004ca2:	836080e7          	jalr	-1994(ra) # 800024d4 <killed>
    80004ca6:	e949                	bnez	a0,80004d38 <piperead+0xe0>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004ca8:	85a6                	mv	a1,s1
    80004caa:	854e                	mv	a0,s3
    80004cac:	ffffd097          	auipc	ra,0xffffd
    80004cb0:	580080e7          	jalr	1408(ra) # 8000222c <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004cb4:	2184a703          	lw	a4,536(s1)
    80004cb8:	21c4a783          	lw	a5,540(s1)
    80004cbc:	fcf70de3          	beq	a4,a5,80004c96 <piperead+0x3e>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004cc0:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004cc2:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004cc4:	05505463          	blez	s5,80004d0c <piperead+0xb4>
    if(pi->nread == pi->nwrite)
    80004cc8:	2184a783          	lw	a5,536(s1)
    80004ccc:	21c4a703          	lw	a4,540(s1)
    80004cd0:	02f70e63          	beq	a4,a5,80004d0c <piperead+0xb4>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80004cd4:	0017871b          	addiw	a4,a5,1
    80004cd8:	20e4ac23          	sw	a4,536(s1)
    80004cdc:	1ff7f793          	andi	a5,a5,511
    80004ce0:	97a6                	add	a5,a5,s1
    80004ce2:	0187c783          	lbu	a5,24(a5)
    80004ce6:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004cea:	4685                	li	a3,1
    80004cec:	fbf40613          	addi	a2,s0,-65
    80004cf0:	85ca                	mv	a1,s2
    80004cf2:	050a3503          	ld	a0,80(s4)
    80004cf6:	ffffd097          	auipc	ra,0xffffd
    80004cfa:	a60080e7          	jalr	-1440(ra) # 80001756 <copyout>
    80004cfe:	01650763          	beq	a0,s6,80004d0c <piperead+0xb4>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004d02:	2985                	addiw	s3,s3,1
    80004d04:	0905                	addi	s2,s2,1
    80004d06:	fd3a91e3          	bne	s5,s3,80004cc8 <piperead+0x70>
    80004d0a:	89d6                	mv	s3,s5
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004d0c:	21c48513          	addi	a0,s1,540
    80004d10:	ffffd097          	auipc	ra,0xffffd
    80004d14:	580080e7          	jalr	1408(ra) # 80002290 <wakeup>
  release(&pi->lock);
    80004d18:	8526                	mv	a0,s1
    80004d1a:	ffffc097          	auipc	ra,0xffffc
    80004d1e:	f70080e7          	jalr	-144(ra) # 80000c8a <release>
  return i;
}
    80004d22:	854e                	mv	a0,s3
    80004d24:	60a6                	ld	ra,72(sp)
    80004d26:	6406                	ld	s0,64(sp)
    80004d28:	74e2                	ld	s1,56(sp)
    80004d2a:	7942                	ld	s2,48(sp)
    80004d2c:	79a2                	ld	s3,40(sp)
    80004d2e:	7a02                	ld	s4,32(sp)
    80004d30:	6ae2                	ld	s5,24(sp)
    80004d32:	6b42                	ld	s6,16(sp)
    80004d34:	6161                	addi	sp,sp,80
    80004d36:	8082                	ret
      release(&pi->lock);
    80004d38:	8526                	mv	a0,s1
    80004d3a:	ffffc097          	auipc	ra,0xffffc
    80004d3e:	f50080e7          	jalr	-176(ra) # 80000c8a <release>
      return -1;
    80004d42:	59fd                	li	s3,-1
    80004d44:	bff9                	j	80004d22 <piperead+0xca>

0000000080004d46 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80004d46:	1141                	addi	sp,sp,-16
    80004d48:	e422                	sd	s0,8(sp)
    80004d4a:	0800                	addi	s0,sp,16
    80004d4c:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004d4e:	8905                	andi	a0,a0,1
    80004d50:	050e                	slli	a0,a0,0x3
      perm = PTE_X;
    if(flags & 0x2)
    80004d52:	8b89                	andi	a5,a5,2
    80004d54:	c399                	beqz	a5,80004d5a <flags2perm+0x14>
      perm |= PTE_W;
    80004d56:	00456513          	ori	a0,a0,4
    return perm;
}
    80004d5a:	6422                	ld	s0,8(sp)
    80004d5c:	0141                	addi	sp,sp,16
    80004d5e:	8082                	ret

0000000080004d60 <exec>:

int
exec(char *path, char **argv)
{
    80004d60:	de010113          	addi	sp,sp,-544
    80004d64:	20113c23          	sd	ra,536(sp)
    80004d68:	20813823          	sd	s0,528(sp)
    80004d6c:	20913423          	sd	s1,520(sp)
    80004d70:	21213023          	sd	s2,512(sp)
    80004d74:	ffce                	sd	s3,504(sp)
    80004d76:	fbd2                	sd	s4,496(sp)
    80004d78:	f7d6                	sd	s5,488(sp)
    80004d7a:	f3da                	sd	s6,480(sp)
    80004d7c:	efde                	sd	s7,472(sp)
    80004d7e:	ebe2                	sd	s8,464(sp)
    80004d80:	e7e6                	sd	s9,456(sp)
    80004d82:	e3ea                	sd	s10,448(sp)
    80004d84:	ff6e                	sd	s11,440(sp)
    80004d86:	1400                	addi	s0,sp,544
    80004d88:	892a                	mv	s2,a0
    80004d8a:	dea43423          	sd	a0,-536(s0)
    80004d8e:	deb43823          	sd	a1,-528(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004d92:	ffffd097          	auipc	ra,0xffffd
    80004d96:	d04080e7          	jalr	-764(ra) # 80001a96 <myproc>
    80004d9a:	84aa                	mv	s1,a0

  begin_op();
    80004d9c:	fffff097          	auipc	ra,0xfffff
    80004da0:	482080e7          	jalr	1154(ra) # 8000421e <begin_op>

  if((ip = namei(path)) == 0){
    80004da4:	854a                	mv	a0,s2
    80004da6:	fffff097          	auipc	ra,0xfffff
    80004daa:	258080e7          	jalr	600(ra) # 80003ffe <namei>
    80004dae:	c93d                	beqz	a0,80004e24 <exec+0xc4>
    80004db0:	8aaa                	mv	s5,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004db2:	fffff097          	auipc	ra,0xfffff
    80004db6:	aa0080e7          	jalr	-1376(ra) # 80003852 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004dba:	04000713          	li	a4,64
    80004dbe:	4681                	li	a3,0
    80004dc0:	e5040613          	addi	a2,s0,-432
    80004dc4:	4581                	li	a1,0
    80004dc6:	8556                	mv	a0,s5
    80004dc8:	fffff097          	auipc	ra,0xfffff
    80004dcc:	d3e080e7          	jalr	-706(ra) # 80003b06 <readi>
    80004dd0:	04000793          	li	a5,64
    80004dd4:	00f51a63          	bne	a0,a5,80004de8 <exec+0x88>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80004dd8:	e5042703          	lw	a4,-432(s0)
    80004ddc:	464c47b7          	lui	a5,0x464c4
    80004de0:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004de4:	04f70663          	beq	a4,a5,80004e30 <exec+0xd0>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004de8:	8556                	mv	a0,s5
    80004dea:	fffff097          	auipc	ra,0xfffff
    80004dee:	cca080e7          	jalr	-822(ra) # 80003ab4 <iunlockput>
    end_op();
    80004df2:	fffff097          	auipc	ra,0xfffff
    80004df6:	4aa080e7          	jalr	1194(ra) # 8000429c <end_op>
  }
  return -1;
    80004dfa:	557d                	li	a0,-1
}
    80004dfc:	21813083          	ld	ra,536(sp)
    80004e00:	21013403          	ld	s0,528(sp)
    80004e04:	20813483          	ld	s1,520(sp)
    80004e08:	20013903          	ld	s2,512(sp)
    80004e0c:	79fe                	ld	s3,504(sp)
    80004e0e:	7a5e                	ld	s4,496(sp)
    80004e10:	7abe                	ld	s5,488(sp)
    80004e12:	7b1e                	ld	s6,480(sp)
    80004e14:	6bfe                	ld	s7,472(sp)
    80004e16:	6c5e                	ld	s8,464(sp)
    80004e18:	6cbe                	ld	s9,456(sp)
    80004e1a:	6d1e                	ld	s10,448(sp)
    80004e1c:	7dfa                	ld	s11,440(sp)
    80004e1e:	22010113          	addi	sp,sp,544
    80004e22:	8082                	ret
    end_op();
    80004e24:	fffff097          	auipc	ra,0xfffff
    80004e28:	478080e7          	jalr	1144(ra) # 8000429c <end_op>
    return -1;
    80004e2c:	557d                	li	a0,-1
    80004e2e:	b7f9                	j	80004dfc <exec+0x9c>
  if((pagetable = proc_pagetable(p)) == 0)
    80004e30:	8526                	mv	a0,s1
    80004e32:	ffffd097          	auipc	ra,0xffffd
    80004e36:	d28080e7          	jalr	-728(ra) # 80001b5a <proc_pagetable>
    80004e3a:	8b2a                	mv	s6,a0
    80004e3c:	d555                	beqz	a0,80004de8 <exec+0x88>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004e3e:	e7042783          	lw	a5,-400(s0)
    80004e42:	e8845703          	lhu	a4,-376(s0)
    80004e46:	c735                	beqz	a4,80004eb2 <exec+0x152>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004e48:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004e4a:	e0043423          	sd	zero,-504(s0)
    if(ph.vaddr % PGSIZE != 0)
    80004e4e:	6a05                	lui	s4,0x1
    80004e50:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    80004e54:	dee43023          	sd	a4,-544(s0)
loadseg(pagetable_t pagetable, uint64 va, struct inode *ip, uint offset, uint sz)
{
  uint i, n;
  uint64 pa;

  for(i = 0; i < sz; i += PGSIZE){
    80004e58:	6d85                	lui	s11,0x1
    80004e5a:	7d7d                	lui	s10,0xfffff
    80004e5c:	ac3d                	j	8000509a <exec+0x33a>
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    80004e5e:	00004517          	auipc	a0,0x4
    80004e62:	8ca50513          	addi	a0,a0,-1846 # 80008728 <syscalls+0x290>
    80004e66:	ffffb097          	auipc	ra,0xffffb
    80004e6a:	6da080e7          	jalr	1754(ra) # 80000540 <panic>
    if(sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80004e6e:	874a                	mv	a4,s2
    80004e70:	009c86bb          	addw	a3,s9,s1
    80004e74:	4581                	li	a1,0
    80004e76:	8556                	mv	a0,s5
    80004e78:	fffff097          	auipc	ra,0xfffff
    80004e7c:	c8e080e7          	jalr	-882(ra) # 80003b06 <readi>
    80004e80:	2501                	sext.w	a0,a0
    80004e82:	1aa91963          	bne	s2,a0,80005034 <exec+0x2d4>
  for(i = 0; i < sz; i += PGSIZE){
    80004e86:	009d84bb          	addw	s1,s11,s1
    80004e8a:	013d09bb          	addw	s3,s10,s3
    80004e8e:	1f74f663          	bgeu	s1,s7,8000507a <exec+0x31a>
    pa = walkaddr(pagetable, va + i);
    80004e92:	02049593          	slli	a1,s1,0x20
    80004e96:	9181                	srli	a1,a1,0x20
    80004e98:	95e2                	add	a1,a1,s8
    80004e9a:	855a                	mv	a0,s6
    80004e9c:	ffffc097          	auipc	ra,0xffffc
    80004ea0:	2aa080e7          	jalr	682(ra) # 80001146 <walkaddr>
    80004ea4:	862a                	mv	a2,a0
    if(pa == 0)
    80004ea6:	dd45                	beqz	a0,80004e5e <exec+0xfe>
      n = PGSIZE;
    80004ea8:	8952                	mv	s2,s4
    if(sz - i < PGSIZE)
    80004eaa:	fd49f2e3          	bgeu	s3,s4,80004e6e <exec+0x10e>
      n = sz - i;
    80004eae:	894e                	mv	s2,s3
    80004eb0:	bf7d                	j	80004e6e <exec+0x10e>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004eb2:	4901                	li	s2,0
  iunlockput(ip);
    80004eb4:	8556                	mv	a0,s5
    80004eb6:	fffff097          	auipc	ra,0xfffff
    80004eba:	bfe080e7          	jalr	-1026(ra) # 80003ab4 <iunlockput>
  end_op();
    80004ebe:	fffff097          	auipc	ra,0xfffff
    80004ec2:	3de080e7          	jalr	990(ra) # 8000429c <end_op>
  p = myproc();
    80004ec6:	ffffd097          	auipc	ra,0xffffd
    80004eca:	bd0080e7          	jalr	-1072(ra) # 80001a96 <myproc>
    80004ece:	8baa                	mv	s7,a0
  uint64 oldsz = p->sz;
    80004ed0:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80004ed4:	6785                	lui	a5,0x1
    80004ed6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80004ed8:	97ca                	add	a5,a5,s2
    80004eda:	777d                	lui	a4,0xfffff
    80004edc:	8ff9                	and	a5,a5,a4
    80004ede:	def43c23          	sd	a5,-520(s0)
  if((sz1 = uvmalloc(pagetable, sz, sz + 2*PGSIZE, PTE_W)) == 0)
    80004ee2:	4691                	li	a3,4
    80004ee4:	6609                	lui	a2,0x2
    80004ee6:	963e                	add	a2,a2,a5
    80004ee8:	85be                	mv	a1,a5
    80004eea:	855a                	mv	a0,s6
    80004eec:	ffffc097          	auipc	ra,0xffffc
    80004ef0:	60e080e7          	jalr	1550(ra) # 800014fa <uvmalloc>
    80004ef4:	8c2a                	mv	s8,a0
  ip = 0;
    80004ef6:	4a81                	li	s5,0
  if((sz1 = uvmalloc(pagetable, sz, sz + 2*PGSIZE, PTE_W)) == 0)
    80004ef8:	12050e63          	beqz	a0,80005034 <exec+0x2d4>
  uvmclear(pagetable, sz-2*PGSIZE);
    80004efc:	75f9                	lui	a1,0xffffe
    80004efe:	95aa                	add	a1,a1,a0
    80004f00:	855a                	mv	a0,s6
    80004f02:	ffffd097          	auipc	ra,0xffffd
    80004f06:	822080e7          	jalr	-2014(ra) # 80001724 <uvmclear>
  stackbase = sp - PGSIZE;
    80004f0a:	7afd                	lui	s5,0xfffff
    80004f0c:	9ae2                	add	s5,s5,s8
  for(argc = 0; argv[argc]; argc++) {
    80004f0e:	df043783          	ld	a5,-528(s0)
    80004f12:	6388                	ld	a0,0(a5)
    80004f14:	c925                	beqz	a0,80004f84 <exec+0x224>
    80004f16:	e9040993          	addi	s3,s0,-368
    80004f1a:	f9040c93          	addi	s9,s0,-112
  sp = sz;
    80004f1e:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80004f20:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004f22:	ffffc097          	auipc	ra,0xffffc
    80004f26:	f2c080e7          	jalr	-212(ra) # 80000e4e <strlen>
    80004f2a:	0015079b          	addiw	a5,a0,1
    80004f2e:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004f32:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004f36:	13596663          	bltu	s2,s5,80005062 <exec+0x302>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004f3a:	df043d83          	ld	s11,-528(s0)
    80004f3e:	000dba03          	ld	s4,0(s11) # 1000 <_entry-0x7ffff000>
    80004f42:	8552                	mv	a0,s4
    80004f44:	ffffc097          	auipc	ra,0xffffc
    80004f48:	f0a080e7          	jalr	-246(ra) # 80000e4e <strlen>
    80004f4c:	0015069b          	addiw	a3,a0,1
    80004f50:	8652                	mv	a2,s4
    80004f52:	85ca                	mv	a1,s2
    80004f54:	855a                	mv	a0,s6
    80004f56:	ffffd097          	auipc	ra,0xffffd
    80004f5a:	800080e7          	jalr	-2048(ra) # 80001756 <copyout>
    80004f5e:	10054663          	bltz	a0,8000506a <exec+0x30a>
    ustack[argc] = sp;
    80004f62:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    80004f66:	0485                	addi	s1,s1,1
    80004f68:	008d8793          	addi	a5,s11,8
    80004f6c:	def43823          	sd	a5,-528(s0)
    80004f70:	008db503          	ld	a0,8(s11)
    80004f74:	c911                	beqz	a0,80004f88 <exec+0x228>
    if(argc >= MAXARG)
    80004f76:	09a1                	addi	s3,s3,8
    80004f78:	fb3c95e3          	bne	s9,s3,80004f22 <exec+0x1c2>
  sz = sz1;
    80004f7c:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004f80:	4a81                	li	s5,0
    80004f82:	a84d                	j	80005034 <exec+0x2d4>
  sp = sz;
    80004f84:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80004f86:	4481                	li	s1,0
  ustack[argc] = 0;
    80004f88:	00349793          	slli	a5,s1,0x3
    80004f8c:	f9078793          	addi	a5,a5,-112
    80004f90:	97a2                	add	a5,a5,s0
    80004f92:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004f96:	00148693          	addi	a3,s1,1
    80004f9a:	068e                	slli	a3,a3,0x3
    80004f9c:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004fa0:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    80004fa4:	01597663          	bgeu	s2,s5,80004fb0 <exec+0x250>
  sz = sz1;
    80004fa8:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004fac:	4a81                	li	s5,0
    80004fae:	a059                	j	80005034 <exec+0x2d4>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004fb0:	e9040613          	addi	a2,s0,-368
    80004fb4:	85ca                	mv	a1,s2
    80004fb6:	855a                	mv	a0,s6
    80004fb8:	ffffc097          	auipc	ra,0xffffc
    80004fbc:	79e080e7          	jalr	1950(ra) # 80001756 <copyout>
    80004fc0:	0a054963          	bltz	a0,80005072 <exec+0x312>
  p->trapframe->a1 = sp;
    80004fc4:	058bb783          	ld	a5,88(s7)
    80004fc8:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004fcc:	de843783          	ld	a5,-536(s0)
    80004fd0:	0007c703          	lbu	a4,0(a5)
    80004fd4:	cf11                	beqz	a4,80004ff0 <exec+0x290>
    80004fd6:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004fd8:	02f00693          	li	a3,47
    80004fdc:	a039                	j	80004fea <exec+0x28a>
      last = s+1;
    80004fde:	def43423          	sd	a5,-536(s0)
  for(last=s=path; *s; s++)
    80004fe2:	0785                	addi	a5,a5,1
    80004fe4:	fff7c703          	lbu	a4,-1(a5)
    80004fe8:	c701                	beqz	a4,80004ff0 <exec+0x290>
    if(*s == '/')
    80004fea:	fed71ce3          	bne	a4,a3,80004fe2 <exec+0x282>
    80004fee:	bfc5                	j	80004fde <exec+0x27e>
  safestrcpy(p->name, last, sizeof(p->name));
    80004ff0:	4641                	li	a2,16
    80004ff2:	de843583          	ld	a1,-536(s0)
    80004ff6:	158b8513          	addi	a0,s7,344
    80004ffa:	ffffc097          	auipc	ra,0xffffc
    80004ffe:	e22080e7          	jalr	-478(ra) # 80000e1c <safestrcpy>
  oldpagetable = p->pagetable;
    80005002:	050bb503          	ld	a0,80(s7)
  p->pagetable = pagetable;
    80005006:	056bb823          	sd	s6,80(s7)
  p->sz = sz;
    8000500a:	058bb423          	sd	s8,72(s7)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    8000500e:	058bb783          	ld	a5,88(s7)
    80005012:	e6843703          	ld	a4,-408(s0)
    80005016:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80005018:	058bb783          	ld	a5,88(s7)
    8000501c:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80005020:	85ea                	mv	a1,s10
    80005022:	ffffd097          	auipc	ra,0xffffd
    80005026:	bd4080e7          	jalr	-1068(ra) # 80001bf6 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    8000502a:	0004851b          	sext.w	a0,s1
    8000502e:	b3f9                	j	80004dfc <exec+0x9c>
    80005030:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80005034:	df843583          	ld	a1,-520(s0)
    80005038:	855a                	mv	a0,s6
    8000503a:	ffffd097          	auipc	ra,0xffffd
    8000503e:	bbc080e7          	jalr	-1092(ra) # 80001bf6 <proc_freepagetable>
  if(ip){
    80005042:	da0a93e3          	bnez	s5,80004de8 <exec+0x88>
  return -1;
    80005046:	557d                	li	a0,-1
    80005048:	bb55                	j	80004dfc <exec+0x9c>
    8000504a:	df243c23          	sd	s2,-520(s0)
    8000504e:	b7dd                	j	80005034 <exec+0x2d4>
    80005050:	df243c23          	sd	s2,-520(s0)
    80005054:	b7c5                	j	80005034 <exec+0x2d4>
    80005056:	df243c23          	sd	s2,-520(s0)
    8000505a:	bfe9                	j	80005034 <exec+0x2d4>
    8000505c:	df243c23          	sd	s2,-520(s0)
    80005060:	bfd1                	j	80005034 <exec+0x2d4>
  sz = sz1;
    80005062:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80005066:	4a81                	li	s5,0
    80005068:	b7f1                	j	80005034 <exec+0x2d4>
  sz = sz1;
    8000506a:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    8000506e:	4a81                	li	s5,0
    80005070:	b7d1                	j	80005034 <exec+0x2d4>
  sz = sz1;
    80005072:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80005076:	4a81                	li	s5,0
    80005078:	bf75                	j	80005034 <exec+0x2d4>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    8000507a:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000507e:	e0843783          	ld	a5,-504(s0)
    80005082:	0017869b          	addiw	a3,a5,1
    80005086:	e0d43423          	sd	a3,-504(s0)
    8000508a:	e0043783          	ld	a5,-512(s0)
    8000508e:	0387879b          	addiw	a5,a5,56
    80005092:	e8845703          	lhu	a4,-376(s0)
    80005096:	e0e6dfe3          	bge	a3,a4,80004eb4 <exec+0x154>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    8000509a:	2781                	sext.w	a5,a5
    8000509c:	e0f43023          	sd	a5,-512(s0)
    800050a0:	03800713          	li	a4,56
    800050a4:	86be                	mv	a3,a5
    800050a6:	e1840613          	addi	a2,s0,-488
    800050aa:	4581                	li	a1,0
    800050ac:	8556                	mv	a0,s5
    800050ae:	fffff097          	auipc	ra,0xfffff
    800050b2:	a58080e7          	jalr	-1448(ra) # 80003b06 <readi>
    800050b6:	03800793          	li	a5,56
    800050ba:	f6f51be3          	bne	a0,a5,80005030 <exec+0x2d0>
    if(ph.type != ELF_PROG_LOAD)
    800050be:	e1842783          	lw	a5,-488(s0)
    800050c2:	4705                	li	a4,1
    800050c4:	fae79de3          	bne	a5,a4,8000507e <exec+0x31e>
    if(ph.memsz < ph.filesz)
    800050c8:	e4043483          	ld	s1,-448(s0)
    800050cc:	e3843783          	ld	a5,-456(s0)
    800050d0:	f6f4ede3          	bltu	s1,a5,8000504a <exec+0x2ea>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    800050d4:	e2843783          	ld	a5,-472(s0)
    800050d8:	94be                	add	s1,s1,a5
    800050da:	f6f4ebe3          	bltu	s1,a5,80005050 <exec+0x2f0>
    if(ph.vaddr % PGSIZE != 0)
    800050de:	de043703          	ld	a4,-544(s0)
    800050e2:	8ff9                	and	a5,a5,a4
    800050e4:	fbad                	bnez	a5,80005056 <exec+0x2f6>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    800050e6:	e1c42503          	lw	a0,-484(s0)
    800050ea:	00000097          	auipc	ra,0x0
    800050ee:	c5c080e7          	jalr	-932(ra) # 80004d46 <flags2perm>
    800050f2:	86aa                	mv	a3,a0
    800050f4:	8626                	mv	a2,s1
    800050f6:	85ca                	mv	a1,s2
    800050f8:	855a                	mv	a0,s6
    800050fa:	ffffc097          	auipc	ra,0xffffc
    800050fe:	400080e7          	jalr	1024(ra) # 800014fa <uvmalloc>
    80005102:	dea43c23          	sd	a0,-520(s0)
    80005106:	d939                	beqz	a0,8000505c <exec+0x2fc>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80005108:	e2843c03          	ld	s8,-472(s0)
    8000510c:	e2042c83          	lw	s9,-480(s0)
    80005110:	e3842b83          	lw	s7,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80005114:	f60b83e3          	beqz	s7,8000507a <exec+0x31a>
    80005118:	89de                	mv	s3,s7
    8000511a:	4481                	li	s1,0
    8000511c:	bb9d                	j	80004e92 <exec+0x132>

000000008000511e <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    8000511e:	7179                	addi	sp,sp,-48
    80005120:	f406                	sd	ra,40(sp)
    80005122:	f022                	sd	s0,32(sp)
    80005124:	ec26                	sd	s1,24(sp)
    80005126:	e84a                	sd	s2,16(sp)
    80005128:	1800                	addi	s0,sp,48
    8000512a:	892e                	mv	s2,a1
    8000512c:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    8000512e:	fdc40593          	addi	a1,s0,-36
    80005132:	ffffe097          	auipc	ra,0xffffe
    80005136:	b68080e7          	jalr	-1176(ra) # 80002c9a <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    8000513a:	fdc42703          	lw	a4,-36(s0)
    8000513e:	47bd                	li	a5,15
    80005140:	02e7eb63          	bltu	a5,a4,80005176 <argfd+0x58>
    80005144:	ffffd097          	auipc	ra,0xffffd
    80005148:	952080e7          	jalr	-1710(ra) # 80001a96 <myproc>
    8000514c:	fdc42703          	lw	a4,-36(s0)
    80005150:	01a70793          	addi	a5,a4,26 # fffffffffffff01a <end+0xffffffff7ffdcdba>
    80005154:	078e                	slli	a5,a5,0x3
    80005156:	953e                	add	a0,a0,a5
    80005158:	611c                	ld	a5,0(a0)
    8000515a:	c385                	beqz	a5,8000517a <argfd+0x5c>
    return -1;
  if(pfd)
    8000515c:	00090463          	beqz	s2,80005164 <argfd+0x46>
    *pfd = fd;
    80005160:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80005164:	4501                	li	a0,0
  if(pf)
    80005166:	c091                	beqz	s1,8000516a <argfd+0x4c>
    *pf = f;
    80005168:	e09c                	sd	a5,0(s1)
}
    8000516a:	70a2                	ld	ra,40(sp)
    8000516c:	7402                	ld	s0,32(sp)
    8000516e:	64e2                	ld	s1,24(sp)
    80005170:	6942                	ld	s2,16(sp)
    80005172:	6145                	addi	sp,sp,48
    80005174:	8082                	ret
    return -1;
    80005176:	557d                	li	a0,-1
    80005178:	bfcd                	j	8000516a <argfd+0x4c>
    8000517a:	557d                	li	a0,-1
    8000517c:	b7fd                	j	8000516a <argfd+0x4c>

000000008000517e <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    8000517e:	1101                	addi	sp,sp,-32
    80005180:	ec06                	sd	ra,24(sp)
    80005182:	e822                	sd	s0,16(sp)
    80005184:	e426                	sd	s1,8(sp)
    80005186:	1000                	addi	s0,sp,32
    80005188:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    8000518a:	ffffd097          	auipc	ra,0xffffd
    8000518e:	90c080e7          	jalr	-1780(ra) # 80001a96 <myproc>
    80005192:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80005194:	0d050793          	addi	a5,a0,208
    80005198:	4501                	li	a0,0
    8000519a:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    8000519c:	6398                	ld	a4,0(a5)
    8000519e:	cb19                	beqz	a4,800051b4 <fdalloc+0x36>
  for(fd = 0; fd < NOFILE; fd++){
    800051a0:	2505                	addiw	a0,a0,1
    800051a2:	07a1                	addi	a5,a5,8
    800051a4:	fed51ce3          	bne	a0,a3,8000519c <fdalloc+0x1e>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    800051a8:	557d                	li	a0,-1
}
    800051aa:	60e2                	ld	ra,24(sp)
    800051ac:	6442                	ld	s0,16(sp)
    800051ae:	64a2                	ld	s1,8(sp)
    800051b0:	6105                	addi	sp,sp,32
    800051b2:	8082                	ret
      p->ofile[fd] = f;
    800051b4:	01a50793          	addi	a5,a0,26
    800051b8:	078e                	slli	a5,a5,0x3
    800051ba:	963e                	add	a2,a2,a5
    800051bc:	e204                	sd	s1,0(a2)
      return fd;
    800051be:	b7f5                	j	800051aa <fdalloc+0x2c>

00000000800051c0 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    800051c0:	715d                	addi	sp,sp,-80
    800051c2:	e486                	sd	ra,72(sp)
    800051c4:	e0a2                	sd	s0,64(sp)
    800051c6:	fc26                	sd	s1,56(sp)
    800051c8:	f84a                	sd	s2,48(sp)
    800051ca:	f44e                	sd	s3,40(sp)
    800051cc:	f052                	sd	s4,32(sp)
    800051ce:	ec56                	sd	s5,24(sp)
    800051d0:	e85a                	sd	s6,16(sp)
    800051d2:	0880                	addi	s0,sp,80
    800051d4:	8b2e                	mv	s6,a1
    800051d6:	89b2                	mv	s3,a2
    800051d8:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    800051da:	fb040593          	addi	a1,s0,-80
    800051de:	fffff097          	auipc	ra,0xfffff
    800051e2:	e3e080e7          	jalr	-450(ra) # 8000401c <nameiparent>
    800051e6:	84aa                	mv	s1,a0
    800051e8:	14050f63          	beqz	a0,80005346 <create+0x186>
    return 0;

  ilock(dp);
    800051ec:	ffffe097          	auipc	ra,0xffffe
    800051f0:	666080e7          	jalr	1638(ra) # 80003852 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    800051f4:	4601                	li	a2,0
    800051f6:	fb040593          	addi	a1,s0,-80
    800051fa:	8526                	mv	a0,s1
    800051fc:	fffff097          	auipc	ra,0xfffff
    80005200:	b3a080e7          	jalr	-1222(ra) # 80003d36 <dirlookup>
    80005204:	8aaa                	mv	s5,a0
    80005206:	c931                	beqz	a0,8000525a <create+0x9a>
    iunlockput(dp);
    80005208:	8526                	mv	a0,s1
    8000520a:	fffff097          	auipc	ra,0xfffff
    8000520e:	8aa080e7          	jalr	-1878(ra) # 80003ab4 <iunlockput>
    ilock(ip);
    80005212:	8556                	mv	a0,s5
    80005214:	ffffe097          	auipc	ra,0xffffe
    80005218:	63e080e7          	jalr	1598(ra) # 80003852 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    8000521c:	000b059b          	sext.w	a1,s6
    80005220:	4789                	li	a5,2
    80005222:	02f59563          	bne	a1,a5,8000524c <create+0x8c>
    80005226:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <end+0xffffffff7ffdcde4>
    8000522a:	37f9                	addiw	a5,a5,-2
    8000522c:	17c2                	slli	a5,a5,0x30
    8000522e:	93c1                	srli	a5,a5,0x30
    80005230:	4705                	li	a4,1
    80005232:	00f76d63          	bltu	a4,a5,8000524c <create+0x8c>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80005236:	8556                	mv	a0,s5
    80005238:	60a6                	ld	ra,72(sp)
    8000523a:	6406                	ld	s0,64(sp)
    8000523c:	74e2                	ld	s1,56(sp)
    8000523e:	7942                	ld	s2,48(sp)
    80005240:	79a2                	ld	s3,40(sp)
    80005242:	7a02                	ld	s4,32(sp)
    80005244:	6ae2                	ld	s5,24(sp)
    80005246:	6b42                	ld	s6,16(sp)
    80005248:	6161                	addi	sp,sp,80
    8000524a:	8082                	ret
    iunlockput(ip);
    8000524c:	8556                	mv	a0,s5
    8000524e:	fffff097          	auipc	ra,0xfffff
    80005252:	866080e7          	jalr	-1946(ra) # 80003ab4 <iunlockput>
    return 0;
    80005256:	4a81                	li	s5,0
    80005258:	bff9                	j	80005236 <create+0x76>
  if((ip = ialloc(dp->dev, type)) == 0){
    8000525a:	85da                	mv	a1,s6
    8000525c:	4088                	lw	a0,0(s1)
    8000525e:	ffffe097          	auipc	ra,0xffffe
    80005262:	456080e7          	jalr	1110(ra) # 800036b4 <ialloc>
    80005266:	8a2a                	mv	s4,a0
    80005268:	c539                	beqz	a0,800052b6 <create+0xf6>
  ilock(ip);
    8000526a:	ffffe097          	auipc	ra,0xffffe
    8000526e:	5e8080e7          	jalr	1512(ra) # 80003852 <ilock>
  ip->major = major;
    80005272:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80005276:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    8000527a:	4905                	li	s2,1
    8000527c:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80005280:	8552                	mv	a0,s4
    80005282:	ffffe097          	auipc	ra,0xffffe
    80005286:	504080e7          	jalr	1284(ra) # 80003786 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    8000528a:	000b059b          	sext.w	a1,s6
    8000528e:	03258b63          	beq	a1,s2,800052c4 <create+0x104>
  if(dirlink(dp, name, ip->inum) < 0)
    80005292:	004a2603          	lw	a2,4(s4)
    80005296:	fb040593          	addi	a1,s0,-80
    8000529a:	8526                	mv	a0,s1
    8000529c:	fffff097          	auipc	ra,0xfffff
    800052a0:	cb0080e7          	jalr	-848(ra) # 80003f4c <dirlink>
    800052a4:	06054f63          	bltz	a0,80005322 <create+0x162>
  iunlockput(dp);
    800052a8:	8526                	mv	a0,s1
    800052aa:	fffff097          	auipc	ra,0xfffff
    800052ae:	80a080e7          	jalr	-2038(ra) # 80003ab4 <iunlockput>
  return ip;
    800052b2:	8ad2                	mv	s5,s4
    800052b4:	b749                	j	80005236 <create+0x76>
    iunlockput(dp);
    800052b6:	8526                	mv	a0,s1
    800052b8:	ffffe097          	auipc	ra,0xffffe
    800052bc:	7fc080e7          	jalr	2044(ra) # 80003ab4 <iunlockput>
    return 0;
    800052c0:	8ad2                	mv	s5,s4
    800052c2:	bf95                	j	80005236 <create+0x76>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    800052c4:	004a2603          	lw	a2,4(s4)
    800052c8:	00003597          	auipc	a1,0x3
    800052cc:	48058593          	addi	a1,a1,1152 # 80008748 <syscalls+0x2b0>
    800052d0:	8552                	mv	a0,s4
    800052d2:	fffff097          	auipc	ra,0xfffff
    800052d6:	c7a080e7          	jalr	-902(ra) # 80003f4c <dirlink>
    800052da:	04054463          	bltz	a0,80005322 <create+0x162>
    800052de:	40d0                	lw	a2,4(s1)
    800052e0:	00003597          	auipc	a1,0x3
    800052e4:	47058593          	addi	a1,a1,1136 # 80008750 <syscalls+0x2b8>
    800052e8:	8552                	mv	a0,s4
    800052ea:	fffff097          	auipc	ra,0xfffff
    800052ee:	c62080e7          	jalr	-926(ra) # 80003f4c <dirlink>
    800052f2:	02054863          	bltz	a0,80005322 <create+0x162>
  if(dirlink(dp, name, ip->inum) < 0)
    800052f6:	004a2603          	lw	a2,4(s4)
    800052fa:	fb040593          	addi	a1,s0,-80
    800052fe:	8526                	mv	a0,s1
    80005300:	fffff097          	auipc	ra,0xfffff
    80005304:	c4c080e7          	jalr	-948(ra) # 80003f4c <dirlink>
    80005308:	00054d63          	bltz	a0,80005322 <create+0x162>
    dp->nlink++;  // for ".."
    8000530c:	04a4d783          	lhu	a5,74(s1)
    80005310:	2785                	addiw	a5,a5,1
    80005312:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80005316:	8526                	mv	a0,s1
    80005318:	ffffe097          	auipc	ra,0xffffe
    8000531c:	46e080e7          	jalr	1134(ra) # 80003786 <iupdate>
    80005320:	b761                	j	800052a8 <create+0xe8>
  ip->nlink = 0;
    80005322:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80005326:	8552                	mv	a0,s4
    80005328:	ffffe097          	auipc	ra,0xffffe
    8000532c:	45e080e7          	jalr	1118(ra) # 80003786 <iupdate>
  iunlockput(ip);
    80005330:	8552                	mv	a0,s4
    80005332:	ffffe097          	auipc	ra,0xffffe
    80005336:	782080e7          	jalr	1922(ra) # 80003ab4 <iunlockput>
  iunlockput(dp);
    8000533a:	8526                	mv	a0,s1
    8000533c:	ffffe097          	auipc	ra,0xffffe
    80005340:	778080e7          	jalr	1912(ra) # 80003ab4 <iunlockput>
  return 0;
    80005344:	bdcd                	j	80005236 <create+0x76>
    return 0;
    80005346:	8aaa                	mv	s5,a0
    80005348:	b5fd                	j	80005236 <create+0x76>

000000008000534a <sys_dup>:
{
    8000534a:	7179                	addi	sp,sp,-48
    8000534c:	f406                	sd	ra,40(sp)
    8000534e:	f022                	sd	s0,32(sp)
    80005350:	ec26                	sd	s1,24(sp)
    80005352:	e84a                	sd	s2,16(sp)
    80005354:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80005356:	fd840613          	addi	a2,s0,-40
    8000535a:	4581                	li	a1,0
    8000535c:	4501                	li	a0,0
    8000535e:	00000097          	auipc	ra,0x0
    80005362:	dc0080e7          	jalr	-576(ra) # 8000511e <argfd>
    return -1;
    80005366:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80005368:	02054363          	bltz	a0,8000538e <sys_dup+0x44>
  if((fd=fdalloc(f)) < 0)
    8000536c:	fd843903          	ld	s2,-40(s0)
    80005370:	854a                	mv	a0,s2
    80005372:	00000097          	auipc	ra,0x0
    80005376:	e0c080e7          	jalr	-500(ra) # 8000517e <fdalloc>
    8000537a:	84aa                	mv	s1,a0
    return -1;
    8000537c:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    8000537e:	00054863          	bltz	a0,8000538e <sys_dup+0x44>
  filedup(f);
    80005382:	854a                	mv	a0,s2
    80005384:	fffff097          	auipc	ra,0xfffff
    80005388:	310080e7          	jalr	784(ra) # 80004694 <filedup>
  return fd;
    8000538c:	87a6                	mv	a5,s1
}
    8000538e:	853e                	mv	a0,a5
    80005390:	70a2                	ld	ra,40(sp)
    80005392:	7402                	ld	s0,32(sp)
    80005394:	64e2                	ld	s1,24(sp)
    80005396:	6942                	ld	s2,16(sp)
    80005398:	6145                	addi	sp,sp,48
    8000539a:	8082                	ret

000000008000539c <sys_read>:
{
    8000539c:	7179                	addi	sp,sp,-48
    8000539e:	f406                	sd	ra,40(sp)
    800053a0:	f022                	sd	s0,32(sp)
    800053a2:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800053a4:	fd840593          	addi	a1,s0,-40
    800053a8:	4505                	li	a0,1
    800053aa:	ffffe097          	auipc	ra,0xffffe
    800053ae:	910080e7          	jalr	-1776(ra) # 80002cba <argaddr>
  argint(2, &n);
    800053b2:	fe440593          	addi	a1,s0,-28
    800053b6:	4509                	li	a0,2
    800053b8:	ffffe097          	auipc	ra,0xffffe
    800053bc:	8e2080e7          	jalr	-1822(ra) # 80002c9a <argint>
  if(argfd(0, 0, &f) < 0)
    800053c0:	fe840613          	addi	a2,s0,-24
    800053c4:	4581                	li	a1,0
    800053c6:	4501                	li	a0,0
    800053c8:	00000097          	auipc	ra,0x0
    800053cc:	d56080e7          	jalr	-682(ra) # 8000511e <argfd>
    800053d0:	87aa                	mv	a5,a0
    return -1;
    800053d2:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800053d4:	0007cc63          	bltz	a5,800053ec <sys_read+0x50>
  return fileread(f, p, n);
    800053d8:	fe442603          	lw	a2,-28(s0)
    800053dc:	fd843583          	ld	a1,-40(s0)
    800053e0:	fe843503          	ld	a0,-24(s0)
    800053e4:	fffff097          	auipc	ra,0xfffff
    800053e8:	43c080e7          	jalr	1084(ra) # 80004820 <fileread>
}
    800053ec:	70a2                	ld	ra,40(sp)
    800053ee:	7402                	ld	s0,32(sp)
    800053f0:	6145                	addi	sp,sp,48
    800053f2:	8082                	ret

00000000800053f4 <sys_write>:
{
    800053f4:	7179                	addi	sp,sp,-48
    800053f6:	f406                	sd	ra,40(sp)
    800053f8:	f022                	sd	s0,32(sp)
    800053fa:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800053fc:	fd840593          	addi	a1,s0,-40
    80005400:	4505                	li	a0,1
    80005402:	ffffe097          	auipc	ra,0xffffe
    80005406:	8b8080e7          	jalr	-1864(ra) # 80002cba <argaddr>
  argint(2, &n);
    8000540a:	fe440593          	addi	a1,s0,-28
    8000540e:	4509                	li	a0,2
    80005410:	ffffe097          	auipc	ra,0xffffe
    80005414:	88a080e7          	jalr	-1910(ra) # 80002c9a <argint>
  if(argfd(0, 0, &f) < 0)
    80005418:	fe840613          	addi	a2,s0,-24
    8000541c:	4581                	li	a1,0
    8000541e:	4501                	li	a0,0
    80005420:	00000097          	auipc	ra,0x0
    80005424:	cfe080e7          	jalr	-770(ra) # 8000511e <argfd>
    80005428:	87aa                	mv	a5,a0
    return -1;
    8000542a:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000542c:	0007cc63          	bltz	a5,80005444 <sys_write+0x50>
  return filewrite(f, p, n);
    80005430:	fe442603          	lw	a2,-28(s0)
    80005434:	fd843583          	ld	a1,-40(s0)
    80005438:	fe843503          	ld	a0,-24(s0)
    8000543c:	fffff097          	auipc	ra,0xfffff
    80005440:	4a6080e7          	jalr	1190(ra) # 800048e2 <filewrite>
}
    80005444:	70a2                	ld	ra,40(sp)
    80005446:	7402                	ld	s0,32(sp)
    80005448:	6145                	addi	sp,sp,48
    8000544a:	8082                	ret

000000008000544c <sys_close>:
{
    8000544c:	1101                	addi	sp,sp,-32
    8000544e:	ec06                	sd	ra,24(sp)
    80005450:	e822                	sd	s0,16(sp)
    80005452:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80005454:	fe040613          	addi	a2,s0,-32
    80005458:	fec40593          	addi	a1,s0,-20
    8000545c:	4501                	li	a0,0
    8000545e:	00000097          	auipc	ra,0x0
    80005462:	cc0080e7          	jalr	-832(ra) # 8000511e <argfd>
    return -1;
    80005466:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80005468:	02054463          	bltz	a0,80005490 <sys_close+0x44>
  myproc()->ofile[fd] = 0;
    8000546c:	ffffc097          	auipc	ra,0xffffc
    80005470:	62a080e7          	jalr	1578(ra) # 80001a96 <myproc>
    80005474:	fec42783          	lw	a5,-20(s0)
    80005478:	07e9                	addi	a5,a5,26
    8000547a:	078e                	slli	a5,a5,0x3
    8000547c:	953e                	add	a0,a0,a5
    8000547e:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80005482:	fe043503          	ld	a0,-32(s0)
    80005486:	fffff097          	auipc	ra,0xfffff
    8000548a:	260080e7          	jalr	608(ra) # 800046e6 <fileclose>
  return 0;
    8000548e:	4781                	li	a5,0
}
    80005490:	853e                	mv	a0,a5
    80005492:	60e2                	ld	ra,24(sp)
    80005494:	6442                	ld	s0,16(sp)
    80005496:	6105                	addi	sp,sp,32
    80005498:	8082                	ret

000000008000549a <sys_fstat>:
{
    8000549a:	1101                	addi	sp,sp,-32
    8000549c:	ec06                	sd	ra,24(sp)
    8000549e:	e822                	sd	s0,16(sp)
    800054a0:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    800054a2:	fe040593          	addi	a1,s0,-32
    800054a6:	4505                	li	a0,1
    800054a8:	ffffe097          	auipc	ra,0xffffe
    800054ac:	812080e7          	jalr	-2030(ra) # 80002cba <argaddr>
  if(argfd(0, 0, &f) < 0)
    800054b0:	fe840613          	addi	a2,s0,-24
    800054b4:	4581                	li	a1,0
    800054b6:	4501                	li	a0,0
    800054b8:	00000097          	auipc	ra,0x0
    800054bc:	c66080e7          	jalr	-922(ra) # 8000511e <argfd>
    800054c0:	87aa                	mv	a5,a0
    return -1;
    800054c2:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800054c4:	0007ca63          	bltz	a5,800054d8 <sys_fstat+0x3e>
  return filestat(f, st);
    800054c8:	fe043583          	ld	a1,-32(s0)
    800054cc:	fe843503          	ld	a0,-24(s0)
    800054d0:	fffff097          	auipc	ra,0xfffff
    800054d4:	2de080e7          	jalr	734(ra) # 800047ae <filestat>
}
    800054d8:	60e2                	ld	ra,24(sp)
    800054da:	6442                	ld	s0,16(sp)
    800054dc:	6105                	addi	sp,sp,32
    800054de:	8082                	ret

00000000800054e0 <sys_link>:
{
    800054e0:	7169                	addi	sp,sp,-304
    800054e2:	f606                	sd	ra,296(sp)
    800054e4:	f222                	sd	s0,288(sp)
    800054e6:	ee26                	sd	s1,280(sp)
    800054e8:	ea4a                	sd	s2,272(sp)
    800054ea:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800054ec:	08000613          	li	a2,128
    800054f0:	ed040593          	addi	a1,s0,-304
    800054f4:	4501                	li	a0,0
    800054f6:	ffffd097          	auipc	ra,0xffffd
    800054fa:	7e4080e7          	jalr	2020(ra) # 80002cda <argstr>
    return -1;
    800054fe:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005500:	10054e63          	bltz	a0,8000561c <sys_link+0x13c>
    80005504:	08000613          	li	a2,128
    80005508:	f5040593          	addi	a1,s0,-176
    8000550c:	4505                	li	a0,1
    8000550e:	ffffd097          	auipc	ra,0xffffd
    80005512:	7cc080e7          	jalr	1996(ra) # 80002cda <argstr>
    return -1;
    80005516:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005518:	10054263          	bltz	a0,8000561c <sys_link+0x13c>
  begin_op();
    8000551c:	fffff097          	auipc	ra,0xfffff
    80005520:	d02080e7          	jalr	-766(ra) # 8000421e <begin_op>
  if((ip = namei(old)) == 0){
    80005524:	ed040513          	addi	a0,s0,-304
    80005528:	fffff097          	auipc	ra,0xfffff
    8000552c:	ad6080e7          	jalr	-1322(ra) # 80003ffe <namei>
    80005530:	84aa                	mv	s1,a0
    80005532:	c551                	beqz	a0,800055be <sys_link+0xde>
  ilock(ip);
    80005534:	ffffe097          	auipc	ra,0xffffe
    80005538:	31e080e7          	jalr	798(ra) # 80003852 <ilock>
  if(ip->type == T_DIR){
    8000553c:	04449703          	lh	a4,68(s1)
    80005540:	4785                	li	a5,1
    80005542:	08f70463          	beq	a4,a5,800055ca <sys_link+0xea>
  ip->nlink++;
    80005546:	04a4d783          	lhu	a5,74(s1)
    8000554a:	2785                	addiw	a5,a5,1
    8000554c:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005550:	8526                	mv	a0,s1
    80005552:	ffffe097          	auipc	ra,0xffffe
    80005556:	234080e7          	jalr	564(ra) # 80003786 <iupdate>
  iunlock(ip);
    8000555a:	8526                	mv	a0,s1
    8000555c:	ffffe097          	auipc	ra,0xffffe
    80005560:	3b8080e7          	jalr	952(ra) # 80003914 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80005564:	fd040593          	addi	a1,s0,-48
    80005568:	f5040513          	addi	a0,s0,-176
    8000556c:	fffff097          	auipc	ra,0xfffff
    80005570:	ab0080e7          	jalr	-1360(ra) # 8000401c <nameiparent>
    80005574:	892a                	mv	s2,a0
    80005576:	c935                	beqz	a0,800055ea <sys_link+0x10a>
  ilock(dp);
    80005578:	ffffe097          	auipc	ra,0xffffe
    8000557c:	2da080e7          	jalr	730(ra) # 80003852 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80005580:	00092703          	lw	a4,0(s2)
    80005584:	409c                	lw	a5,0(s1)
    80005586:	04f71d63          	bne	a4,a5,800055e0 <sys_link+0x100>
    8000558a:	40d0                	lw	a2,4(s1)
    8000558c:	fd040593          	addi	a1,s0,-48
    80005590:	854a                	mv	a0,s2
    80005592:	fffff097          	auipc	ra,0xfffff
    80005596:	9ba080e7          	jalr	-1606(ra) # 80003f4c <dirlink>
    8000559a:	04054363          	bltz	a0,800055e0 <sys_link+0x100>
  iunlockput(dp);
    8000559e:	854a                	mv	a0,s2
    800055a0:	ffffe097          	auipc	ra,0xffffe
    800055a4:	514080e7          	jalr	1300(ra) # 80003ab4 <iunlockput>
  iput(ip);
    800055a8:	8526                	mv	a0,s1
    800055aa:	ffffe097          	auipc	ra,0xffffe
    800055ae:	462080e7          	jalr	1122(ra) # 80003a0c <iput>
  end_op();
    800055b2:	fffff097          	auipc	ra,0xfffff
    800055b6:	cea080e7          	jalr	-790(ra) # 8000429c <end_op>
  return 0;
    800055ba:	4781                	li	a5,0
    800055bc:	a085                	j	8000561c <sys_link+0x13c>
    end_op();
    800055be:	fffff097          	auipc	ra,0xfffff
    800055c2:	cde080e7          	jalr	-802(ra) # 8000429c <end_op>
    return -1;
    800055c6:	57fd                	li	a5,-1
    800055c8:	a891                	j	8000561c <sys_link+0x13c>
    iunlockput(ip);
    800055ca:	8526                	mv	a0,s1
    800055cc:	ffffe097          	auipc	ra,0xffffe
    800055d0:	4e8080e7          	jalr	1256(ra) # 80003ab4 <iunlockput>
    end_op();
    800055d4:	fffff097          	auipc	ra,0xfffff
    800055d8:	cc8080e7          	jalr	-824(ra) # 8000429c <end_op>
    return -1;
    800055dc:	57fd                	li	a5,-1
    800055de:	a83d                	j	8000561c <sys_link+0x13c>
    iunlockput(dp);
    800055e0:	854a                	mv	a0,s2
    800055e2:	ffffe097          	auipc	ra,0xffffe
    800055e6:	4d2080e7          	jalr	1234(ra) # 80003ab4 <iunlockput>
  ilock(ip);
    800055ea:	8526                	mv	a0,s1
    800055ec:	ffffe097          	auipc	ra,0xffffe
    800055f0:	266080e7          	jalr	614(ra) # 80003852 <ilock>
  ip->nlink--;
    800055f4:	04a4d783          	lhu	a5,74(s1)
    800055f8:	37fd                	addiw	a5,a5,-1
    800055fa:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800055fe:	8526                	mv	a0,s1
    80005600:	ffffe097          	auipc	ra,0xffffe
    80005604:	186080e7          	jalr	390(ra) # 80003786 <iupdate>
  iunlockput(ip);
    80005608:	8526                	mv	a0,s1
    8000560a:	ffffe097          	auipc	ra,0xffffe
    8000560e:	4aa080e7          	jalr	1194(ra) # 80003ab4 <iunlockput>
  end_op();
    80005612:	fffff097          	auipc	ra,0xfffff
    80005616:	c8a080e7          	jalr	-886(ra) # 8000429c <end_op>
  return -1;
    8000561a:	57fd                	li	a5,-1
}
    8000561c:	853e                	mv	a0,a5
    8000561e:	70b2                	ld	ra,296(sp)
    80005620:	7412                	ld	s0,288(sp)
    80005622:	64f2                	ld	s1,280(sp)
    80005624:	6952                	ld	s2,272(sp)
    80005626:	6155                	addi	sp,sp,304
    80005628:	8082                	ret

000000008000562a <sys_unlink>:
{
    8000562a:	7151                	addi	sp,sp,-240
    8000562c:	f586                	sd	ra,232(sp)
    8000562e:	f1a2                	sd	s0,224(sp)
    80005630:	eda6                	sd	s1,216(sp)
    80005632:	e9ca                	sd	s2,208(sp)
    80005634:	e5ce                	sd	s3,200(sp)
    80005636:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80005638:	08000613          	li	a2,128
    8000563c:	f3040593          	addi	a1,s0,-208
    80005640:	4501                	li	a0,0
    80005642:	ffffd097          	auipc	ra,0xffffd
    80005646:	698080e7          	jalr	1688(ra) # 80002cda <argstr>
    8000564a:	18054163          	bltz	a0,800057cc <sys_unlink+0x1a2>
  begin_op();
    8000564e:	fffff097          	auipc	ra,0xfffff
    80005652:	bd0080e7          	jalr	-1072(ra) # 8000421e <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80005656:	fb040593          	addi	a1,s0,-80
    8000565a:	f3040513          	addi	a0,s0,-208
    8000565e:	fffff097          	auipc	ra,0xfffff
    80005662:	9be080e7          	jalr	-1602(ra) # 8000401c <nameiparent>
    80005666:	84aa                	mv	s1,a0
    80005668:	c979                	beqz	a0,8000573e <sys_unlink+0x114>
  ilock(dp);
    8000566a:	ffffe097          	auipc	ra,0xffffe
    8000566e:	1e8080e7          	jalr	488(ra) # 80003852 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80005672:	00003597          	auipc	a1,0x3
    80005676:	0d658593          	addi	a1,a1,214 # 80008748 <syscalls+0x2b0>
    8000567a:	fb040513          	addi	a0,s0,-80
    8000567e:	ffffe097          	auipc	ra,0xffffe
    80005682:	69e080e7          	jalr	1694(ra) # 80003d1c <namecmp>
    80005686:	14050a63          	beqz	a0,800057da <sys_unlink+0x1b0>
    8000568a:	00003597          	auipc	a1,0x3
    8000568e:	0c658593          	addi	a1,a1,198 # 80008750 <syscalls+0x2b8>
    80005692:	fb040513          	addi	a0,s0,-80
    80005696:	ffffe097          	auipc	ra,0xffffe
    8000569a:	686080e7          	jalr	1670(ra) # 80003d1c <namecmp>
    8000569e:	12050e63          	beqz	a0,800057da <sys_unlink+0x1b0>
  if((ip = dirlookup(dp, name, &off)) == 0)
    800056a2:	f2c40613          	addi	a2,s0,-212
    800056a6:	fb040593          	addi	a1,s0,-80
    800056aa:	8526                	mv	a0,s1
    800056ac:	ffffe097          	auipc	ra,0xffffe
    800056b0:	68a080e7          	jalr	1674(ra) # 80003d36 <dirlookup>
    800056b4:	892a                	mv	s2,a0
    800056b6:	12050263          	beqz	a0,800057da <sys_unlink+0x1b0>
  ilock(ip);
    800056ba:	ffffe097          	auipc	ra,0xffffe
    800056be:	198080e7          	jalr	408(ra) # 80003852 <ilock>
  if(ip->nlink < 1)
    800056c2:	04a91783          	lh	a5,74(s2)
    800056c6:	08f05263          	blez	a5,8000574a <sys_unlink+0x120>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800056ca:	04491703          	lh	a4,68(s2)
    800056ce:	4785                	li	a5,1
    800056d0:	08f70563          	beq	a4,a5,8000575a <sys_unlink+0x130>
  memset(&de, 0, sizeof(de));
    800056d4:	4641                	li	a2,16
    800056d6:	4581                	li	a1,0
    800056d8:	fc040513          	addi	a0,s0,-64
    800056dc:	ffffb097          	auipc	ra,0xffffb
    800056e0:	5f6080e7          	jalr	1526(ra) # 80000cd2 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800056e4:	4741                	li	a4,16
    800056e6:	f2c42683          	lw	a3,-212(s0)
    800056ea:	fc040613          	addi	a2,s0,-64
    800056ee:	4581                	li	a1,0
    800056f0:	8526                	mv	a0,s1
    800056f2:	ffffe097          	auipc	ra,0xffffe
    800056f6:	50c080e7          	jalr	1292(ra) # 80003bfe <writei>
    800056fa:	47c1                	li	a5,16
    800056fc:	0af51563          	bne	a0,a5,800057a6 <sys_unlink+0x17c>
  if(ip->type == T_DIR){
    80005700:	04491703          	lh	a4,68(s2)
    80005704:	4785                	li	a5,1
    80005706:	0af70863          	beq	a4,a5,800057b6 <sys_unlink+0x18c>
  iunlockput(dp);
    8000570a:	8526                	mv	a0,s1
    8000570c:	ffffe097          	auipc	ra,0xffffe
    80005710:	3a8080e7          	jalr	936(ra) # 80003ab4 <iunlockput>
  ip->nlink--;
    80005714:	04a95783          	lhu	a5,74(s2)
    80005718:	37fd                	addiw	a5,a5,-1
    8000571a:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    8000571e:	854a                	mv	a0,s2
    80005720:	ffffe097          	auipc	ra,0xffffe
    80005724:	066080e7          	jalr	102(ra) # 80003786 <iupdate>
  iunlockput(ip);
    80005728:	854a                	mv	a0,s2
    8000572a:	ffffe097          	auipc	ra,0xffffe
    8000572e:	38a080e7          	jalr	906(ra) # 80003ab4 <iunlockput>
  end_op();
    80005732:	fffff097          	auipc	ra,0xfffff
    80005736:	b6a080e7          	jalr	-1174(ra) # 8000429c <end_op>
  return 0;
    8000573a:	4501                	li	a0,0
    8000573c:	a84d                	j	800057ee <sys_unlink+0x1c4>
    end_op();
    8000573e:	fffff097          	auipc	ra,0xfffff
    80005742:	b5e080e7          	jalr	-1186(ra) # 8000429c <end_op>
    return -1;
    80005746:	557d                	li	a0,-1
    80005748:	a05d                	j	800057ee <sys_unlink+0x1c4>
    panic("unlink: nlink < 1");
    8000574a:	00003517          	auipc	a0,0x3
    8000574e:	00e50513          	addi	a0,a0,14 # 80008758 <syscalls+0x2c0>
    80005752:	ffffb097          	auipc	ra,0xffffb
    80005756:	dee080e7          	jalr	-530(ra) # 80000540 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000575a:	04c92703          	lw	a4,76(s2)
    8000575e:	02000793          	li	a5,32
    80005762:	f6e7f9e3          	bgeu	a5,a4,800056d4 <sys_unlink+0xaa>
    80005766:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000576a:	4741                	li	a4,16
    8000576c:	86ce                	mv	a3,s3
    8000576e:	f1840613          	addi	a2,s0,-232
    80005772:	4581                	li	a1,0
    80005774:	854a                	mv	a0,s2
    80005776:	ffffe097          	auipc	ra,0xffffe
    8000577a:	390080e7          	jalr	912(ra) # 80003b06 <readi>
    8000577e:	47c1                	li	a5,16
    80005780:	00f51b63          	bne	a0,a5,80005796 <sys_unlink+0x16c>
    if(de.inum != 0)
    80005784:	f1845783          	lhu	a5,-232(s0)
    80005788:	e7a1                	bnez	a5,800057d0 <sys_unlink+0x1a6>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000578a:	29c1                	addiw	s3,s3,16
    8000578c:	04c92783          	lw	a5,76(s2)
    80005790:	fcf9ede3          	bltu	s3,a5,8000576a <sys_unlink+0x140>
    80005794:	b781                	j	800056d4 <sys_unlink+0xaa>
      panic("isdirempty: readi");
    80005796:	00003517          	auipc	a0,0x3
    8000579a:	fda50513          	addi	a0,a0,-38 # 80008770 <syscalls+0x2d8>
    8000579e:	ffffb097          	auipc	ra,0xffffb
    800057a2:	da2080e7          	jalr	-606(ra) # 80000540 <panic>
    panic("unlink: writei");
    800057a6:	00003517          	auipc	a0,0x3
    800057aa:	fe250513          	addi	a0,a0,-30 # 80008788 <syscalls+0x2f0>
    800057ae:	ffffb097          	auipc	ra,0xffffb
    800057b2:	d92080e7          	jalr	-622(ra) # 80000540 <panic>
    dp->nlink--;
    800057b6:	04a4d783          	lhu	a5,74(s1)
    800057ba:	37fd                	addiw	a5,a5,-1
    800057bc:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800057c0:	8526                	mv	a0,s1
    800057c2:	ffffe097          	auipc	ra,0xffffe
    800057c6:	fc4080e7          	jalr	-60(ra) # 80003786 <iupdate>
    800057ca:	b781                	j	8000570a <sys_unlink+0xe0>
    return -1;
    800057cc:	557d                	li	a0,-1
    800057ce:	a005                	j	800057ee <sys_unlink+0x1c4>
    iunlockput(ip);
    800057d0:	854a                	mv	a0,s2
    800057d2:	ffffe097          	auipc	ra,0xffffe
    800057d6:	2e2080e7          	jalr	738(ra) # 80003ab4 <iunlockput>
  iunlockput(dp);
    800057da:	8526                	mv	a0,s1
    800057dc:	ffffe097          	auipc	ra,0xffffe
    800057e0:	2d8080e7          	jalr	728(ra) # 80003ab4 <iunlockput>
  end_op();
    800057e4:	fffff097          	auipc	ra,0xfffff
    800057e8:	ab8080e7          	jalr	-1352(ra) # 8000429c <end_op>
  return -1;
    800057ec:	557d                	li	a0,-1
}
    800057ee:	70ae                	ld	ra,232(sp)
    800057f0:	740e                	ld	s0,224(sp)
    800057f2:	64ee                	ld	s1,216(sp)
    800057f4:	694e                	ld	s2,208(sp)
    800057f6:	69ae                	ld	s3,200(sp)
    800057f8:	616d                	addi	sp,sp,240
    800057fa:	8082                	ret

00000000800057fc <sys_open>:

uint64
sys_open(void)
{
    800057fc:	7131                	addi	sp,sp,-192
    800057fe:	fd06                	sd	ra,184(sp)
    80005800:	f922                	sd	s0,176(sp)
    80005802:	f526                	sd	s1,168(sp)
    80005804:	f14a                	sd	s2,160(sp)
    80005806:	ed4e                	sd	s3,152(sp)
    80005808:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    8000580a:	f4c40593          	addi	a1,s0,-180
    8000580e:	4505                	li	a0,1
    80005810:	ffffd097          	auipc	ra,0xffffd
    80005814:	48a080e7          	jalr	1162(ra) # 80002c9a <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80005818:	08000613          	li	a2,128
    8000581c:	f5040593          	addi	a1,s0,-176
    80005820:	4501                	li	a0,0
    80005822:	ffffd097          	auipc	ra,0xffffd
    80005826:	4b8080e7          	jalr	1208(ra) # 80002cda <argstr>
    8000582a:	87aa                	mv	a5,a0
    return -1;
    8000582c:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000582e:	0a07c963          	bltz	a5,800058e0 <sys_open+0xe4>

  begin_op();
    80005832:	fffff097          	auipc	ra,0xfffff
    80005836:	9ec080e7          	jalr	-1556(ra) # 8000421e <begin_op>

  if(omode & O_CREATE){
    8000583a:	f4c42783          	lw	a5,-180(s0)
    8000583e:	2007f793          	andi	a5,a5,512
    80005842:	cfc5                	beqz	a5,800058fa <sys_open+0xfe>
    ip = create(path, T_FILE, 0, 0);
    80005844:	4681                	li	a3,0
    80005846:	4601                	li	a2,0
    80005848:	4589                	li	a1,2
    8000584a:	f5040513          	addi	a0,s0,-176
    8000584e:	00000097          	auipc	ra,0x0
    80005852:	972080e7          	jalr	-1678(ra) # 800051c0 <create>
    80005856:	84aa                	mv	s1,a0
    if(ip == 0){
    80005858:	c959                	beqz	a0,800058ee <sys_open+0xf2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    8000585a:	04449703          	lh	a4,68(s1)
    8000585e:	478d                	li	a5,3
    80005860:	00f71763          	bne	a4,a5,8000586e <sys_open+0x72>
    80005864:	0464d703          	lhu	a4,70(s1)
    80005868:	47a5                	li	a5,9
    8000586a:	0ce7ed63          	bltu	a5,a4,80005944 <sys_open+0x148>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    8000586e:	fffff097          	auipc	ra,0xfffff
    80005872:	dbc080e7          	jalr	-580(ra) # 8000462a <filealloc>
    80005876:	89aa                	mv	s3,a0
    80005878:	10050363          	beqz	a0,8000597e <sys_open+0x182>
    8000587c:	00000097          	auipc	ra,0x0
    80005880:	902080e7          	jalr	-1790(ra) # 8000517e <fdalloc>
    80005884:	892a                	mv	s2,a0
    80005886:	0e054763          	bltz	a0,80005974 <sys_open+0x178>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    8000588a:	04449703          	lh	a4,68(s1)
    8000588e:	478d                	li	a5,3
    80005890:	0cf70563          	beq	a4,a5,8000595a <sys_open+0x15e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80005894:	4789                	li	a5,2
    80005896:	00f9a023          	sw	a5,0(s3)
    f->off = 0;
    8000589a:	0209a023          	sw	zero,32(s3)
  }
  f->ip = ip;
    8000589e:	0099bc23          	sd	s1,24(s3)
  f->readable = !(omode & O_WRONLY);
    800058a2:	f4c42783          	lw	a5,-180(s0)
    800058a6:	0017c713          	xori	a4,a5,1
    800058aa:	8b05                	andi	a4,a4,1
    800058ac:	00e98423          	sb	a4,8(s3)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    800058b0:	0037f713          	andi	a4,a5,3
    800058b4:	00e03733          	snez	a4,a4
    800058b8:	00e984a3          	sb	a4,9(s3)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    800058bc:	4007f793          	andi	a5,a5,1024
    800058c0:	c791                	beqz	a5,800058cc <sys_open+0xd0>
    800058c2:	04449703          	lh	a4,68(s1)
    800058c6:	4789                	li	a5,2
    800058c8:	0af70063          	beq	a4,a5,80005968 <sys_open+0x16c>
    itrunc(ip);
  }

  iunlock(ip);
    800058cc:	8526                	mv	a0,s1
    800058ce:	ffffe097          	auipc	ra,0xffffe
    800058d2:	046080e7          	jalr	70(ra) # 80003914 <iunlock>
  end_op();
    800058d6:	fffff097          	auipc	ra,0xfffff
    800058da:	9c6080e7          	jalr	-1594(ra) # 8000429c <end_op>

  return fd;
    800058de:	854a                	mv	a0,s2
}
    800058e0:	70ea                	ld	ra,184(sp)
    800058e2:	744a                	ld	s0,176(sp)
    800058e4:	74aa                	ld	s1,168(sp)
    800058e6:	790a                	ld	s2,160(sp)
    800058e8:	69ea                	ld	s3,152(sp)
    800058ea:	6129                	addi	sp,sp,192
    800058ec:	8082                	ret
      end_op();
    800058ee:	fffff097          	auipc	ra,0xfffff
    800058f2:	9ae080e7          	jalr	-1618(ra) # 8000429c <end_op>
      return -1;
    800058f6:	557d                	li	a0,-1
    800058f8:	b7e5                	j	800058e0 <sys_open+0xe4>
    if((ip = namei(path)) == 0){
    800058fa:	f5040513          	addi	a0,s0,-176
    800058fe:	ffffe097          	auipc	ra,0xffffe
    80005902:	700080e7          	jalr	1792(ra) # 80003ffe <namei>
    80005906:	84aa                	mv	s1,a0
    80005908:	c905                	beqz	a0,80005938 <sys_open+0x13c>
    ilock(ip);
    8000590a:	ffffe097          	auipc	ra,0xffffe
    8000590e:	f48080e7          	jalr	-184(ra) # 80003852 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80005912:	04449703          	lh	a4,68(s1)
    80005916:	4785                	li	a5,1
    80005918:	f4f711e3          	bne	a4,a5,8000585a <sys_open+0x5e>
    8000591c:	f4c42783          	lw	a5,-180(s0)
    80005920:	d7b9                	beqz	a5,8000586e <sys_open+0x72>
      iunlockput(ip);
    80005922:	8526                	mv	a0,s1
    80005924:	ffffe097          	auipc	ra,0xffffe
    80005928:	190080e7          	jalr	400(ra) # 80003ab4 <iunlockput>
      end_op();
    8000592c:	fffff097          	auipc	ra,0xfffff
    80005930:	970080e7          	jalr	-1680(ra) # 8000429c <end_op>
      return -1;
    80005934:	557d                	li	a0,-1
    80005936:	b76d                	j	800058e0 <sys_open+0xe4>
      end_op();
    80005938:	fffff097          	auipc	ra,0xfffff
    8000593c:	964080e7          	jalr	-1692(ra) # 8000429c <end_op>
      return -1;
    80005940:	557d                	li	a0,-1
    80005942:	bf79                	j	800058e0 <sys_open+0xe4>
    iunlockput(ip);
    80005944:	8526                	mv	a0,s1
    80005946:	ffffe097          	auipc	ra,0xffffe
    8000594a:	16e080e7          	jalr	366(ra) # 80003ab4 <iunlockput>
    end_op();
    8000594e:	fffff097          	auipc	ra,0xfffff
    80005952:	94e080e7          	jalr	-1714(ra) # 8000429c <end_op>
    return -1;
    80005956:	557d                	li	a0,-1
    80005958:	b761                	j	800058e0 <sys_open+0xe4>
    f->type = FD_DEVICE;
    8000595a:	00f9a023          	sw	a5,0(s3)
    f->major = ip->major;
    8000595e:	04649783          	lh	a5,70(s1)
    80005962:	02f99223          	sh	a5,36(s3)
    80005966:	bf25                	j	8000589e <sys_open+0xa2>
    itrunc(ip);
    80005968:	8526                	mv	a0,s1
    8000596a:	ffffe097          	auipc	ra,0xffffe
    8000596e:	ff6080e7          	jalr	-10(ra) # 80003960 <itrunc>
    80005972:	bfa9                	j	800058cc <sys_open+0xd0>
      fileclose(f);
    80005974:	854e                	mv	a0,s3
    80005976:	fffff097          	auipc	ra,0xfffff
    8000597a:	d70080e7          	jalr	-656(ra) # 800046e6 <fileclose>
    iunlockput(ip);
    8000597e:	8526                	mv	a0,s1
    80005980:	ffffe097          	auipc	ra,0xffffe
    80005984:	134080e7          	jalr	308(ra) # 80003ab4 <iunlockput>
    end_op();
    80005988:	fffff097          	auipc	ra,0xfffff
    8000598c:	914080e7          	jalr	-1772(ra) # 8000429c <end_op>
    return -1;
    80005990:	557d                	li	a0,-1
    80005992:	b7b9                	j	800058e0 <sys_open+0xe4>

0000000080005994 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005994:	7175                	addi	sp,sp,-144
    80005996:	e506                	sd	ra,136(sp)
    80005998:	e122                	sd	s0,128(sp)
    8000599a:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    8000599c:	fffff097          	auipc	ra,0xfffff
    800059a0:	882080e7          	jalr	-1918(ra) # 8000421e <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    800059a4:	08000613          	li	a2,128
    800059a8:	f7040593          	addi	a1,s0,-144
    800059ac:	4501                	li	a0,0
    800059ae:	ffffd097          	auipc	ra,0xffffd
    800059b2:	32c080e7          	jalr	812(ra) # 80002cda <argstr>
    800059b6:	02054963          	bltz	a0,800059e8 <sys_mkdir+0x54>
    800059ba:	4681                	li	a3,0
    800059bc:	4601                	li	a2,0
    800059be:	4585                	li	a1,1
    800059c0:	f7040513          	addi	a0,s0,-144
    800059c4:	fffff097          	auipc	ra,0xfffff
    800059c8:	7fc080e7          	jalr	2044(ra) # 800051c0 <create>
    800059cc:	cd11                	beqz	a0,800059e8 <sys_mkdir+0x54>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800059ce:	ffffe097          	auipc	ra,0xffffe
    800059d2:	0e6080e7          	jalr	230(ra) # 80003ab4 <iunlockput>
  end_op();
    800059d6:	fffff097          	auipc	ra,0xfffff
    800059da:	8c6080e7          	jalr	-1850(ra) # 8000429c <end_op>
  return 0;
    800059de:	4501                	li	a0,0
}
    800059e0:	60aa                	ld	ra,136(sp)
    800059e2:	640a                	ld	s0,128(sp)
    800059e4:	6149                	addi	sp,sp,144
    800059e6:	8082                	ret
    end_op();
    800059e8:	fffff097          	auipc	ra,0xfffff
    800059ec:	8b4080e7          	jalr	-1868(ra) # 8000429c <end_op>
    return -1;
    800059f0:	557d                	li	a0,-1
    800059f2:	b7fd                	j	800059e0 <sys_mkdir+0x4c>

00000000800059f4 <sys_mknod>:

uint64
sys_mknod(void)
{
    800059f4:	7135                	addi	sp,sp,-160
    800059f6:	ed06                	sd	ra,152(sp)
    800059f8:	e922                	sd	s0,144(sp)
    800059fa:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    800059fc:	fffff097          	auipc	ra,0xfffff
    80005a00:	822080e7          	jalr	-2014(ra) # 8000421e <begin_op>
  argint(1, &major);
    80005a04:	f6c40593          	addi	a1,s0,-148
    80005a08:	4505                	li	a0,1
    80005a0a:	ffffd097          	auipc	ra,0xffffd
    80005a0e:	290080e7          	jalr	656(ra) # 80002c9a <argint>
  argint(2, &minor);
    80005a12:	f6840593          	addi	a1,s0,-152
    80005a16:	4509                	li	a0,2
    80005a18:	ffffd097          	auipc	ra,0xffffd
    80005a1c:	282080e7          	jalr	642(ra) # 80002c9a <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005a20:	08000613          	li	a2,128
    80005a24:	f7040593          	addi	a1,s0,-144
    80005a28:	4501                	li	a0,0
    80005a2a:	ffffd097          	auipc	ra,0xffffd
    80005a2e:	2b0080e7          	jalr	688(ra) # 80002cda <argstr>
    80005a32:	02054b63          	bltz	a0,80005a68 <sys_mknod+0x74>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80005a36:	f6841683          	lh	a3,-152(s0)
    80005a3a:	f6c41603          	lh	a2,-148(s0)
    80005a3e:	458d                	li	a1,3
    80005a40:	f7040513          	addi	a0,s0,-144
    80005a44:	fffff097          	auipc	ra,0xfffff
    80005a48:	77c080e7          	jalr	1916(ra) # 800051c0 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005a4c:	cd11                	beqz	a0,80005a68 <sys_mknod+0x74>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005a4e:	ffffe097          	auipc	ra,0xffffe
    80005a52:	066080e7          	jalr	102(ra) # 80003ab4 <iunlockput>
  end_op();
    80005a56:	fffff097          	auipc	ra,0xfffff
    80005a5a:	846080e7          	jalr	-1978(ra) # 8000429c <end_op>
  return 0;
    80005a5e:	4501                	li	a0,0
}
    80005a60:	60ea                	ld	ra,152(sp)
    80005a62:	644a                	ld	s0,144(sp)
    80005a64:	610d                	addi	sp,sp,160
    80005a66:	8082                	ret
    end_op();
    80005a68:	fffff097          	auipc	ra,0xfffff
    80005a6c:	834080e7          	jalr	-1996(ra) # 8000429c <end_op>
    return -1;
    80005a70:	557d                	li	a0,-1
    80005a72:	b7fd                	j	80005a60 <sys_mknod+0x6c>

0000000080005a74 <sys_chdir>:

uint64
sys_chdir(void)
{
    80005a74:	7135                	addi	sp,sp,-160
    80005a76:	ed06                	sd	ra,152(sp)
    80005a78:	e922                	sd	s0,144(sp)
    80005a7a:	e526                	sd	s1,136(sp)
    80005a7c:	e14a                	sd	s2,128(sp)
    80005a7e:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005a80:	ffffc097          	auipc	ra,0xffffc
    80005a84:	016080e7          	jalr	22(ra) # 80001a96 <myproc>
    80005a88:	892a                	mv	s2,a0
  
  begin_op();
    80005a8a:	ffffe097          	auipc	ra,0xffffe
    80005a8e:	794080e7          	jalr	1940(ra) # 8000421e <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80005a92:	08000613          	li	a2,128
    80005a96:	f6040593          	addi	a1,s0,-160
    80005a9a:	4501                	li	a0,0
    80005a9c:	ffffd097          	auipc	ra,0xffffd
    80005aa0:	23e080e7          	jalr	574(ra) # 80002cda <argstr>
    80005aa4:	04054b63          	bltz	a0,80005afa <sys_chdir+0x86>
    80005aa8:	f6040513          	addi	a0,s0,-160
    80005aac:	ffffe097          	auipc	ra,0xffffe
    80005ab0:	552080e7          	jalr	1362(ra) # 80003ffe <namei>
    80005ab4:	84aa                	mv	s1,a0
    80005ab6:	c131                	beqz	a0,80005afa <sys_chdir+0x86>
    end_op();
    return -1;
  }
  ilock(ip);
    80005ab8:	ffffe097          	auipc	ra,0xffffe
    80005abc:	d9a080e7          	jalr	-614(ra) # 80003852 <ilock>
  if(ip->type != T_DIR){
    80005ac0:	04449703          	lh	a4,68(s1)
    80005ac4:	4785                	li	a5,1
    80005ac6:	04f71063          	bne	a4,a5,80005b06 <sys_chdir+0x92>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80005aca:	8526                	mv	a0,s1
    80005acc:	ffffe097          	auipc	ra,0xffffe
    80005ad0:	e48080e7          	jalr	-440(ra) # 80003914 <iunlock>
  iput(p->cwd);
    80005ad4:	15093503          	ld	a0,336(s2)
    80005ad8:	ffffe097          	auipc	ra,0xffffe
    80005adc:	f34080e7          	jalr	-204(ra) # 80003a0c <iput>
  end_op();
    80005ae0:	ffffe097          	auipc	ra,0xffffe
    80005ae4:	7bc080e7          	jalr	1980(ra) # 8000429c <end_op>
  p->cwd = ip;
    80005ae8:	14993823          	sd	s1,336(s2)
  return 0;
    80005aec:	4501                	li	a0,0
}
    80005aee:	60ea                	ld	ra,152(sp)
    80005af0:	644a                	ld	s0,144(sp)
    80005af2:	64aa                	ld	s1,136(sp)
    80005af4:	690a                	ld	s2,128(sp)
    80005af6:	610d                	addi	sp,sp,160
    80005af8:	8082                	ret
    end_op();
    80005afa:	ffffe097          	auipc	ra,0xffffe
    80005afe:	7a2080e7          	jalr	1954(ra) # 8000429c <end_op>
    return -1;
    80005b02:	557d                	li	a0,-1
    80005b04:	b7ed                	j	80005aee <sys_chdir+0x7a>
    iunlockput(ip);
    80005b06:	8526                	mv	a0,s1
    80005b08:	ffffe097          	auipc	ra,0xffffe
    80005b0c:	fac080e7          	jalr	-84(ra) # 80003ab4 <iunlockput>
    end_op();
    80005b10:	ffffe097          	auipc	ra,0xffffe
    80005b14:	78c080e7          	jalr	1932(ra) # 8000429c <end_op>
    return -1;
    80005b18:	557d                	li	a0,-1
    80005b1a:	bfd1                	j	80005aee <sys_chdir+0x7a>

0000000080005b1c <sys_exec>:

uint64
sys_exec(void)
{
    80005b1c:	7145                	addi	sp,sp,-464
    80005b1e:	e786                	sd	ra,456(sp)
    80005b20:	e3a2                	sd	s0,448(sp)
    80005b22:	ff26                	sd	s1,440(sp)
    80005b24:	fb4a                	sd	s2,432(sp)
    80005b26:	f74e                	sd	s3,424(sp)
    80005b28:	f352                	sd	s4,416(sp)
    80005b2a:	ef56                	sd	s5,408(sp)
    80005b2c:	0b80                	addi	s0,sp,464
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005b2e:	e3840593          	addi	a1,s0,-456
    80005b32:	4505                	li	a0,1
    80005b34:	ffffd097          	auipc	ra,0xffffd
    80005b38:	186080e7          	jalr	390(ra) # 80002cba <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005b3c:	08000613          	li	a2,128
    80005b40:	f4040593          	addi	a1,s0,-192
    80005b44:	4501                	li	a0,0
    80005b46:	ffffd097          	auipc	ra,0xffffd
    80005b4a:	194080e7          	jalr	404(ra) # 80002cda <argstr>
    80005b4e:	87aa                	mv	a5,a0
    return -1;
    80005b50:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005b52:	0c07c363          	bltz	a5,80005c18 <sys_exec+0xfc>
  }
  memset(argv, 0, sizeof(argv));
    80005b56:	10000613          	li	a2,256
    80005b5a:	4581                	li	a1,0
    80005b5c:	e4040513          	addi	a0,s0,-448
    80005b60:	ffffb097          	auipc	ra,0xffffb
    80005b64:	172080e7          	jalr	370(ra) # 80000cd2 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80005b68:	e4040493          	addi	s1,s0,-448
  memset(argv, 0, sizeof(argv));
    80005b6c:	89a6                	mv	s3,s1
    80005b6e:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    80005b70:	02000a13          	li	s4,32
    80005b74:	00090a9b          	sext.w	s5,s2
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005b78:	00391513          	slli	a0,s2,0x3
    80005b7c:	e3040593          	addi	a1,s0,-464
    80005b80:	e3843783          	ld	a5,-456(s0)
    80005b84:	953e                	add	a0,a0,a5
    80005b86:	ffffd097          	auipc	ra,0xffffd
    80005b8a:	076080e7          	jalr	118(ra) # 80002bfc <fetchaddr>
    80005b8e:	02054a63          	bltz	a0,80005bc2 <sys_exec+0xa6>
      goto bad;
    }
    if(uarg == 0){
    80005b92:	e3043783          	ld	a5,-464(s0)
    80005b96:	c3b9                	beqz	a5,80005bdc <sys_exec+0xc0>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    80005b98:	ffffb097          	auipc	ra,0xffffb
    80005b9c:	f4e080e7          	jalr	-178(ra) # 80000ae6 <kalloc>
    80005ba0:	85aa                	mv	a1,a0
    80005ba2:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    80005ba6:	cd11                	beqz	a0,80005bc2 <sys_exec+0xa6>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005ba8:	6605                	lui	a2,0x1
    80005baa:	e3043503          	ld	a0,-464(s0)
    80005bae:	ffffd097          	auipc	ra,0xffffd
    80005bb2:	0a0080e7          	jalr	160(ra) # 80002c4e <fetchstr>
    80005bb6:	00054663          	bltz	a0,80005bc2 <sys_exec+0xa6>
    if(i >= NELEM(argv)){
    80005bba:	0905                	addi	s2,s2,1
    80005bbc:	09a1                	addi	s3,s3,8
    80005bbe:	fb491be3          	bne	s2,s4,80005b74 <sys_exec+0x58>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005bc2:	f4040913          	addi	s2,s0,-192
    80005bc6:	6088                	ld	a0,0(s1)
    80005bc8:	c539                	beqz	a0,80005c16 <sys_exec+0xfa>
    kfree(argv[i]);
    80005bca:	ffffb097          	auipc	ra,0xffffb
    80005bce:	e1e080e7          	jalr	-482(ra) # 800009e8 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005bd2:	04a1                	addi	s1,s1,8
    80005bd4:	ff2499e3          	bne	s1,s2,80005bc6 <sys_exec+0xaa>
  return -1;
    80005bd8:	557d                	li	a0,-1
    80005bda:	a83d                	j	80005c18 <sys_exec+0xfc>
      argv[i] = 0;
    80005bdc:	0a8e                	slli	s5,s5,0x3
    80005bde:	fc0a8793          	addi	a5,s5,-64
    80005be2:	00878ab3          	add	s5,a5,s0
    80005be6:	e80ab023          	sd	zero,-384(s5)
  int ret = exec(path, argv);
    80005bea:	e4040593          	addi	a1,s0,-448
    80005bee:	f4040513          	addi	a0,s0,-192
    80005bf2:	fffff097          	auipc	ra,0xfffff
    80005bf6:	16e080e7          	jalr	366(ra) # 80004d60 <exec>
    80005bfa:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005bfc:	f4040993          	addi	s3,s0,-192
    80005c00:	6088                	ld	a0,0(s1)
    80005c02:	c901                	beqz	a0,80005c12 <sys_exec+0xf6>
    kfree(argv[i]);
    80005c04:	ffffb097          	auipc	ra,0xffffb
    80005c08:	de4080e7          	jalr	-540(ra) # 800009e8 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005c0c:	04a1                	addi	s1,s1,8
    80005c0e:	ff3499e3          	bne	s1,s3,80005c00 <sys_exec+0xe4>
  return ret;
    80005c12:	854a                	mv	a0,s2
    80005c14:	a011                	j	80005c18 <sys_exec+0xfc>
  return -1;
    80005c16:	557d                	li	a0,-1
}
    80005c18:	60be                	ld	ra,456(sp)
    80005c1a:	641e                	ld	s0,448(sp)
    80005c1c:	74fa                	ld	s1,440(sp)
    80005c1e:	795a                	ld	s2,432(sp)
    80005c20:	79ba                	ld	s3,424(sp)
    80005c22:	7a1a                	ld	s4,416(sp)
    80005c24:	6afa                	ld	s5,408(sp)
    80005c26:	6179                	addi	sp,sp,464
    80005c28:	8082                	ret

0000000080005c2a <sys_pipe>:

uint64
sys_pipe(void)
{
    80005c2a:	7139                	addi	sp,sp,-64
    80005c2c:	fc06                	sd	ra,56(sp)
    80005c2e:	f822                	sd	s0,48(sp)
    80005c30:	f426                	sd	s1,40(sp)
    80005c32:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005c34:	ffffc097          	auipc	ra,0xffffc
    80005c38:	e62080e7          	jalr	-414(ra) # 80001a96 <myproc>
    80005c3c:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005c3e:	fd840593          	addi	a1,s0,-40
    80005c42:	4501                	li	a0,0
    80005c44:	ffffd097          	auipc	ra,0xffffd
    80005c48:	076080e7          	jalr	118(ra) # 80002cba <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80005c4c:	fc840593          	addi	a1,s0,-56
    80005c50:	fd040513          	addi	a0,s0,-48
    80005c54:	fffff097          	auipc	ra,0xfffff
    80005c58:	dc2080e7          	jalr	-574(ra) # 80004a16 <pipealloc>
    return -1;
    80005c5c:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80005c5e:	0c054463          	bltz	a0,80005d26 <sys_pipe+0xfc>
  fd0 = -1;
    80005c62:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80005c66:	fd043503          	ld	a0,-48(s0)
    80005c6a:	fffff097          	auipc	ra,0xfffff
    80005c6e:	514080e7          	jalr	1300(ra) # 8000517e <fdalloc>
    80005c72:	fca42223          	sw	a0,-60(s0)
    80005c76:	08054b63          	bltz	a0,80005d0c <sys_pipe+0xe2>
    80005c7a:	fc843503          	ld	a0,-56(s0)
    80005c7e:	fffff097          	auipc	ra,0xfffff
    80005c82:	500080e7          	jalr	1280(ra) # 8000517e <fdalloc>
    80005c86:	fca42023          	sw	a0,-64(s0)
    80005c8a:	06054863          	bltz	a0,80005cfa <sys_pipe+0xd0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005c8e:	4691                	li	a3,4
    80005c90:	fc440613          	addi	a2,s0,-60
    80005c94:	fd843583          	ld	a1,-40(s0)
    80005c98:	68a8                	ld	a0,80(s1)
    80005c9a:	ffffc097          	auipc	ra,0xffffc
    80005c9e:	abc080e7          	jalr	-1348(ra) # 80001756 <copyout>
    80005ca2:	02054063          	bltz	a0,80005cc2 <sys_pipe+0x98>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80005ca6:	4691                	li	a3,4
    80005ca8:	fc040613          	addi	a2,s0,-64
    80005cac:	fd843583          	ld	a1,-40(s0)
    80005cb0:	0591                	addi	a1,a1,4
    80005cb2:	68a8                	ld	a0,80(s1)
    80005cb4:	ffffc097          	auipc	ra,0xffffc
    80005cb8:	aa2080e7          	jalr	-1374(ra) # 80001756 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005cbc:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005cbe:	06055463          	bgez	a0,80005d26 <sys_pipe+0xfc>
    p->ofile[fd0] = 0;
    80005cc2:	fc442783          	lw	a5,-60(s0)
    80005cc6:	07e9                	addi	a5,a5,26
    80005cc8:	078e                	slli	a5,a5,0x3
    80005cca:	97a6                	add	a5,a5,s1
    80005ccc:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005cd0:	fc042783          	lw	a5,-64(s0)
    80005cd4:	07e9                	addi	a5,a5,26
    80005cd6:	078e                	slli	a5,a5,0x3
    80005cd8:	94be                	add	s1,s1,a5
    80005cda:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005cde:	fd043503          	ld	a0,-48(s0)
    80005ce2:	fffff097          	auipc	ra,0xfffff
    80005ce6:	a04080e7          	jalr	-1532(ra) # 800046e6 <fileclose>
    fileclose(wf);
    80005cea:	fc843503          	ld	a0,-56(s0)
    80005cee:	fffff097          	auipc	ra,0xfffff
    80005cf2:	9f8080e7          	jalr	-1544(ra) # 800046e6 <fileclose>
    return -1;
    80005cf6:	57fd                	li	a5,-1
    80005cf8:	a03d                	j	80005d26 <sys_pipe+0xfc>
    if(fd0 >= 0)
    80005cfa:	fc442783          	lw	a5,-60(s0)
    80005cfe:	0007c763          	bltz	a5,80005d0c <sys_pipe+0xe2>
      p->ofile[fd0] = 0;
    80005d02:	07e9                	addi	a5,a5,26
    80005d04:	078e                	slli	a5,a5,0x3
    80005d06:	97a6                	add	a5,a5,s1
    80005d08:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005d0c:	fd043503          	ld	a0,-48(s0)
    80005d10:	fffff097          	auipc	ra,0xfffff
    80005d14:	9d6080e7          	jalr	-1578(ra) # 800046e6 <fileclose>
    fileclose(wf);
    80005d18:	fc843503          	ld	a0,-56(s0)
    80005d1c:	fffff097          	auipc	ra,0xfffff
    80005d20:	9ca080e7          	jalr	-1590(ra) # 800046e6 <fileclose>
    return -1;
    80005d24:	57fd                	li	a5,-1
}
    80005d26:	853e                	mv	a0,a5
    80005d28:	70e2                	ld	ra,56(sp)
    80005d2a:	7442                	ld	s0,48(sp)
    80005d2c:	74a2                	ld	s1,40(sp)
    80005d2e:	6121                	addi	sp,sp,64
    80005d30:	8082                	ret
	...

0000000080005d40 <kernelvec>:
    80005d40:	7111                	addi	sp,sp,-256
    80005d42:	e006                	sd	ra,0(sp)
    80005d44:	e40a                	sd	sp,8(sp)
    80005d46:	e80e                	sd	gp,16(sp)
    80005d48:	ec12                	sd	tp,24(sp)
    80005d4a:	f016                	sd	t0,32(sp)
    80005d4c:	f41a                	sd	t1,40(sp)
    80005d4e:	f81e                	sd	t2,48(sp)
    80005d50:	fc22                	sd	s0,56(sp)
    80005d52:	e0a6                	sd	s1,64(sp)
    80005d54:	e4aa                	sd	a0,72(sp)
    80005d56:	e8ae                	sd	a1,80(sp)
    80005d58:	ecb2                	sd	a2,88(sp)
    80005d5a:	f0b6                	sd	a3,96(sp)
    80005d5c:	f4ba                	sd	a4,104(sp)
    80005d5e:	f8be                	sd	a5,112(sp)
    80005d60:	fcc2                	sd	a6,120(sp)
    80005d62:	e146                	sd	a7,128(sp)
    80005d64:	e54a                	sd	s2,136(sp)
    80005d66:	e94e                	sd	s3,144(sp)
    80005d68:	ed52                	sd	s4,152(sp)
    80005d6a:	f156                	sd	s5,160(sp)
    80005d6c:	f55a                	sd	s6,168(sp)
    80005d6e:	f95e                	sd	s7,176(sp)
    80005d70:	fd62                	sd	s8,184(sp)
    80005d72:	e1e6                	sd	s9,192(sp)
    80005d74:	e5ea                	sd	s10,200(sp)
    80005d76:	e9ee                	sd	s11,208(sp)
    80005d78:	edf2                	sd	t3,216(sp)
    80005d7a:	f1f6                	sd	t4,224(sp)
    80005d7c:	f5fa                	sd	t5,232(sp)
    80005d7e:	f9fe                	sd	t6,240(sp)
    80005d80:	d49fc0ef          	jal	ra,80002ac8 <kerneltrap>
    80005d84:	6082                	ld	ra,0(sp)
    80005d86:	6122                	ld	sp,8(sp)
    80005d88:	61c2                	ld	gp,16(sp)
    80005d8a:	7282                	ld	t0,32(sp)
    80005d8c:	7322                	ld	t1,40(sp)
    80005d8e:	73c2                	ld	t2,48(sp)
    80005d90:	7462                	ld	s0,56(sp)
    80005d92:	6486                	ld	s1,64(sp)
    80005d94:	6526                	ld	a0,72(sp)
    80005d96:	65c6                	ld	a1,80(sp)
    80005d98:	6666                	ld	a2,88(sp)
    80005d9a:	7686                	ld	a3,96(sp)
    80005d9c:	7726                	ld	a4,104(sp)
    80005d9e:	77c6                	ld	a5,112(sp)
    80005da0:	7866                	ld	a6,120(sp)
    80005da2:	688a                	ld	a7,128(sp)
    80005da4:	692a                	ld	s2,136(sp)
    80005da6:	69ca                	ld	s3,144(sp)
    80005da8:	6a6a                	ld	s4,152(sp)
    80005daa:	7a8a                	ld	s5,160(sp)
    80005dac:	7b2a                	ld	s6,168(sp)
    80005dae:	7bca                	ld	s7,176(sp)
    80005db0:	7c6a                	ld	s8,184(sp)
    80005db2:	6c8e                	ld	s9,192(sp)
    80005db4:	6d2e                	ld	s10,200(sp)
    80005db6:	6dce                	ld	s11,208(sp)
    80005db8:	6e6e                	ld	t3,216(sp)
    80005dba:	7e8e                	ld	t4,224(sp)
    80005dbc:	7f2e                	ld	t5,232(sp)
    80005dbe:	7fce                	ld	t6,240(sp)
    80005dc0:	6111                	addi	sp,sp,256
    80005dc2:	10200073          	sret
    80005dc6:	00000013          	nop
    80005dca:	00000013          	nop
    80005dce:	0001                	nop

0000000080005dd0 <timervec>:
    80005dd0:	34051573          	csrrw	a0,mscratch,a0
    80005dd4:	e10c                	sd	a1,0(a0)
    80005dd6:	e510                	sd	a2,8(a0)
    80005dd8:	e914                	sd	a3,16(a0)
    80005dda:	6d0c                	ld	a1,24(a0)
    80005ddc:	7110                	ld	a2,32(a0)
    80005dde:	6194                	ld	a3,0(a1)
    80005de0:	96b2                	add	a3,a3,a2
    80005de2:	e194                	sd	a3,0(a1)
    80005de4:	4589                	li	a1,2
    80005de6:	14459073          	csrw	sip,a1
    80005dea:	6914                	ld	a3,16(a0)
    80005dec:	6510                	ld	a2,8(a0)
    80005dee:	610c                	ld	a1,0(a0)
    80005df0:	34051573          	csrrw	a0,mscratch,a0
    80005df4:	30200073          	mret
	...

0000000080005dfa <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    80005dfa:	1141                	addi	sp,sp,-16
    80005dfc:	e422                	sd	s0,8(sp)
    80005dfe:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005e00:	0c0007b7          	lui	a5,0xc000
    80005e04:	4705                	li	a4,1
    80005e06:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    80005e08:	c3d8                	sw	a4,4(a5)
}
    80005e0a:	6422                	ld	s0,8(sp)
    80005e0c:	0141                	addi	sp,sp,16
    80005e0e:	8082                	ret

0000000080005e10 <plicinithart>:

void
plicinithart(void)
{
    80005e10:	1141                	addi	sp,sp,-16
    80005e12:	e406                	sd	ra,8(sp)
    80005e14:	e022                	sd	s0,0(sp)
    80005e16:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005e18:	ffffc097          	auipc	ra,0xffffc
    80005e1c:	c52080e7          	jalr	-942(ra) # 80001a6a <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005e20:	0085171b          	slliw	a4,a0,0x8
    80005e24:	0c0027b7          	lui	a5,0xc002
    80005e28:	97ba                	add	a5,a5,a4
    80005e2a:	40200713          	li	a4,1026
    80005e2e:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005e32:	00d5151b          	slliw	a0,a0,0xd
    80005e36:	0c2017b7          	lui	a5,0xc201
    80005e3a:	97aa                	add	a5,a5,a0
    80005e3c:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005e40:	60a2                	ld	ra,8(sp)
    80005e42:	6402                	ld	s0,0(sp)
    80005e44:	0141                	addi	sp,sp,16
    80005e46:	8082                	ret

0000000080005e48 <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80005e48:	1141                	addi	sp,sp,-16
    80005e4a:	e406                	sd	ra,8(sp)
    80005e4c:	e022                	sd	s0,0(sp)
    80005e4e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005e50:	ffffc097          	auipc	ra,0xffffc
    80005e54:	c1a080e7          	jalr	-998(ra) # 80001a6a <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005e58:	00d5151b          	slliw	a0,a0,0xd
    80005e5c:	0c2017b7          	lui	a5,0xc201
    80005e60:	97aa                	add	a5,a5,a0
  return irq;
}
    80005e62:	43c8                	lw	a0,4(a5)
    80005e64:	60a2                	ld	ra,8(sp)
    80005e66:	6402                	ld	s0,0(sp)
    80005e68:	0141                	addi	sp,sp,16
    80005e6a:	8082                	ret

0000000080005e6c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005e6c:	1101                	addi	sp,sp,-32
    80005e6e:	ec06                	sd	ra,24(sp)
    80005e70:	e822                	sd	s0,16(sp)
    80005e72:	e426                	sd	s1,8(sp)
    80005e74:	1000                	addi	s0,sp,32
    80005e76:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005e78:	ffffc097          	auipc	ra,0xffffc
    80005e7c:	bf2080e7          	jalr	-1038(ra) # 80001a6a <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    80005e80:	00d5151b          	slliw	a0,a0,0xd
    80005e84:	0c2017b7          	lui	a5,0xc201
    80005e88:	97aa                	add	a5,a5,a0
    80005e8a:	c3c4                	sw	s1,4(a5)
}
    80005e8c:	60e2                	ld	ra,24(sp)
    80005e8e:	6442                	ld	s0,16(sp)
    80005e90:	64a2                	ld	s1,8(sp)
    80005e92:	6105                	addi	sp,sp,32
    80005e94:	8082                	ret

0000000080005e96 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005e96:	1141                	addi	sp,sp,-16
    80005e98:	e406                	sd	ra,8(sp)
    80005e9a:	e022                	sd	s0,0(sp)
    80005e9c:	0800                	addi	s0,sp,16
  if(i >= NUM)
    80005e9e:	479d                	li	a5,7
    80005ea0:	04a7cc63          	blt	a5,a0,80005ef8 <free_desc+0x62>
    panic("free_desc 1");
  if(disk.free[i])
    80005ea4:	0001c797          	auipc	a5,0x1c
    80005ea8:	27c78793          	addi	a5,a5,636 # 80022120 <disk>
    80005eac:	97aa                	add	a5,a5,a0
    80005eae:	0187c783          	lbu	a5,24(a5)
    80005eb2:	ebb9                	bnez	a5,80005f08 <free_desc+0x72>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005eb4:	00451693          	slli	a3,a0,0x4
    80005eb8:	0001c797          	auipc	a5,0x1c
    80005ebc:	26878793          	addi	a5,a5,616 # 80022120 <disk>
    80005ec0:	6398                	ld	a4,0(a5)
    80005ec2:	9736                	add	a4,a4,a3
    80005ec4:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    80005ec8:	6398                	ld	a4,0(a5)
    80005eca:	9736                	add	a4,a4,a3
    80005ecc:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80005ed0:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005ed4:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005ed8:	97aa                	add	a5,a5,a0
    80005eda:	4705                	li	a4,1
    80005edc:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80005ee0:	0001c517          	auipc	a0,0x1c
    80005ee4:	25850513          	addi	a0,a0,600 # 80022138 <disk+0x18>
    80005ee8:	ffffc097          	auipc	ra,0xffffc
    80005eec:	3a8080e7          	jalr	936(ra) # 80002290 <wakeup>
}
    80005ef0:	60a2                	ld	ra,8(sp)
    80005ef2:	6402                	ld	s0,0(sp)
    80005ef4:	0141                	addi	sp,sp,16
    80005ef6:	8082                	ret
    panic("free_desc 1");
    80005ef8:	00003517          	auipc	a0,0x3
    80005efc:	8a050513          	addi	a0,a0,-1888 # 80008798 <syscalls+0x300>
    80005f00:	ffffa097          	auipc	ra,0xffffa
    80005f04:	640080e7          	jalr	1600(ra) # 80000540 <panic>
    panic("free_desc 2");
    80005f08:	00003517          	auipc	a0,0x3
    80005f0c:	8a050513          	addi	a0,a0,-1888 # 800087a8 <syscalls+0x310>
    80005f10:	ffffa097          	auipc	ra,0xffffa
    80005f14:	630080e7          	jalr	1584(ra) # 80000540 <panic>

0000000080005f18 <virtio_disk_init>:
{
    80005f18:	1101                	addi	sp,sp,-32
    80005f1a:	ec06                	sd	ra,24(sp)
    80005f1c:	e822                	sd	s0,16(sp)
    80005f1e:	e426                	sd	s1,8(sp)
    80005f20:	e04a                	sd	s2,0(sp)
    80005f22:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005f24:	00003597          	auipc	a1,0x3
    80005f28:	89458593          	addi	a1,a1,-1900 # 800087b8 <syscalls+0x320>
    80005f2c:	0001c517          	auipc	a0,0x1c
    80005f30:	31c50513          	addi	a0,a0,796 # 80022248 <disk+0x128>
    80005f34:	ffffb097          	auipc	ra,0xffffb
    80005f38:	c12080e7          	jalr	-1006(ra) # 80000b46 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005f3c:	100017b7          	lui	a5,0x10001
    80005f40:	4398                	lw	a4,0(a5)
    80005f42:	2701                	sext.w	a4,a4
    80005f44:	747277b7          	lui	a5,0x74727
    80005f48:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005f4c:	14f71b63          	bne	a4,a5,800060a2 <virtio_disk_init+0x18a>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005f50:	100017b7          	lui	a5,0x10001
    80005f54:	43dc                	lw	a5,4(a5)
    80005f56:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005f58:	4709                	li	a4,2
    80005f5a:	14e79463          	bne	a5,a4,800060a2 <virtio_disk_init+0x18a>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005f5e:	100017b7          	lui	a5,0x10001
    80005f62:	479c                	lw	a5,8(a5)
    80005f64:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005f66:	12e79e63          	bne	a5,a4,800060a2 <virtio_disk_init+0x18a>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80005f6a:	100017b7          	lui	a5,0x10001
    80005f6e:	47d8                	lw	a4,12(a5)
    80005f70:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005f72:	554d47b7          	lui	a5,0x554d4
    80005f76:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005f7a:	12f71463          	bne	a4,a5,800060a2 <virtio_disk_init+0x18a>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005f7e:	100017b7          	lui	a5,0x10001
    80005f82:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005f86:	4705                	li	a4,1
    80005f88:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005f8a:	470d                	li	a4,3
    80005f8c:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005f8e:	4b98                	lw	a4,16(a5)
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005f90:	c7ffe6b7          	lui	a3,0xc7ffe
    80005f94:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fdc4ff>
    80005f98:	8f75                	and	a4,a4,a3
    80005f9a:	d398                	sw	a4,32(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005f9c:	472d                	li	a4,11
    80005f9e:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    80005fa0:	5bbc                	lw	a5,112(a5)
    80005fa2:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005fa6:	8ba1                	andi	a5,a5,8
    80005fa8:	10078563          	beqz	a5,800060b2 <virtio_disk_init+0x19a>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005fac:	100017b7          	lui	a5,0x10001
    80005fb0:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005fb4:	43fc                	lw	a5,68(a5)
    80005fb6:	2781                	sext.w	a5,a5
    80005fb8:	10079563          	bnez	a5,800060c2 <virtio_disk_init+0x1aa>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005fbc:	100017b7          	lui	a5,0x10001
    80005fc0:	5bdc                	lw	a5,52(a5)
    80005fc2:	2781                	sext.w	a5,a5
  if(max == 0)
    80005fc4:	10078763          	beqz	a5,800060d2 <virtio_disk_init+0x1ba>
  if(max < NUM)
    80005fc8:	471d                	li	a4,7
    80005fca:	10f77c63          	bgeu	a4,a5,800060e2 <virtio_disk_init+0x1ca>
  disk.desc = kalloc();
    80005fce:	ffffb097          	auipc	ra,0xffffb
    80005fd2:	b18080e7          	jalr	-1256(ra) # 80000ae6 <kalloc>
    80005fd6:	0001c497          	auipc	s1,0x1c
    80005fda:	14a48493          	addi	s1,s1,330 # 80022120 <disk>
    80005fde:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005fe0:	ffffb097          	auipc	ra,0xffffb
    80005fe4:	b06080e7          	jalr	-1274(ra) # 80000ae6 <kalloc>
    80005fe8:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80005fea:	ffffb097          	auipc	ra,0xffffb
    80005fee:	afc080e7          	jalr	-1284(ra) # 80000ae6 <kalloc>
    80005ff2:	87aa                	mv	a5,a0
    80005ff4:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80005ff6:	6088                	ld	a0,0(s1)
    80005ff8:	cd6d                	beqz	a0,800060f2 <virtio_disk_init+0x1da>
    80005ffa:	0001c717          	auipc	a4,0x1c
    80005ffe:	12e73703          	ld	a4,302(a4) # 80022128 <disk+0x8>
    80006002:	cb65                	beqz	a4,800060f2 <virtio_disk_init+0x1da>
    80006004:	c7fd                	beqz	a5,800060f2 <virtio_disk_init+0x1da>
  memset(disk.desc, 0, PGSIZE);
    80006006:	6605                	lui	a2,0x1
    80006008:	4581                	li	a1,0
    8000600a:	ffffb097          	auipc	ra,0xffffb
    8000600e:	cc8080e7          	jalr	-824(ra) # 80000cd2 <memset>
  memset(disk.avail, 0, PGSIZE);
    80006012:	0001c497          	auipc	s1,0x1c
    80006016:	10e48493          	addi	s1,s1,270 # 80022120 <disk>
    8000601a:	6605                	lui	a2,0x1
    8000601c:	4581                	li	a1,0
    8000601e:	6488                	ld	a0,8(s1)
    80006020:	ffffb097          	auipc	ra,0xffffb
    80006024:	cb2080e7          	jalr	-846(ra) # 80000cd2 <memset>
  memset(disk.used, 0, PGSIZE);
    80006028:	6605                	lui	a2,0x1
    8000602a:	4581                	li	a1,0
    8000602c:	6888                	ld	a0,16(s1)
    8000602e:	ffffb097          	auipc	ra,0xffffb
    80006032:	ca4080e7          	jalr	-860(ra) # 80000cd2 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80006036:	100017b7          	lui	a5,0x10001
    8000603a:	4721                	li	a4,8
    8000603c:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    8000603e:	4098                	lw	a4,0(s1)
    80006040:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80006044:	40d8                	lw	a4,4(s1)
    80006046:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    8000604a:	6498                	ld	a4,8(s1)
    8000604c:	0007069b          	sext.w	a3,a4
    80006050:	08d7a823          	sw	a3,144(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80006054:	9701                	srai	a4,a4,0x20
    80006056:	08e7aa23          	sw	a4,148(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    8000605a:	6898                	ld	a4,16(s1)
    8000605c:	0007069b          	sext.w	a3,a4
    80006060:	0ad7a023          	sw	a3,160(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80006064:	9701                	srai	a4,a4,0x20
    80006066:	0ae7a223          	sw	a4,164(a5)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    8000606a:	4705                	li	a4,1
    8000606c:	c3f8                	sw	a4,68(a5)
    disk.free[i] = 1;
    8000606e:	00e48c23          	sb	a4,24(s1)
    80006072:	00e48ca3          	sb	a4,25(s1)
    80006076:	00e48d23          	sb	a4,26(s1)
    8000607a:	00e48da3          	sb	a4,27(s1)
    8000607e:	00e48e23          	sb	a4,28(s1)
    80006082:	00e48ea3          	sb	a4,29(s1)
    80006086:	00e48f23          	sb	a4,30(s1)
    8000608a:	00e48fa3          	sb	a4,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    8000608e:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80006092:	0727a823          	sw	s2,112(a5)
}
    80006096:	60e2                	ld	ra,24(sp)
    80006098:	6442                	ld	s0,16(sp)
    8000609a:	64a2                	ld	s1,8(sp)
    8000609c:	6902                	ld	s2,0(sp)
    8000609e:	6105                	addi	sp,sp,32
    800060a0:	8082                	ret
    panic("could not find virtio disk");
    800060a2:	00002517          	auipc	a0,0x2
    800060a6:	72650513          	addi	a0,a0,1830 # 800087c8 <syscalls+0x330>
    800060aa:	ffffa097          	auipc	ra,0xffffa
    800060ae:	496080e7          	jalr	1174(ra) # 80000540 <panic>
    panic("virtio disk FEATURES_OK unset");
    800060b2:	00002517          	auipc	a0,0x2
    800060b6:	73650513          	addi	a0,a0,1846 # 800087e8 <syscalls+0x350>
    800060ba:	ffffa097          	auipc	ra,0xffffa
    800060be:	486080e7          	jalr	1158(ra) # 80000540 <panic>
    panic("virtio disk should not be ready");
    800060c2:	00002517          	auipc	a0,0x2
    800060c6:	74650513          	addi	a0,a0,1862 # 80008808 <syscalls+0x370>
    800060ca:	ffffa097          	auipc	ra,0xffffa
    800060ce:	476080e7          	jalr	1142(ra) # 80000540 <panic>
    panic("virtio disk has no queue 0");
    800060d2:	00002517          	auipc	a0,0x2
    800060d6:	75650513          	addi	a0,a0,1878 # 80008828 <syscalls+0x390>
    800060da:	ffffa097          	auipc	ra,0xffffa
    800060de:	466080e7          	jalr	1126(ra) # 80000540 <panic>
    panic("virtio disk max queue too short");
    800060e2:	00002517          	auipc	a0,0x2
    800060e6:	76650513          	addi	a0,a0,1894 # 80008848 <syscalls+0x3b0>
    800060ea:	ffffa097          	auipc	ra,0xffffa
    800060ee:	456080e7          	jalr	1110(ra) # 80000540 <panic>
    panic("virtio disk kalloc");
    800060f2:	00002517          	auipc	a0,0x2
    800060f6:	77650513          	addi	a0,a0,1910 # 80008868 <syscalls+0x3d0>
    800060fa:	ffffa097          	auipc	ra,0xffffa
    800060fe:	446080e7          	jalr	1094(ra) # 80000540 <panic>

0000000080006102 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80006102:	7119                	addi	sp,sp,-128
    80006104:	fc86                	sd	ra,120(sp)
    80006106:	f8a2                	sd	s0,112(sp)
    80006108:	f4a6                	sd	s1,104(sp)
    8000610a:	f0ca                	sd	s2,96(sp)
    8000610c:	ecce                	sd	s3,88(sp)
    8000610e:	e8d2                	sd	s4,80(sp)
    80006110:	e4d6                	sd	s5,72(sp)
    80006112:	e0da                	sd	s6,64(sp)
    80006114:	fc5e                	sd	s7,56(sp)
    80006116:	f862                	sd	s8,48(sp)
    80006118:	f466                	sd	s9,40(sp)
    8000611a:	f06a                	sd	s10,32(sp)
    8000611c:	ec6e                	sd	s11,24(sp)
    8000611e:	0100                	addi	s0,sp,128
    80006120:	8aaa                	mv	s5,a0
    80006122:	8c2e                	mv	s8,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80006124:	00c52d03          	lw	s10,12(a0)
    80006128:	001d1d1b          	slliw	s10,s10,0x1
    8000612c:	1d02                	slli	s10,s10,0x20
    8000612e:	020d5d13          	srli	s10,s10,0x20

  acquire(&disk.vdisk_lock);
    80006132:	0001c517          	auipc	a0,0x1c
    80006136:	11650513          	addi	a0,a0,278 # 80022248 <disk+0x128>
    8000613a:	ffffb097          	auipc	ra,0xffffb
    8000613e:	a9c080e7          	jalr	-1380(ra) # 80000bd6 <acquire>
  for(int i = 0; i < 3; i++){
    80006142:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    80006144:	44a1                	li	s1,8
      disk.free[i] = 0;
    80006146:	0001cb97          	auipc	s7,0x1c
    8000614a:	fdab8b93          	addi	s7,s7,-38 # 80022120 <disk>
  for(int i = 0; i < 3; i++){
    8000614e:	4b0d                	li	s6,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80006150:	0001cc97          	auipc	s9,0x1c
    80006154:	0f8c8c93          	addi	s9,s9,248 # 80022248 <disk+0x128>
    80006158:	a08d                	j	800061ba <virtio_disk_rw+0xb8>
      disk.free[i] = 0;
    8000615a:	00fb8733          	add	a4,s7,a5
    8000615e:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80006162:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80006164:	0207c563          	bltz	a5,8000618e <virtio_disk_rw+0x8c>
  for(int i = 0; i < 3; i++){
    80006168:	2905                	addiw	s2,s2,1
    8000616a:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    8000616c:	05690c63          	beq	s2,s6,800061c4 <virtio_disk_rw+0xc2>
    idx[i] = alloc_desc();
    80006170:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80006172:	0001c717          	auipc	a4,0x1c
    80006176:	fae70713          	addi	a4,a4,-82 # 80022120 <disk>
    8000617a:	87ce                	mv	a5,s3
    if(disk.free[i]){
    8000617c:	01874683          	lbu	a3,24(a4)
    80006180:	fee9                	bnez	a3,8000615a <virtio_disk_rw+0x58>
  for(int i = 0; i < NUM; i++){
    80006182:	2785                	addiw	a5,a5,1
    80006184:	0705                	addi	a4,a4,1
    80006186:	fe979be3          	bne	a5,s1,8000617c <virtio_disk_rw+0x7a>
    idx[i] = alloc_desc();
    8000618a:	57fd                	li	a5,-1
    8000618c:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    8000618e:	01205d63          	blez	s2,800061a8 <virtio_disk_rw+0xa6>
    80006192:	8dce                	mv	s11,s3
        free_desc(idx[j]);
    80006194:	000a2503          	lw	a0,0(s4)
    80006198:	00000097          	auipc	ra,0x0
    8000619c:	cfe080e7          	jalr	-770(ra) # 80005e96 <free_desc>
      for(int j = 0; j < i; j++)
    800061a0:	2d85                	addiw	s11,s11,1
    800061a2:	0a11                	addi	s4,s4,4
    800061a4:	ff2d98e3          	bne	s11,s2,80006194 <virtio_disk_rw+0x92>
    sleep(&disk.free[0], &disk.vdisk_lock);
    800061a8:	85e6                	mv	a1,s9
    800061aa:	0001c517          	auipc	a0,0x1c
    800061ae:	f8e50513          	addi	a0,a0,-114 # 80022138 <disk+0x18>
    800061b2:	ffffc097          	auipc	ra,0xffffc
    800061b6:	07a080e7          	jalr	122(ra) # 8000222c <sleep>
  for(int i = 0; i < 3; i++){
    800061ba:	f8040a13          	addi	s4,s0,-128
{
    800061be:	8652                	mv	a2,s4
  for(int i = 0; i < 3; i++){
    800061c0:	894e                	mv	s2,s3
    800061c2:	b77d                	j	80006170 <virtio_disk_rw+0x6e>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800061c4:	f8042503          	lw	a0,-128(s0)
    800061c8:	00a50713          	addi	a4,a0,10
    800061cc:	0712                	slli	a4,a4,0x4

  if(write)
    800061ce:	0001c797          	auipc	a5,0x1c
    800061d2:	f5278793          	addi	a5,a5,-174 # 80022120 <disk>
    800061d6:	00e786b3          	add	a3,a5,a4
    800061da:	01803633          	snez	a2,s8
    800061de:	c690                	sw	a2,8(a3)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    800061e0:	0006a623          	sw	zero,12(a3)
  buf0->sector = sector;
    800061e4:	01a6b823          	sd	s10,16(a3)

  disk.desc[idx[0]].addr = (uint64) buf0;
    800061e8:	f6070613          	addi	a2,a4,-160
    800061ec:	6394                	ld	a3,0(a5)
    800061ee:	96b2                	add	a3,a3,a2
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800061f0:	00870593          	addi	a1,a4,8
    800061f4:	95be                	add	a1,a1,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    800061f6:	e28c                	sd	a1,0(a3)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    800061f8:	0007b803          	ld	a6,0(a5)
    800061fc:	9642                	add	a2,a2,a6
    800061fe:	46c1                	li	a3,16
    80006200:	c614                	sw	a3,8(a2)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80006202:	4585                	li	a1,1
    80006204:	00b61623          	sh	a1,12(a2)
  disk.desc[idx[0]].next = idx[1];
    80006208:	f8442683          	lw	a3,-124(s0)
    8000620c:	00d61723          	sh	a3,14(a2)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80006210:	0692                	slli	a3,a3,0x4
    80006212:	9836                	add	a6,a6,a3
    80006214:	058a8613          	addi	a2,s5,88
    80006218:	00c83023          	sd	a2,0(a6)
  disk.desc[idx[1]].len = BSIZE;
    8000621c:	0007b803          	ld	a6,0(a5)
    80006220:	96c2                	add	a3,a3,a6
    80006222:	40000613          	li	a2,1024
    80006226:	c690                	sw	a2,8(a3)
  if(write)
    80006228:	001c3613          	seqz	a2,s8
    8000622c:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80006230:	00166613          	ori	a2,a2,1
    80006234:	00c69623          	sh	a2,12(a3)
  disk.desc[idx[1]].next = idx[2];
    80006238:	f8842603          	lw	a2,-120(s0)
    8000623c:	00c69723          	sh	a2,14(a3)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80006240:	00250693          	addi	a3,a0,2
    80006244:	0692                	slli	a3,a3,0x4
    80006246:	96be                	add	a3,a3,a5
    80006248:	58fd                	li	a7,-1
    8000624a:	01168823          	sb	a7,16(a3)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    8000624e:	0612                	slli	a2,a2,0x4
    80006250:	9832                	add	a6,a6,a2
    80006252:	f9070713          	addi	a4,a4,-112
    80006256:	973e                	add	a4,a4,a5
    80006258:	00e83023          	sd	a4,0(a6)
  disk.desc[idx[2]].len = 1;
    8000625c:	6398                	ld	a4,0(a5)
    8000625e:	9732                	add	a4,a4,a2
    80006260:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80006262:	4609                	li	a2,2
    80006264:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[2]].next = 0;
    80006268:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    8000626c:	00baa223          	sw	a1,4(s5)
  disk.info[idx[0]].b = b;
    80006270:	0156b423          	sd	s5,8(a3)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80006274:	6794                	ld	a3,8(a5)
    80006276:	0026d703          	lhu	a4,2(a3)
    8000627a:	8b1d                	andi	a4,a4,7
    8000627c:	0706                	slli	a4,a4,0x1
    8000627e:	96ba                	add	a3,a3,a4
    80006280:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80006284:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80006288:	6798                	ld	a4,8(a5)
    8000628a:	00275783          	lhu	a5,2(a4)
    8000628e:	2785                	addiw	a5,a5,1
    80006290:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80006294:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80006298:	100017b7          	lui	a5,0x10001
    8000629c:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    800062a0:	004aa783          	lw	a5,4(s5)
    sleep(b, &disk.vdisk_lock);
    800062a4:	0001c917          	auipc	s2,0x1c
    800062a8:	fa490913          	addi	s2,s2,-92 # 80022248 <disk+0x128>
  while(b->disk == 1) {
    800062ac:	4485                	li	s1,1
    800062ae:	00b79c63          	bne	a5,a1,800062c6 <virtio_disk_rw+0x1c4>
    sleep(b, &disk.vdisk_lock);
    800062b2:	85ca                	mv	a1,s2
    800062b4:	8556                	mv	a0,s5
    800062b6:	ffffc097          	auipc	ra,0xffffc
    800062ba:	f76080e7          	jalr	-138(ra) # 8000222c <sleep>
  while(b->disk == 1) {
    800062be:	004aa783          	lw	a5,4(s5)
    800062c2:	fe9788e3          	beq	a5,s1,800062b2 <virtio_disk_rw+0x1b0>
  }

  disk.info[idx[0]].b = 0;
    800062c6:	f8042903          	lw	s2,-128(s0)
    800062ca:	00290713          	addi	a4,s2,2
    800062ce:	0712                	slli	a4,a4,0x4
    800062d0:	0001c797          	auipc	a5,0x1c
    800062d4:	e5078793          	addi	a5,a5,-432 # 80022120 <disk>
    800062d8:	97ba                	add	a5,a5,a4
    800062da:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    800062de:	0001c997          	auipc	s3,0x1c
    800062e2:	e4298993          	addi	s3,s3,-446 # 80022120 <disk>
    800062e6:	00491713          	slli	a4,s2,0x4
    800062ea:	0009b783          	ld	a5,0(s3)
    800062ee:	97ba                	add	a5,a5,a4
    800062f0:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    800062f4:	854a                	mv	a0,s2
    800062f6:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    800062fa:	00000097          	auipc	ra,0x0
    800062fe:	b9c080e7          	jalr	-1124(ra) # 80005e96 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80006302:	8885                	andi	s1,s1,1
    80006304:	f0ed                	bnez	s1,800062e6 <virtio_disk_rw+0x1e4>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80006306:	0001c517          	auipc	a0,0x1c
    8000630a:	f4250513          	addi	a0,a0,-190 # 80022248 <disk+0x128>
    8000630e:	ffffb097          	auipc	ra,0xffffb
    80006312:	97c080e7          	jalr	-1668(ra) # 80000c8a <release>
}
    80006316:	70e6                	ld	ra,120(sp)
    80006318:	7446                	ld	s0,112(sp)
    8000631a:	74a6                	ld	s1,104(sp)
    8000631c:	7906                	ld	s2,96(sp)
    8000631e:	69e6                	ld	s3,88(sp)
    80006320:	6a46                	ld	s4,80(sp)
    80006322:	6aa6                	ld	s5,72(sp)
    80006324:	6b06                	ld	s6,64(sp)
    80006326:	7be2                	ld	s7,56(sp)
    80006328:	7c42                	ld	s8,48(sp)
    8000632a:	7ca2                	ld	s9,40(sp)
    8000632c:	7d02                	ld	s10,32(sp)
    8000632e:	6de2                	ld	s11,24(sp)
    80006330:	6109                	addi	sp,sp,128
    80006332:	8082                	ret

0000000080006334 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80006334:	1101                	addi	sp,sp,-32
    80006336:	ec06                	sd	ra,24(sp)
    80006338:	e822                	sd	s0,16(sp)
    8000633a:	e426                	sd	s1,8(sp)
    8000633c:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    8000633e:	0001c497          	auipc	s1,0x1c
    80006342:	de248493          	addi	s1,s1,-542 # 80022120 <disk>
    80006346:	0001c517          	auipc	a0,0x1c
    8000634a:	f0250513          	addi	a0,a0,-254 # 80022248 <disk+0x128>
    8000634e:	ffffb097          	auipc	ra,0xffffb
    80006352:	888080e7          	jalr	-1912(ra) # 80000bd6 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80006356:	10001737          	lui	a4,0x10001
    8000635a:	533c                	lw	a5,96(a4)
    8000635c:	8b8d                	andi	a5,a5,3
    8000635e:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80006360:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80006364:	689c                	ld	a5,16(s1)
    80006366:	0204d703          	lhu	a4,32(s1)
    8000636a:	0027d783          	lhu	a5,2(a5)
    8000636e:	04f70863          	beq	a4,a5,800063be <virtio_disk_intr+0x8a>
    __sync_synchronize();
    80006372:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80006376:	6898                	ld	a4,16(s1)
    80006378:	0204d783          	lhu	a5,32(s1)
    8000637c:	8b9d                	andi	a5,a5,7
    8000637e:	078e                	slli	a5,a5,0x3
    80006380:	97ba                	add	a5,a5,a4
    80006382:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80006384:	00278713          	addi	a4,a5,2
    80006388:	0712                	slli	a4,a4,0x4
    8000638a:	9726                	add	a4,a4,s1
    8000638c:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    80006390:	e721                	bnez	a4,800063d8 <virtio_disk_intr+0xa4>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80006392:	0789                	addi	a5,a5,2
    80006394:	0792                	slli	a5,a5,0x4
    80006396:	97a6                	add	a5,a5,s1
    80006398:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    8000639a:	00052223          	sw	zero,4(a0)
    wakeup(b);
    8000639e:	ffffc097          	auipc	ra,0xffffc
    800063a2:	ef2080e7          	jalr	-270(ra) # 80002290 <wakeup>

    disk.used_idx += 1;
    800063a6:	0204d783          	lhu	a5,32(s1)
    800063aa:	2785                	addiw	a5,a5,1
    800063ac:	17c2                	slli	a5,a5,0x30
    800063ae:	93c1                	srli	a5,a5,0x30
    800063b0:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    800063b4:	6898                	ld	a4,16(s1)
    800063b6:	00275703          	lhu	a4,2(a4)
    800063ba:	faf71ce3          	bne	a4,a5,80006372 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    800063be:	0001c517          	auipc	a0,0x1c
    800063c2:	e8a50513          	addi	a0,a0,-374 # 80022248 <disk+0x128>
    800063c6:	ffffb097          	auipc	ra,0xffffb
    800063ca:	8c4080e7          	jalr	-1852(ra) # 80000c8a <release>
}
    800063ce:	60e2                	ld	ra,24(sp)
    800063d0:	6442                	ld	s0,16(sp)
    800063d2:	64a2                	ld	s1,8(sp)
    800063d4:	6105                	addi	sp,sp,32
    800063d6:	8082                	ret
      panic("virtio_disk_intr status");
    800063d8:	00002517          	auipc	a0,0x2
    800063dc:	4a850513          	addi	a0,a0,1192 # 80008880 <syscalls+0x3e8>
    800063e0:	ffffa097          	auipc	ra,0xffffa
    800063e4:	160080e7          	jalr	352(ra) # 80000540 <panic>
	...

0000000080007000 <_trampoline>:
    80007000:	14051073          	csrw	sscratch,a0
    80007004:	02000537          	lui	a0,0x2000
    80007008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000700a:	0536                	slli	a0,a0,0xd
    8000700c:	02153423          	sd	ra,40(a0)
    80007010:	02253823          	sd	sp,48(a0)
    80007014:	02353c23          	sd	gp,56(a0)
    80007018:	04453023          	sd	tp,64(a0)
    8000701c:	04553423          	sd	t0,72(a0)
    80007020:	04653823          	sd	t1,80(a0)
    80007024:	04753c23          	sd	t2,88(a0)
    80007028:	f120                	sd	s0,96(a0)
    8000702a:	f524                	sd	s1,104(a0)
    8000702c:	fd2c                	sd	a1,120(a0)
    8000702e:	e150                	sd	a2,128(a0)
    80007030:	e554                	sd	a3,136(a0)
    80007032:	e958                	sd	a4,144(a0)
    80007034:	ed5c                	sd	a5,152(a0)
    80007036:	0b053023          	sd	a6,160(a0)
    8000703a:	0b153423          	sd	a7,168(a0)
    8000703e:	0b253823          	sd	s2,176(a0)
    80007042:	0b353c23          	sd	s3,184(a0)
    80007046:	0d453023          	sd	s4,192(a0)
    8000704a:	0d553423          	sd	s5,200(a0)
    8000704e:	0d653823          	sd	s6,208(a0)
    80007052:	0d753c23          	sd	s7,216(a0)
    80007056:	0f853023          	sd	s8,224(a0)
    8000705a:	0f953423          	sd	s9,232(a0)
    8000705e:	0fa53823          	sd	s10,240(a0)
    80007062:	0fb53c23          	sd	s11,248(a0)
    80007066:	11c53023          	sd	t3,256(a0)
    8000706a:	11d53423          	sd	t4,264(a0)
    8000706e:	11e53823          	sd	t5,272(a0)
    80007072:	11f53c23          	sd	t6,280(a0)
    80007076:	140022f3          	csrr	t0,sscratch
    8000707a:	06553823          	sd	t0,112(a0)
    8000707e:	00853103          	ld	sp,8(a0)
    80007082:	02053203          	ld	tp,32(a0)
    80007086:	01053283          	ld	t0,16(a0)
    8000708a:	00053303          	ld	t1,0(a0)
    8000708e:	12000073          	sfence.vma
    80007092:	18031073          	csrw	satp,t1
    80007096:	12000073          	sfence.vma
    8000709a:	8282                	jr	t0

000000008000709c <userret>:
    8000709c:	12000073          	sfence.vma
    800070a0:	18051073          	csrw	satp,a0
    800070a4:	12000073          	sfence.vma
    800070a8:	02000537          	lui	a0,0x2000
    800070ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800070ae:	0536                	slli	a0,a0,0xd
    800070b0:	02853083          	ld	ra,40(a0)
    800070b4:	03053103          	ld	sp,48(a0)
    800070b8:	03853183          	ld	gp,56(a0)
    800070bc:	04053203          	ld	tp,64(a0)
    800070c0:	04853283          	ld	t0,72(a0)
    800070c4:	05053303          	ld	t1,80(a0)
    800070c8:	05853383          	ld	t2,88(a0)
    800070cc:	7120                	ld	s0,96(a0)
    800070ce:	7524                	ld	s1,104(a0)
    800070d0:	7d2c                	ld	a1,120(a0)
    800070d2:	6150                	ld	a2,128(a0)
    800070d4:	6554                	ld	a3,136(a0)
    800070d6:	6958                	ld	a4,144(a0)
    800070d8:	6d5c                	ld	a5,152(a0)
    800070da:	0a053803          	ld	a6,160(a0)
    800070de:	0a853883          	ld	a7,168(a0)
    800070e2:	0b053903          	ld	s2,176(a0)
    800070e6:	0b853983          	ld	s3,184(a0)
    800070ea:	0c053a03          	ld	s4,192(a0)
    800070ee:	0c853a83          	ld	s5,200(a0)
    800070f2:	0d053b03          	ld	s6,208(a0)
    800070f6:	0d853b83          	ld	s7,216(a0)
    800070fa:	0e053c03          	ld	s8,224(a0)
    800070fe:	0e853c83          	ld	s9,232(a0)
    80007102:	0f053d03          	ld	s10,240(a0)
    80007106:	0f853d83          	ld	s11,248(a0)
    8000710a:	10053e03          	ld	t3,256(a0)
    8000710e:	10853e83          	ld	t4,264(a0)
    80007112:	11053f03          	ld	t5,272(a0)
    80007116:	11853f83          	ld	t6,280(a0)
    8000711a:	7928                	ld	a0,112(a0)
    8000711c:	10200073          	sret
	...
