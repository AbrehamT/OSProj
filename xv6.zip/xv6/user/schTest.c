#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"


int isPrime(int N){
    if (N <= 1) return 0;
    if (N <= 3) return 1;
    if (N%2 == 0 || N%3 == 0) return 0;
    for(int i = 5; i <= (N/2); i = i + 6){
        if (N%i == 0 || N % (i+2)==0){
            return 0;
        }
    }
    return 1;
}

int primecount(int LIMIT){
    int count = 0;
    for(int i = 2; i <= LIMIT; i++){
        if (isPrime(i)){
            count++;
        }
    }
    return count;
}


int main(int argc, char* argv)
{
    int MAX_PROCESS = 12;
    int pid[32] ={0};
    int temp_pid = 0;
    int p_count = 0;
    int LIMIT = 50000;
    uint index = 0;
    printf("===== schTest =====\nMAX_PROCESS= %d, LIMIT = %d\n", MAX_PROCESS, LIMIT);
    printf("Parent process running. PID = %d\n", getpid());
    for(int i = 0; i < MAX_PROCESS; i++){
        temp_pid = fork();
      if(temp_pid == 0){
            p_count = primecount(LIMIT);
            printf("Child process %d finished. PID=%d, Count=%d\n", i, getpid(), p_count);
            exit(0);
      }
    }
    for(int i = 0; i < MAX_PROCESS; i++){
        wait(0);
    }

    // Call schedDisp() here to retrieve the lastProcess
    //Casting to uint so that when index < 0, index mod 32 is not a negative value
    index = (uint)schedDisp(pid);
    
    for (int i = 0; i < 32; i++){
        printf("%d ", pid[index%32]);
        index -= 1;
    }
    printf("\n");
    return 0;
}