user/schTest.o: user/schTest.c kernel/types.h kernel/stat.h user/user.h
